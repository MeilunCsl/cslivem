vmc framework version 0.0.3.2
