﻿using System;
using System.Text;

namespace com.bitmick.marshall.utils
{

	public static class ByteArrayUtils
	{


		// ===========================================================
		// Constants
		// ===========================================================

		internal static readonly string TAG = typeof(ByteArrayUtils).Name;

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        //  abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        public static long byteArrToLong(byte[] arr, int offset)
        {
            ulong longValue = 0;

            longValue = (((ulong)arr[offset + 0]) & 0xff);
            longValue = longValue + (((ulong)(arr[offset + 1]) & 0xff) << 8);
            longValue = longValue + (((ulong)(arr[offset + 2]) & 0xff) << 16);
            longValue = longValue + (((ulong)(arr[offset + 3]) & 0xff) << 24);
            longValue = longValue + (((ulong)(arr[offset + 4]) & 0xff) << 32);
            longValue = longValue + (((ulong)(arr[offset + 5]) & 0xff) << 40);
            longValue = longValue + (((ulong)(arr[offset + 6]) & 0xff) << 48);
            longValue = longValue + (((ulong)(arr[offset + 7]) & 0xff) << 56);

            return (long)longValue;
        }

        public static int byteArrToInteger(byte[] arr, int offset)
		{
			int intValue = 0;

			intValue = (((int)arr[offset + 0]) & 0xff);
			intValue = intValue + (((int)(arr[offset + 1]) & 0xff) << 8);
			intValue = intValue + (((int)(arr[offset + 2]) & 0xff) << 16);
			intValue = intValue + (((int)(arr[offset + 3]) & 0xff) << 24);

			return intValue;
		}

		public static ushort byteArrToShort(byte[] arr, int offset)
		{
			ushort shortValue = 0;

			shortValue = (ushort)(arr[offset + 0] & 0xff);
			shortValue = (ushort)(shortValue + (((ushort)(arr[offset + 1]) & 0xff) << 8));

			return shortValue;
		}

		public static byte byteArrToByte(byte[] arr, int offset)
		{
			return arr[offset];
		}

		public static int byteToByteArray(byte[] arr, int offset, sbyte value)
		{
			arr[offset + 0] = (byte)(value);

			return 1;
		}

		public static int shortToByteArray(byte[] arr, int offset, ushort value)
		{
			arr[offset + 0] = (byte)(value);
			arr[offset + 1] = (byte)(value >> 8);

			return 2;
		}

		public static int intToByteArray(byte[] arr, int offset, int value)
		{
			arr[offset + 0] = (byte)(value >> 0);
			arr[offset + 1] = (byte)(value >> 8);
			arr[offset + 2] = (byte)(value >> 16);
			arr[offset + 3] = (byte)(value >> 24);

			return 4;
		}

		public static int stringToByteArray(byte[] arr, int offset, string str, int max_len)
		{
			byte[] str_byte_arr = null;

            str_byte_arr = str.GetBytes(Encoding.ASCII);

				max_len = str_byte_arr.Length < max_len ? str_byte_arr.Length : max_len;

				for (int i = 0; i < str_byte_arr.Length; i++)
				{
					arr[offset++] = str_byte_arr[i];
				}

            return str_byte_arr.Length;
		}

		public static string byteArrToString(byte[] arr, int offset, int max_len)
		{

			int str_length = max_len;
			for (int i = offset; i < offset + str_length; i++)
			{
				if (arr[i] == 0)
				{
					str_length = i;
					break;
				}
			}
			return StringHelperClass.NewString(arr, offset, str_length);
		}

		public static int subByteArrToByteArray(byte[] arr, int offset, byte[] sub_arr)
		{
			Array.Copy(sub_arr, 0, arr, offset, sub_arr.Length);

			return sub_arr.Length;
		}

		public static int byteArrToSubByteArray(byte[] arr, int offset, byte[] sub_arr)
		{
			Array.Copy(arr, offset, sub_arr, 0, sub_arr.Length);

			return sub_arr.Length;
		}

	}

}