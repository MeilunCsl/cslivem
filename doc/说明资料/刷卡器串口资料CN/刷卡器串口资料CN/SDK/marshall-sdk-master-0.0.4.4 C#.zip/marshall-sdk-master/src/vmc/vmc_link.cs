using System;
using System.Threading;
using System.Timers;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace com.bitmick.marshall.protocol
{
	using com.bitmick.marshall.data;
	using com.bitmick.marshall.models;
	using com.bitmick.marshall.utils;
	using com.bitmick.marshall.interfaces;

	public class vmc_link : lowlevel_i.link_events_t
    {

		// this layer is responsible for the low-level marshall link
		// 1. link establishment
		// 2. re-transmittion control
		// 3. keep-alive

		// ===========================================================
		// Constants
		// ===========================================================

		internal static readonly string TAG = typeof(vmc_link).Name;

		private const int vmc_link_state_init_e = 0;
		private const int vmc_link_state_reset_e = 1;
		private const int vmc_link_state_config_e = 2;
		private const int vmc_link_state_ready_e = 3;
		private const int vmc_link_state_error_e = 4;

		private const int MAX_QUEUE_SIZE = 100;

        private const byte PERIPHERAL_SUB_TYPE = 0x01;

        public const int MARSHALL_RETRANSMIT_KA_INTERVAL = 1000;
        public const int MARSHALL_NO_COMM_TIMEOUT = 15000;

		public const int TIMER_TICK_MS = 50;

		public interface vmc_link_events_t
		{

			//////////////////////////////////////////////////////////////////////////////////////////////
			// function name:
			// input:
			// output:
			// notes:
			/////////////////////////////////////////////////////////////////////////////////////////////
			void onReady(vpos_config_t config);

			//////////////////////////////////////////////////////////////////////////////////////////////
			// function name:
			// input:
			// output:
			// notes:
			/////////////////////////////////////////////////////////////////////////////////////////////
			void onCommError();

		}

		// ===========================================================
		// Sub Classes
		// ===========================================================

		public class vpos_config_t
		{
			// marshall protocol version, msb
			public byte prot_ver_major;
			// marshall protocol version, lsb
			public byte prot_ver_minor;
			public byte language;
			// country code, iso<t.b.d>
			public byte[] country_code;
			// currency code, based on same iso<t.b.d> above
			public byte[] currency_code;
			// how price is represented, as 10 exponent. for example:
			// if decimal place is 2 and price requested is 100, then the actual price is 1.00 (decimal places: 2 positions)
			// if decimal place is 0 and price requested is 100, then the actual price is 100.
			// all pricing is according to currency configured on DCS (above examples, 1.00$, and 100$ respectivly)
			public byte decimal_place;
			// byte array representing vpos serial number
			public byte[] vpos_serial;
			// machine type. see vmc_configuration.machine_type_xxxxxx
			public int machine_type;
			// merchant id
			public byte[] merchant_id;
			// merchant teminal id
			public byte[] acquirer_terminal_id;
			// machine location
			public byte[] machine_location;

		}

		public class vpos_link_stats_t
		{
			public int comm_loss;
			public int crc_error;
			public int retrans;
		}

		// ===========================================================
		// Fields
		// ===========================================================

		private lowlevel_i m_i_f;
		private BlockingCollection<MsgObject> m_msg_queue;
		private Thread m_vmc_thread;
		private bool m_vmc_thread_running;

		// marshall
		private static byte[] m_tx_buf;

		private System.Timers.Timer m_keepalive_timer;

		private int m_marshall_link_state;
		private marshall_t.msg_config_t m_config;
		private vpos_config_t m_vpos_config;
		private volatile int m_rx_msg_id;
		private volatile byte m_tx_msg_id;

		private marshall_t.msg_marshall_t m_pending_tx_msg;
		private int m_pending_tx_msg_retries;
		private Queue<marshall_t.msg_marshall_t> m_marshall_queue;

		private long m_transmit_timestamp;
		private long m_receive_timestamp;
		private long m_last_tick_timestamp;
		private bool m_is_marshall_online;

		private vmc_link_events_t m_vmc_events;
		// vmc clients
		private List<vmc_client_t> m_clients;

		private vmc_configuration m_app_config;

		private vpos_link_stats_t m_link_stats;

		// ===========================================================
		// Abstract methods
		// ===========================================================

		// ===========================================================
		// Constructors
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_link()
		{
			init();
		}

		// ===========================================================
		// Methods from SuperClass/Interfaces (and supporting methods)
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void set_events(vmc_link_events_t events)
		{
			m_vmc_events = events;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void start()
		{
            if (m_app_config.always_idle)
            {
                m_app_config.reader_always_on = true;
            }

            // start clients
            foreach (vmc_client_t client in m_clients)
			{
				client.start();
			}

            if (m_app_config.debug)
                Log.level(0xff);
            else
                Log.level(0);

            // start parsing thread
            m_vmc_thread = new Thread(new ThreadStart(vmc_thread_proc));
            m_vmc_thread.Priority = ThreadPriority.Highest;
			m_vmc_thread.Start();

			// initialize lowlevel serial interface
			m_i_f.init(m_app_config.port_vpos, m_app_config.port_vpos_baud);

			// start lowlevel serial interface
			m_i_f.register_link_events(this);
			m_i_f.start();

			Log.d(TAG, string.Format("marshall C# sdk version {0}", vmc_framework.get_version()));

		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void stop()
		{
			// stop clients
			foreach (vmc_client_t client in m_clients)
			{
				client.stop();
			}

			// stop keepalive timer
			keepalive_stop();

			// stop vmc link thread
			if (m_vmc_thread != null)
			{
				notify(R.id_stop_thread, null);
				m_vmc_thread = null;
			}

			m_i_f.stop();

            m_is_marshall_online = false;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        
		public bool onReceive(byte[] data, int offset, int len)
        {
            marshall_t.msg_marshall_t marshall_msg = new marshall_t.msg_marshall_t();

			bool result = marshall_msg.decode(data, offset, len) > 0;

            if (result)
            {
                // mark last reception time-stamp

                m_receive_timestamp = Utils.currentTimeMillis();

                bool ack_request = (marshall_msg.options & marshall_t.marshall_packet_option_ack_mask) != 0;
                int retrans_num = (marshall_msg.options & marshall_t.marshall_packet_option_retry_num_mask) >> 2;
                int rx_msg_id = (marshall_msg.id & 0xff);


				dump_packet("rx", marshall_msg, data, offset, len);

				// check response, as it is an ack message
				if (marshall_msg.func_code == marshall_t.marshall_func_code_response)
                {
                    marshall_t.msg_response_t response = (marshall_t.msg_response_t)marshall_msg.body;

                    // received ack
                    if (response.value == marshall_t.msg_response_t.response_ack)
                    {
                        if (m_pending_tx_msg != null)
                        {
                            if (m_pending_tx_msg.id != marshall_msg.id)
                            {
                                Log.e(TAG, string.Format("sporious ack!. waiting for {0}, received {1}", m_pending_tx_msg.id, marshall_msg.id));
                            }

                            // remove ack'ed message
                            discard_last_tx_message_trigger_next();
                        }
                    }
                }
                else
                {
                    // transmit ack, in case ack is needed
                    if (ack_request)
                    {
                        marshall_t.msg_marshall_t ack_msg = marshall_t.response(marshall_t.marshall_packet_option_none, marshall_t.msg_response_t.response_ack);

                        // acknowledge
                        transmit_marshall_raw(ack_msg, marshall_msg.id, true);
                    }

                    // check message id and message duplication
                    if (retrans_num != 0 && m_rx_msg_id == rx_msg_id)
                    {
                        // check for duplication
                        Log.e(TAG, String.Format("discarding duplicate frame: {0}", m_rx_msg_id));
                        return false;
                    }
                    else
                    {
                        if (is_ready())
                        {
                            int delta = rx_msg_id - m_rx_msg_id;
                            if (delta <= 0)
                            {
                                delta = 256 - delta;
                            }

                            if (delta != 1 && delta != 511)
                            {
                                Log.e(TAG, String.Format("not consecutive message {0} received: {1}, expected: {2}, delta: {3}", marshall_msg.func_code, rx_msg_id, m_rx_msg_id, delta));
                            }
                        }
                    }

                    m_rx_msg_id = rx_msg_id;
                }

				notify(R.id_rx, marshall_msg);

            }
			else
			{
                // handle stats
				m_link_stats.crc_error++;
			}
   
            return result;
        }

		// ===========================================================
		// Methods
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void init()
		{
			m_msg_queue = new BlockingCollection<MsgObject>(MAX_QUEUE_SIZE);

			m_clients = new List<vmc_client_t>();

			marshall_init_variables();

			m_tx_buf = new byte[512];

			m_link_stats = new vpos_link_stats_t();
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void marshall_init_variables()
		{
			m_rx_msg_id = 0;
			m_tx_msg_id = 0;
			m_config = new marshall_t.msg_config_t();

			m_transmit_timestamp = 0;
			m_is_marshall_online = false;

			m_pending_tx_msg = null;
			m_pending_tx_msg_retries = 3;
			m_marshall_queue = new Queue<marshall_t.msg_marshall_t>();

			m_marshall_link_state = vmc_link_state_init_e;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void tx_queue_reset()
		{
  			{
				m_marshall_queue.Clear();
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private bool tx_queue_is_empty()
		{
			int count = 0;
   
			count = m_marshall_queue.Count;

			return (count == 0);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private marshall_t.msg_marshall_t tx_queue_peek()
		{
			marshall_t.msg_marshall_t msg = null;

			{
				if (!tx_queue_is_empty())
				{
					msg = m_marshall_queue.Peek();
				}
			}

			return msg;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void tx_queue_enqueue(marshall_t.msg_marshall_t msg)
		{
			{
				m_marshall_queue.Enqueue(msg);
			}
		}

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private marshall_t.msg_marshall_t tx_queue_dequeue()
        {
            marshall_t.msg_marshall_t msg = null;

            lock(m_marshall_queue)
            {
                try
                {
                    if (!tx_queue_is_empty())
                        msg = m_marshall_queue.Dequeue();
                }
                catch (Exception ex)
                {
					Log.e(TAG, ex.Message);
                }
            }

            return msg;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void discard_last_tx_message_trigger_next()
		{
            // remove ack'ed message
            tx_queue_dequeue();

            m_pending_tx_msg = null;
            m_pending_tx_msg_retries = 3;

            // trigger next transmission
            if (!tx_queue_is_empty())
            {
                notify(R.id_tx, null);
            }
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void keepalive_start()
		{
			// invoke keep-alive - timer
			if (m_keepalive_timer == null)
			{
				m_last_tick_timestamp = Utils.currentTimeMillis();

				m_keepalive_timer = new System.Timers.Timer(TIMER_TICK_MS);
				m_keepalive_timer.AutoReset = true;
				m_keepalive_timer.Elapsed += OnKeepAliveTimerExpired;

				// make sure the timer runs on threadpool
				m_keepalive_timer.SynchronizingObject = null;

				m_keepalive_timer.Enabled = true;
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void keepalive_stop()
		{
			// stop keepalive timer
			if (m_keepalive_timer != null)
			{
				m_keepalive_timer.Enabled = false;
				m_keepalive_timer = null;
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private bool marshall_link_change_state(int new_state)
		{
			//Log.d(TAG, string.Format("changing from {0} to {1}", m_marshall_link_state, new_state));


			switch (new_state)
			{
				case vmc_link_state_init_e:
					keepalive_stop();

					marshall_init_variables();

					// notify clients about init
					foreach (vmc_client_t client in m_clients)
					{
						client.onCommError();
					}
					break;
				case vmc_link_state_reset_e:
					break;
				case vmc_link_state_config_e:
					keepalive_start();
					break;
				case vmc_link_state_ready_e:
					Log.d(TAG, "vmc is online");

					// mark that vmc is online
					if (m_is_marshall_online)
					{
						// receiving reset while already in online state means link
                        // was somehow lost...
						m_link_stats.comm_loss++;
					}
					m_is_marshall_online = true;

					// notify all clients that a link has established
					foreach (vmc_client_t client in m_clients)
					{
						client.onReady(this);
					}

                    if (m_vmc_events != null)
                        m_vmc_events.onReady(m_vpos_config);

                    break;
				case vmc_link_state_error_e:
					break;
				default:
					break;
			}

			m_marshall_link_state = new_state;

			return true;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void marshall_link_state(marshall_t.msg_marshall_t msg)
		{
			bool action = false;

			do
			{
				action = false;

				switch (m_marshall_link_state)
				{
					case vmc_link_state_init_e:
						{
							switch (msg.func_code)
							{
								case marshall_t.marshall_func_code_reset:

									// send fw info
									marshall_t.msg_fw_info_t body = new marshall_t.msg_fw_info_t();

									body.prot_ver = marshall_t.marshall_version;
									body.periph_type = (byte)m_app_config.machine_type;
									body.periph_sub_type = PERIPHERAL_SUB_TYPE;
									body.periph_cap_bitmap = 0;
									body.model = m_app_config.model.PadRight(19).Substring(0, 19);
									body.serial = m_app_config.serial.PadRight(19).Substring(0, 19);
                                    body.app_sw_ver = m_app_config.sw_ver.PadRight(19).Substring(0, 19);

                                    // configure cap bitmap according to configuration
                                    if (m_app_config.multi_session_support)
									{
										body.periph_cap_bitmap |= marshall_t.msg_fw_info_t.fw_info_periph_cap_bitmap_multi_session;
									}

									if (m_app_config.price_not_final_support)
									{
										body.periph_cap_bitmap |= marshall_t.msg_fw_info_t.fw_info_periph_cap_bitmap_req_price_is_not_final;
									}

									if (m_app_config.mag_card_approved_by_vmc_support)
									{
										body.periph_cap_bitmap |= marshall_t.msg_fw_info_t.fw_info_periph_cap_bitmap_mag_card_approved_by_vmc;
									}

									if (m_app_config.mifare_approved_by_vmc_support)
									{
										body.periph_cap_bitmap |= marshall_t.msg_fw_info_t.fw_info_periph_cap_bitmap_mifare_card_approved_by_vmc;
									}

									// transmit message
									transmit_marshall(marshall_t.firmware_info((byte)0, body));

									m_rx_msg_id = 0;

									// move to wait for config state
									action = marshall_link_change_state(vmc_link_state_reset_e);
									break;
								default:
									// stay here...
									break;
							}
						}
						break;
					case vmc_link_state_reset_e:
						{
							switch (msg.func_code)
							{
								case marshall_t.marshall_func_code_config:
									m_config = (marshall_t.msg_config_t)msg.body;

									m_vpos_config = new vpos_config_t();
									m_vpos_config.prot_ver_major = m_config.prot_ver_major;
									m_vpos_config.prot_ver_minor = m_config.prot_ver_minor;
									m_vpos_config.country_code = m_config.country_code;
									m_vpos_config.currency_code = m_config.currency_code;
									m_vpos_config.decimal_place = m_config.decimal_place;
									m_vpos_config.language = m_config.language;
									m_vpos_config.vpos_serial = m_config.vpos_serial;
									if (m_vpos_config.prot_ver_major >= 1)
									{
										m_vpos_config.merchant_id = m_config.merchant_id;
										m_vpos_config.acquirer_terminal_id = m_config.acquirer_terminal_id;
										m_vpos_config.machine_location = m_config.machine_location;
									}

									// move to config state
									action = marshall_link_change_state(vmc_link_state_config_e);
									break;
								case marshall_t.marshall_func_code_reset:
									action = marshall_link_change_state(vmc_link_state_init_e);
									break;
								default:
									break;
							}
						}
						break;
					case vmc_link_state_config_e:
						{
							switch (msg.func_code)
							{
								case marshall_t.marshall_func_code_reset:
									// change to reset state. another reset will surely arrive
									action = marshall_link_change_state(vmc_link_state_init_e);
									break;
								case marshall_t.marshall_func_code_response:
								default:
									action = marshall_link_change_state(vmc_link_state_ready_e);
									break;

							}
						}
						break;
					case vmc_link_state_ready_e:
						{
							switch (msg.func_code)
							{
								case marshall_t.marshall_func_code_reset:
									// change to reset state. another reset will surely arrive
									action = marshall_link_change_state(vmc_link_state_init_e);
									break;
								case marshall_t.marshall_func_code_response:
									break;
								default:
									// pass marshall messages to upper layers (socket / vending / etc)
									foreach (vmc_client_t client in m_clients)
									{
										if (client.handleMarshallMessage(msg))
										{
											break;
										}
									}
									break;

							}
						}
						break;
					case vmc_link_state_error_e:
						break;
					default:
						break;


				}
			} while (false);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private bool handle_message(MsgObject msg)
		{
			switch (msg.id)
			{
				case R.id_rx:
					{
						marshall_t.msg_marshall_t marshall_msg = (marshall_t.msg_marshall_t)msg.data;

						// handle message
                        marshall_link_state(marshall_msg);
 					}
					break;
				case R.id_tx:
					{
						marshall_t.msg_marshall_t tx_msg = tx_queue_peek();


                        if (m_pending_tx_msg != null)
                        {
                            Log.e(TAG, "trying to transmit while did not get message back!");
                        }

                        if (tx_msg == null)
						{
							Log.d(TAG, "requested to transmit from null queue!");
							break;
						}

						if (tx_msg.func_code != marshall_t.marshall_func_code_response && tx_msg.func_code != marshall_t.marshall_func_code_keepalive)
						{
							Log.d(TAG, string.Format("transmitting marshall command: {0}", tx_msg.func_code));
						}

						transmit_marshall_raw(tx_msg, m_tx_msg_id, true);

						// increment msg id and handle wrap-around
						m_tx_msg_id = (byte)(m_tx_msg_id + 1);

						// don't wait for ack, if no ack is required
						if ((tx_msg.options & marshall_t.marshall_packet_option_ack_mask) == 0)
						{
							// can remove message, it is not waiting for ack
							discard_last_tx_message_trigger_next();
						}
						else
						{
							// ack / timeout will trigger tx for (re-)transmission
							m_pending_tx_msg = tx_msg;
						}

					}
					break;
				case R.id_stop_thread:
					m_vmc_thread_running = false;
					break;
				default:
					break;
			}

			return true;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void notify(int msg_id, object obj)
		{
			MsgObject msg = new MsgObject();

			msg.id = msg_id;
			msg.data = obj;

			m_msg_queue.Add(msg);
		}

		private void vmc_thread_proc()
		{
			m_vmc_thread_running = true;

			while (m_vmc_thread_running)
			{
				try
                {
					MsgObject msg = m_msg_queue.Take();

					if (msg != null)
                    {
						if (!handle_message(msg))
						{
							
						}
                    }
                }
                catch (InvalidOperationException) { }
			}
		}
        
		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void transmit_marshall_lowlevel(marshall_t.msg_marshall_t msg)
		{

			// transmit next message
			int len = msg.encode(m_tx_buf, 0, m_tx_buf.Length);

			// transmit
			m_i_f.transmit(m_tx_buf, len);

			dump_packet("tx", msg, m_tx_buf, 0, len);

			m_transmit_timestamp = Utils.currentTimeMillis();
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void transmit_marshall_raw(marshall_t.msg_marshall_t msg, byte msg_id, bool now)
		{
			if (now)
			{
				msg.source = m_config.dev_src_id;
				msg.source_lsb = (byte)m_app_config.serial[0];
				msg.dest = marshall_t.vpos_address;
				msg.dest_lsb = m_config.vpos_serial[0];
				msg.id = msg_id;

				transmit_marshall_lowlevel(msg);
			}
			else
			{
				bool should_trigger_tx = tx_queue_is_empty();

				tx_queue_enqueue(msg);

				if (should_trigger_tx)
				{
					notify(R.id_tx, null);
				}
			}
		}

		// ===========================================================
		// Public Methods
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_client_t register_vmc_client(vmc_client_t client)
		{
			m_clients.Add(client);

			return client;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_link set_lowlevel(lowlevel_i i_f)
		{
			m_i_f = i_f;

			return this;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_link configure(vmc_configuration config)
		{
			m_app_config = config;

			return this;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_configuration get_configuration()
		{
			return m_app_config;
		}

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
		public vpos_link_stats_t get_stats()
        {
			return m_link_stats;
        }

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void transmit_marshall(marshall_t.msg_marshall_t msg)
		{
			transmit_marshall_raw(msg, (byte)m_tx_msg_id, false);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public bool is_ready()
		{
			return (m_is_marshall_online);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vpos_config_t get_config()
		{
			return m_vpos_config;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public int get_marshall_version()
		{
			int version = marshall_t.marshall_version;
			if (m_vpos_config != null)
				version = (((int)m_vpos_config.prot_ver_major) * 100) + m_vpos_config.prot_ver_minor;
			return version;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void OnKeepAliveTimerExpired(Object source, ElapsedEventArgs e)
		{
			long ms = Utils.currentTimeMillis();

			long last_tx_delta = ms - m_transmit_timestamp;
			long last_rx_delta = ms - m_receive_timestamp;


			if (true)
			{
				long delta = ms - m_last_tick_timestamp;

				if (delta > 500)
				{
					Log.d(TAG, String.Format("warning! sdk is not getting enough cpu! (starved for {0}ms", delta));
				}

				m_last_tick_timestamp = ms;
			}

			// keep-alive timer
			switch (m_marshall_link_state)
			{
				case vmc_link_state_init_e:
					break;
				case vmc_link_state_reset_e:
					break;
				case vmc_link_state_config_e:
				default:
                    // keep-alive, in case long enough we didn't receive anything
                    if (last_tx_delta > MARSHALL_RETRANSMIT_KA_INTERVAL)
                    {
                        // check if a re-transmission is required
                        if (m_pending_tx_msg != null)
						{
							if (m_pending_tx_msg_retries > 0)
							{
								Log.e(TAG, String.Format("retransmitting... last_rx: {0}, last_tx: {1}, attempts left: #{2}", last_rx_delta, last_tx_delta, m_pending_tx_msg_retries));

								m_i_f.dumpStats();

								m_pending_tx_msg_retries--;
                                
								byte retrans_num = (byte)(3 - m_pending_tx_msg_retries);

                                // clear tx index
								m_pending_tx_msg.options &= unchecked((byte)(~(int)(3 << 2)));
                                
                                // set tx index
								m_pending_tx_msg.options = (byte)((m_pending_tx_msg.options | (retrans_num << 2)));

                                // re-transmit
								transmit_marshall_raw(m_pending_tx_msg, (byte)m_pending_tx_msg.id, true);

								// handle stats
								m_link_stats.retrans++;
							}
							else
							{
								// failed transmitting message

                                // re-transmit again and again, we believe in every message!
								m_pending_tx_msg_retries = 3;
							}
						}
						else
						{
							// transmit keep-alive
							transmit_marshall(marshall_t.keepalive());
						}
					}
					break;
			}

            // check if link is still valid
            if (m_is_marshall_online)
            {
                int timeout = m_config.keepalive_interval_ms > MARSHALL_NO_COMM_TIMEOUT ? m_config.keepalive_interval_ms : MARSHALL_NO_COMM_TIMEOUT;
                if (last_rx_delta > timeout)
                {
                    Log.e(TAG, "link down");

					marshall_link_change_state(vmc_link_state_init_e);

					if (m_vmc_events != null)
						m_vmc_events.onCommError();

					// pass marshall messages to upper layers (socket / vending / etc)
					foreach (vmc_client_t client in m_clients)
					{
						client.onCommError();
					}


                    // handle stats
					m_link_stats.comm_loss++;
				}
			}

			// notify clients about timer tick
			foreach (vmc_client_t client in m_clients)
			{
				client.onTimerTick(ms);
			}

			m_i_f.onLinkTimerTick(ms);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void dump_packet(String title, marshall_t.msg_marshall_t msg, byte[] buf, int offset, int buf_len)
		{
			bool print = false;

			if (m_app_config.dump_packets_level == vmc_configuration.debug_level_dump_moderate)
			{
				/* dont print response for a keep-alive */
				if (m_pending_tx_msg != null)
				{
					if (msg.func_code == marshall_t.marshall_func_code_response && m_pending_tx_msg.func_code != marshall_t.marshall_func_code_keepalive)
						print = true;
				}
				/* dont print transmit keepalive */
				else if (msg.func_code != marshall_t.marshall_func_code_keepalive)
					print = true;

			}
			else if (m_app_config.dump_packets_level == vmc_configuration.debug_level_dump_all)
				print = true;

			if (print)
				Utils.dumpPacket(title, buf, offset, buf_len);
		}

	}
}