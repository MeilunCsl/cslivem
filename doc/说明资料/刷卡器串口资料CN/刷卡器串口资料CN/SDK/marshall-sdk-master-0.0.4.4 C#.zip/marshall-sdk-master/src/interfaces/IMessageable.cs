﻿namespace com.bitmick.marshall.interfaces
{
	public interface IMessageable
	{
		void notify(int what, object obj);
	}

}