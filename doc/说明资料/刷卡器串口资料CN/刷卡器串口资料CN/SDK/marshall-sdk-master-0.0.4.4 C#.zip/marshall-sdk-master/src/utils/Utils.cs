﻿using System;
using System.Text;

namespace com.bitmick.marshall.utils
{
    public static class Utils
	{

		// ===========================================================
		// Constants
		// ===========================================================

		private static readonly string TAG = typeof(Utils).Name;

        // ===========================================================
        // Fields
        // ===========================================================

        private static DateTime epoch = new DateTime(1970, 1, 1);

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        public static void clearPacket(byte[] arr, int offset, int len)
		{

			for (int i = 0; i < len; i++)
			{
				arr[offset + i] = 0;
			}
		}

		public static void dumpPacket(String title, byte[] arr, int offset, int len)
		{
			StringBuilder sb = new StringBuilder();

            sb.Append(title);
            sb.Append(":\n");

			for (int i = 0; i < len; i++)
			{
				if (i % 16 == 0 && i > 0)
				{
					sb.Append("\n");
				}

				sb.Append(string.Format("{0:x2}:", arr[offset + i]));
			}

            Log.d("", sb.ToString());
        }

        public static long currentTimeMillis()
        {         
			return DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
        }


    }

}