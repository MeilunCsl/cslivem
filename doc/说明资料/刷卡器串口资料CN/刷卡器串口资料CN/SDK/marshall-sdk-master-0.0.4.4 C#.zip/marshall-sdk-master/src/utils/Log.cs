﻿using System;
using System.IO;

namespace com.bitmick.marshall.utils
{
    public static class Log
    {

        public const int LOG_LEVEL_ERROR = 0;
        public const int LOG_LEVEL_WARNING = 1;
        public const int LOG_LEVEL_DEBUG = 2;
        public const int LOG_LEVEL_EVERYTHING = 4;

        private static String m_filter = null;

        // default: log everything, including debug warning and error messages
        private static int m_level = 0xFF;

        private static StreamWriter sw = null;
        private static long m_prev_log_ts = Utils.currentTimeMillis();

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void initialize(String filename)
        {
            // already opened
            if (sw != null)
                sw.Close();

            if (filename != null)
            {
                sw = File.AppendText(filename);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void filter(String tag)
        {
            m_filter = tag;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void level(int level)
        {
            m_level = level;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void close()
        {
            if (sw != null)
                sw.Close();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void d(String TAG, String message)
        {
            _log(LOG_LEVEL_DEBUG, TAG, message);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void l(String TAG, String message)
        {
            _log(LOG_LEVEL_EVERYTHING, TAG, message);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void w(String TAG, String message)
        {
            _log(LOG_LEVEL_WARNING, TAG, String.Format("*** warning: {0} ***", message));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void e(String TAG, String message)
        {
            _log(LOG_LEVEL_ERROR, TAG, String.Format("*** error: {0} ***", message));
        }
        
        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public static void _log(int level, String TAG, String message)
        {
            if ((level & m_level) != 0 && (m_filter == null || TAG.Contains(m_filter)))
            {
                long ts = Utils.currentTimeMillis();

                string f_msg = String.Format("(+{0}ms) {1}: {2}", (ts - m_prev_log_ts), TAG, message);
                Console.WriteLine(f_msg);

                m_prev_log_ts = ts;

                if (sw != null)
                {
                    sw.WriteLine(message);

                    sw.Flush();
                }
            }
        }

    }
}
