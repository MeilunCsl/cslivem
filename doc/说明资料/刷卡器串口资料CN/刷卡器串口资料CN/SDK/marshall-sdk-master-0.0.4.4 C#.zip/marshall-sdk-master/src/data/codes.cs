﻿
namespace com.bitmick.marshall.data
{
    public static class R
    {
        // vmc UART data received message
        public const int id_rx                       = 0x0001;
        public const int id_tx                       = 0x0002;

        // general messages
        public const int id_timer_expired            = 0x0000;
        public const int id_stop_thread              = 0xFFFF;
    }
}
