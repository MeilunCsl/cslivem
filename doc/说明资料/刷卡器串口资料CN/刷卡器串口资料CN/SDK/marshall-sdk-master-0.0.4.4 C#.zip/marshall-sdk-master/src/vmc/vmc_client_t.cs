using System;
using System.Threading;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.data;
    using com.bitmick.marshall.models;

	//////////////////////////////////////////////////////////////////////////////////////////////
	// class name:
	// notes:
	/////////////////////////////////////////////////////////////////////////////////////////////
	public abstract class vmc_client_t
	{

		// ===========================================================
		// Constants
		// ===========================================================

		private const int MAX_QUEUE_SIZE = 10;

		// ===========================================================
		// Fields
		// ===========================================================

		private LinkedList<MsgObject> m_delayed_queue;
        private BlockingCollection<MsgObject> m_msg_queue;
		private Thread m_client_thread;
		private bool m_client_thread_running;
		private long m_timer_counter_ms;

		// ===========================================================
		// Abstract methods
		// ===========================================================

		// ===========================================================
		// Constructors
		// ===========================================================

		// ===========================================================
		// Methods from SuperClass/Interfaces (and supporting methods)
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public vmc_client_t()
		{
			m_delayed_queue = new LinkedList<MsgObject>();
            m_msg_queue = new BlockingCollection<MsgObject>(MAX_QUEUE_SIZE);

			m_timer_counter_ms = 0;
		}

		// ===========================================================
		// Methods
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public virtual void start()
		{
			if (m_client_thread == null)
			{
				// start parsing thread
                m_client_thread = new Thread(new ThreadStart(client_thread_proc));

                m_client_thread.Start();
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public virtual void stop()
		{
			// stop vmc link thread
			if (m_client_thread != null)
			{
				notify(R.id_stop_thread, null);
				m_client_thread = null;
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void client_thread_proc()
		{
			m_client_thread_running = true;

			while (m_client_thread_running)
			{
				try
				{
					MsgObject msg = m_msg_queue.Take();

					if (msg != null)
					{
						if (!handleMessage(msg))
						{

						}
					}
				}
				catch (Exception) {}
			}
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        protected virtual bool handleMessage(MsgObject msg)
		{
			switch (msg.id)
			{
				case R.id_stop_thread:
					m_client_thread_running = false;
					break;
				default:
					break;
			}

			return true;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		protected void notify(int msg_id, object obj)
		{
			notify(msg_id, obj, 0);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        protected void notify(int msg_id, object obj, int timeout = 0)
		{
			MsgObject msg = new MsgObject();

			msg.id = msg_id;
			msg.data = obj;
			msg.timeout = timeout;

            m_msg_queue.Add(msg);
			}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        protected void notify_delayed(int msg_id, object obj, int timeout)
		{
			MsgObject msg = new MsgObject();

			msg.id = msg_id;
			msg.data = obj;
			msg.timeout = timeout;

            m_delayed_queue.AddLast(msg);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public virtual void onTimerTick(long ms)
		{
			long delta = ms - m_timer_counter_ms;

			// scan through delayed list, for pending msg objects
            foreach (MsgObject msg in m_delayed_queue)
			{
				msg.timeout -= delta;

				if (msg.timeout <= 0)
				{
					// remove from delayed queue
                    m_delayed_queue.Remove(msg);

					// add to immediate queue
                    m_msg_queue.Add(msg);
				}
			}

			m_timer_counter_ms = ms;
		}

		// ===========================================================
		// Public Methods
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public abstract void onReady(vmc_link link);

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public abstract void onCommError();

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public abstract bool handleMarshallMessage(marshall_t.msg_marshall_t msg);

	}
}