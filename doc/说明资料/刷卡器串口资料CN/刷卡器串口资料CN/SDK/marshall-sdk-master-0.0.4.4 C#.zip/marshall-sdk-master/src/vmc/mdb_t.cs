﻿namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.interfaces;
    using com.bitmick.marshall.utils;

    public class mdb_t
    {

        // ===========================================================
        // Constants
        // ===========================================================

        public static readonly byte mdb_dev_addr_cashless_a = (byte)0x10;
        public static readonly byte mdb_dev_addr_cashless_b = (byte)0x60;

        public static readonly byte mdb_master_addr = mdb_dev_addr_cashless_a;

        // ===========================================================
        // Sub Classes
        // ===========================================================

        // common structures , shared between mdb requests and responses

        /*
		 * msg_ftl_req_to_send_t
		 */
        public class msg_ftl_req_to_send_t : msg_i
        {

            public byte command;

            // ftl fields
            public byte src;
            public byte dst;
            public byte file_id;
            public byte len;
            public byte control;

            public msg_ftl_req_to_send_t()
            {
            }

            public msg_ftl_req_to_send_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                command = buf[index++];
                dst = buf[index]++;
                src = buf[index]++;
                file_id = buf[index]++;
                len = buf[index]++;
                control = buf[index]++;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = command;
                buf[index++] = dst;
                buf[index++] = src;
                buf[index++] = file_id;
                buf[index++] = len;
                buf[index++] = control;

                return index - enc_len;
            }
        }

        /*
		 * msg_ftl_req_to_send_t
		 */
        public class msg_ftl_req_to_receive_t : msg_i
        {

            // ftl fields
            public byte src;
            public byte dst;
            public byte file_id;
            public byte max_len;
            public byte control;

            public msg_ftl_req_to_receive_t()
            {
            }

            public msg_ftl_req_to_receive_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                dst = buf[index]++;
                src = buf[index]++;
                file_id = buf[index]++;
                max_len = buf[index]++;
                control = buf[index]++;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = dst;
                buf[index++] = src;
                buf[index++] = file_id;
                buf[index++] = max_len;
                buf[index++] = control;

                return index - enc_len;
            }
        }

        /*
		 * msg_ftl_req_to_send_t
		 */
        public class msg_ftl_ok_to_send_t : msg_i
        {

            // ftl fields
            public byte dst;
            public byte src;

            public msg_ftl_ok_to_send_t()
            {
            }

            public msg_ftl_ok_to_send_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                dst = buf[index]++;
                src = buf[index]++;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = dst;
                buf[index++] = src;

                return index - enc_len;
            }
        }

        /*
		 * msg_ftl_send_block_t
		 */
        public class msg_ftl_send_block_t : msg_i
        {

            // ftl fields
            public byte dst;
            public byte block_num;
            public byte[] data;

            public msg_ftl_send_block_t()
            {
            }

            public msg_ftl_send_block_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                //            dst = arr[index]++;
                //            block_num = arr[index]++;
                data = new byte[buf_len - index];
                index += ByteArrayUtils.byteArrToSubByteArray(buf, index, data);

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = dst;
                buf[index++] = block_num;
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, data);

                return index - enc_len;
            }
        }

        /*
		 * msg_ftl_req_to_send_t
		 */
        public class msg_ftl_retry_deny_t : msg_i
        {

            // ftl fields
            public byte dst;
            public byte src;
            public byte retry_delay;

            public msg_ftl_retry_deny_t()
            {
            }

            public msg_ftl_retry_deny_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                dst = buf[index]++;
                src = buf[index]++;
                retry_delay = buf[index++];

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = dst;
                buf[index++] = src;
                buf[index++] = retry_delay;

                return index - enc_len;
            }
        }

        /*
		 * msg_sessions_status_t
		 */
        public class msg_sessions_status_t : msg_i
        {
            public byte num_opened_sessions;
            public ushort[] sessions;

            public msg_sessions_status_t()
            {
                num_opened_sessions = 0;
                sessions = null;
            }

            public msg_sessions_status_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {
                int start_index = index;

                num_opened_sessions = buf[index]++;
                sessions = new ushort[num_opened_sessions];

                for (int i = 0; i < num_opened_sessions; i++)
                {
                    sessions[i] = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                }

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {
                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_reader_state_t
		 */
        public class msg_reader_state_t : msg_i
        {
            public byte state;

            public msg_reader_state_t()
            {
                state = 0;
            }

            public msg_reader_state_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {
                int start_index = index;

                state = buf[index]++;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {
                int enc_len = index;

                return index - enc_len;
            }
        }

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

    }

}