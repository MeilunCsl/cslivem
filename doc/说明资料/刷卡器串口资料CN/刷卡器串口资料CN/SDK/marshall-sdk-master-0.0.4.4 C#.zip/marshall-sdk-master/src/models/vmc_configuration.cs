﻿
using System.Collections.Generic;

namespace com.bitmick.marshall.models
{

    public class vmc_configuration
    {
        // ===========================================================
        // Constants
        // ===========================================================

        public const int machine_type_none = 0x00;
        public const int machine_type_type_reserved = 0x01;
        public const int machine_type_type_card_reader = 0x02;
        public const int machine_type_type_photo_booth = 0x03;
        public const int machine_type_type_default = 0x04;
        public const int machine_type_type_beverage = 0x05;
        public const int machine_type_type_water_filling = 0x06;
        public const int machine_type_type_locker = 0x07;
        public const int machine_type_type_retail = 0x08;
        public const int machine_type_type_laundry_machine = 0x09;
        public const int machine_type_type_ev_charger = 0x0b;
        public const int machine_type_type_paymarket = 0x0c;
        public const int machine_type_type_money = 0x010;

        public const int debug_level_dump_none = 0x00;
        public const int debug_level_dump_all = 0x01;
        public const int debug_level_dump_moderate = 0x02;

        public const int vend_denied_policy_cancel = 0x00;
        public const int vend_denied_policy_persist = 0x01;

        // ===========================================================
        // Fields
        // ===========================================================

        // following fields are decoded from the configuration text file

        public string port_vpos { get; set; }
        public int port_vpos_baud { get; set; }

        public string serial { get; set; }
        public string model { get; set; }
        public string sw_ver { get; set; }
        public int    machine_type { get; set; }

        public bool multi_session_support { get; set; }
        public bool multi_vend_support { get; set; }
        public bool always_idle { get; set; }

        public bool price_not_final_support { get; set; }
        public bool mag_card_approved_by_vmc_support { get; set; }
        public bool mifare_approved_by_vmc_support { get; set; }
        public bool reader_always_on { get; set; }
        public int  vend_denied_policy;


        public bool debug { get; set; }
        public int dump_packets_level;

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        public vmc_configuration()
        {
            port_vpos = "";
            port_vpos_baud = 115200;

            serial = "";
            model = "";
            sw_ver = "";

            multi_session_support = false;
            multi_vend_support = false;
            price_not_final_support = false;
            mag_card_approved_by_vmc_support = false;
            mifare_approved_by_vmc_support = false;
            reader_always_on = false;
            vend_denied_policy = vend_denied_policy_cancel;

            debug = false;
            dump_packets_level = debug_level_dump_none;
        }
        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        public void invalidate()
        {
        }
    }
   
}
