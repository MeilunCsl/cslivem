﻿using System.Collections.Generic;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.interfaces;
    using com.bitmick.marshall.utils;

    public class mdb_req_t : mdb_t
    {

        // ===========================================================
        // Constants
        // ===========================================================

        internal static readonly string TAG = typeof(mdb_req_t).Name;

        // command codes
        // each command code is the cashless addr + below command
        public const byte mdb_command_reset = (byte)0x00;
        public const byte mdb_command_setup = (byte)0x01;
        public const byte mdb_command_poll = (byte)0x02;
        public const byte mdb_command_vend = (byte)0x03;
        public const byte mdb_command_reader = (byte)0x04;
        public const byte mdb_command_revalue = (byte)0x05;
        public const byte mdb_command_expansion = (byte)0x07;

        // sub commands
        public const byte mdb_sub_command_setup_config_data = (byte)0x00;
        public const byte mdb_sub_command_setup_max_min_prices = (byte)0x01;

        public const byte mdb_sub_command_vend_request = (byte)0x00;
        public const byte mdb_sub_command_vend_cancel = (byte)0x01;
        public const byte mdb_sub_command_vend_success = (byte)0x02;
        public const byte mdb_sub_command_vend_failure = (byte)0x03;
        public const byte mdb_sub_command_vend_session_complete = (byte)0x04;
        public const byte mdb_sub_command_vend_cash_sale = (byte)0x05;
        public const byte mdb_sub_command_vend_negative_req = (byte)0x06;
        public const byte mdb_sub_command_selection_denied = (byte)0x07; // mdb 4.3, page 170, 213-214
        public const byte mdb_sub_command_vend_close_session = unchecked((byte)0x80);
        public const byte mdb_sub_command_vend_session_type = unchecked((byte)0x81);
        public const byte mdb_sub_command_multivend_request = (byte)0x82;
        public const byte mdb_sub_command_prepaid_pay = (byte)0x83;
        public const byte mdb_sub_command_multivend_success = (byte)0x84;
        public const byte mdb_sub_command_get_sessions_status = (byte)0x85;

        public const byte mdb_sub_command_reader_disable = (byte)0x00;
        public const byte mdb_sub_command_reader_enable = (byte)0x01;
        public const byte mdb_sub_command_reader_cancel = (byte)0x02;
        public const byte mdb_sub_command_reader_data_entry_rsp = (byte)0x03;
        public const byte mdb_sub_command_reader_state_req = (byte)0x87;

        public const byte mdb_sub_command_revalue_request = (byte)0x00;
        public const byte mdb_sub_command_revalue_limit_request = (byte)0x01;

        public const byte mdb_sub_command_expansion_request_id = (byte)0x00;
        public const byte mdb_sub_command_expansion_rd_user_file = (byte)0x01;
        public const byte mdb_sub_command_expansion_wr_user_file = (byte)0x02;
        public const byte mdb_sub_command_expansion_wr_time_date = (byte)0x03;
        public const byte mdb_sub_command_expansion_opt_feature_en = (byte)0x04;
        public const byte mdb_sub_command_expansion_ftl_req_to_rcv = unchecked((byte)0xfa);
        public const byte mdb_sub_command_expansion_ftl_retry_deny = unchecked((byte)0xfb);
        public const byte mdb_sub_command_expansion_ftl_send_block = unchecked((byte)0xfc);
        public const byte mdb_sub_command_expansion_ftl_ok_to_send = unchecked((byte)0xfd);
        public const byte mdb_sub_command_expansion_ftl_req_to_send = unchecked((byte)0xfe);
        public const byte mdb_sub_command_expansion_ftl_diagnostics = unchecked((byte)0xff);

        public const byte mdb_close_session_status_ok = (byte)0x00;
        public const byte mdb_close_session_status_user_cancel = (byte)0x01;
        public const byte mdb_close_session_status_fail_to_dispense = (byte)0x02;

        // ===========================================================
        // Sub Classes
        // ===========================================================

        /*
         * msg_mdb_req_t
         */
        public class msg_mdb_req_t : msg_i
        {

            public byte command;
            public msg_i body;

            public msg_mdb_req_t(byte c, msg_i b)
            {
                command = c;
                body = b;
            }

            public msg_mdb_req_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                command = (byte)(buf[index++] - mdb_master_addr);

                body = null;

                switch (command)
                {
                    case mdb_command_reset:
                        body = new msg_reset_t();
                        break;
                    case mdb_command_setup:
                        // peep at sub command
                        byte sub_command = buf[index];
                        if (sub_command == mdb_sub_command_setup_config_data)
                        {
                            body = new msg_setup_config_data_t();
                        }
                        else
                        {
                            body = new msg_setup_max_min_prices_t();
                        }
                        break;
                    case mdb_command_poll:
                        body = new msg_poll_t();
                        break;
                    case mdb_command_vend:
                        body = new msg_vend_t();
                        break;
                    case mdb_command_reader:
                        body = new msg_reader_t();
                        break;
                    case mdb_command_revalue:
                        break;
                    case mdb_command_expansion:
                        break;
                    default:
                        break;
                }

                if (body != null)
                {
                    index += body.decode(buf, index, buf_len - index);
                }

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = (byte)(mdb_master_addr + command);

                if (body != null)
                {
                    index += body.encode(buf, index, buf_len - index);
                }

                return index - enc_len;
            }
        }

        /*
         * msg_reset_t
         */
        public class msg_reset_t : msg_i
        {


            public msg_reset_t()
            {
            }

            public msg_reset_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
         * msg_reader_t
         */
        public class msg_reader_t : msg_i
        {

            public byte data;

            public msg_reader_t()
            {
            }

            public msg_reader_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                data = buf[index++];

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = data;

                return index - enc_len;
            }
        }

        /*
         * msg_setup_config_data_t
         */
        public class msg_setup_config_data_t : msg_i
        {

            public byte sub_command;
            public byte feature_level;
            public byte cols_on_display;
            public byte rows_on_display;
            public byte display_info;

            public msg_setup_config_data_t()
            {
            }

            public msg_setup_config_data_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                sub_command = buf[index++];
                feature_level = buf[index++];
                cols_on_display = buf[index++];
                rows_on_display = buf[index++];
                display_info = buf[index++];

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                sub_command = mdb_sub_command_setup_config_data;

                buf[index++] = sub_command;
                buf[index++] = feature_level;
                buf[index++] = cols_on_display;
                buf[index++] = rows_on_display;
                buf[index++] = display_info;

                return index - enc_len;
            }
        }

        /*
         * msg_setup_max_min_prices_t
         */
        public class msg_setup_max_min_prices_t : msg_i
        {

            public byte sub_command;
            public ushort max_price;
            public ushort min_price;
            public ushort currency_code;

            // not encoded/decoded. just used to signal wheter currency code is encoded/decoded
            public bool expanded_mode;

            public msg_setup_max_min_prices_t()
            {
            }

            public msg_setup_max_min_prices_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                sub_command = buf[index++];
                max_price = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                min_price = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                if (expanded_mode)
                {
                    currency_code = ByteArrayUtils.byteArrToShort(buf, index);
                }
                index += 2;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                sub_command = mdb_sub_command_setup_max_min_prices;

                index += ByteArrayUtils.shortToByteArray(buf, index, max_price);
                index += ByteArrayUtils.shortToByteArray(buf, index, min_price);

                if (expanded_mode)
                {
                    index = +ByteArrayUtils.shortToByteArray(buf, index, currency_code);
                }

                return index - enc_len;
            }
        }

        /*
         * msg_poll_t
         */
        public class msg_poll_t : msg_i
        {

            public msg_poll_t()
            {
            }

            public msg_poll_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
         * msg_vend_t
         */
        public class msg_vend_t : msg_i
        {

            public byte sub_command;
            public ushort item_price;
            public ushort item_number;

            // nayax addition to multi-session mdb
            public byte status;
            public int quantity;
            public byte unit_of_measure;

            public msg_vend_t()
            {
            }

            public msg_vend_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                sub_command = buf[index++];
                item_price = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                item_number = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;

                switch (sub_command)
                {
                    case mdb_sub_command_vend_request:
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_price);
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_number);
                        break;
                    case mdb_sub_command_vend_cancel:
                        break;
                    case mdb_sub_command_vend_success:
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_number);
                        break;
                    case mdb_sub_command_vend_failure:
                        break;
                    case mdb_sub_command_vend_session_complete:
                        break;
                    case mdb_sub_command_vend_cash_sale:
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_price);
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_number);
                        break;
                    case mdb_sub_command_vend_negative_req:
                        break;
                    case mdb_sub_command_vend_close_session:
                        buf[index++] = status;
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_price);
                        index += ByteArrayUtils.shortToByteArray(buf, index, item_number);
                        index += ByteArrayUtils.intToByteArray(buf, index, quantity);
                        buf[index++] = unit_of_measure;
                        break;
                    case mdb_sub_command_get_sessions_status:
                        break;
                    default:
                        break;
                }

                return index - enc_len;
            }
        }

        public class msg_ex_t : msg_i
        {

            public byte sub_command;
            public byte type;


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                sub_command = buf[index++];
                type = buf[index++];

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;
                buf[index++] = type;

                return index - enc_len;
            }
        }

        /*
         * msg_ex_selection_denied_t
         */
        public class msg_ex_selection_denied_t : msg_i
        {

        public byte sub_command;
        public ushort item_number;
        public byte reason;

        public override int decode(byte[] buf, int index, int buf_len)
        {

            int start_index = index;

            sub_command = buf[index++];
            item_number = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
            reason = buf[index++];

            return index - start_index;
        }

        public override int encode(byte[] buf, int index, int buf_len)
        {

            int enc_len = index;

            buf[index++] = sub_command;
            index += ByteArrayUtils.shortToByteArray(buf, index, item_number);
            buf[index++] = reason;

            return index - enc_len;
        }
    }

    /*
     * msg_ex_pay_t
     */
    public class msg_ex_pay_t : msg_i
        {
            public byte sub_command;
            public byte[] pp_number;


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, pp_number);

                return index - enc_len;
            }
        }

        /*
         * msg_ex_multi_vend_req_t
         */
        public class msg_ex_multi_vend_req_t : msg_i
        {

            public class prod_item_t
            {
                public ushort code;
                public ushort price;
                public int    qty;
                public byte   unit;

                public prod_item_t(ushort _code, ushort _price, int _qty, byte _unit)
                {
                    code = _code;
                    price = _price;
                    qty = _qty;
                    unit = _unit;
                }
            }

            public byte sub_command;
            public List<prod_item_t> list;

            public msg_ex_multi_vend_req_t()
            {
                list = new List<prod_item_t>();
            }

            public void add(ushort _code, ushort _price, int _qty, byte _unit)
            {
                list.Add(new prod_item_t(_code, _price, _qty, _unit));
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;
                foreach (prod_item_t item in list)
                {
                    index += ByteArrayUtils.shortToByteArray(buf, index, item.code);
                    index += ByteArrayUtils.shortToByteArray(buf, index, item.price);
                    index += ByteArrayUtils.intToByteArray(buf, index, item.qty);
                    buf[index++] = item.unit;
                }

                return index - enc_len;
            }
        }

        /*
         * msg_ex_multi_vend_success_t
         */
        public class msg_ex_multi_vend_success_t : msg_i
        {

            public byte sub_command;
            public List<prod_item_t> list;

            public class prod_item_t
            {
                public ushort code;
                public ushort price;
                public int qty;
                public byte unit;

                public prod_item_t(ushort _code, ushort _price, int _qty, byte _unit)
                {
                    code = _code;
                    price = _price;
                    qty = _qty;
                    unit = _unit;
                }
            }

            public msg_ex_multi_vend_success_t()
            {
                list = new List<prod_item_t>();
            }

            public void add(ushort _code, ushort _price, int _qty, byte _unit)
            {
                list.Add(new prod_item_t(_code, _price, _qty, _unit));
            }

            
        public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            
        public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;
                foreach (prod_item_t item in list)
                {
                    index += ByteArrayUtils.shortToByteArray(buf, index, item.code);
                    index += ByteArrayUtils.shortToByteArray(buf, index, item.price);
                    index += ByteArrayUtils.intToByteArray(buf, index, item.qty);
                    buf[index++] = item.unit;
                }

                return index - enc_len;
            }
        }


        /*
         * msg_expansion_t
         */
        public class msg_expansion_t : msg_i
        {

            internal byte sub_command;

            internal msg_i body;

            public msg_expansion_t()
            {
            }

            public msg_expansion_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                sub_command = buf[index++];

                switch (sub_command)
                {
                    case mdb_sub_command_expansion_ftl_req_to_send:
                        body = new mdb_t.msg_ftl_req_to_send_t();
                        break;
                    case mdb_sub_command_expansion_ftl_ok_to_send:
                        body = new mdb_t.msg_ftl_ok_to_send_t();
                        break;
                    case mdb_sub_command_expansion_ftl_send_block:
                        body = new mdb_t.msg_ftl_send_block_t();
                        break;
                    case mdb_sub_command_expansion_ftl_req_to_rcv:
                        body = new mdb_t.msg_ftl_req_to_receive_t();
                        break;
                    case mdb_sub_command_expansion_ftl_retry_deny:
                        break;
                    default:
                        break;
                }

                index += body.decode(buf, index, buf_len - index);

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = sub_command;
                index += body.encode(buf, index, buf_len - index);

                return index - enc_len;
            }
        }

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        public static msg_mdb_req_t pool_req()
        {
            mdb_req_t.msg_poll_t msg_poll = new mdb_req_t.msg_poll_t();

            return new msg_mdb_req_t(mdb_command_poll, msg_poll);
        }

        public static msg_mdb_req_t reader_req(byte reader_option)
        {
            mdb_req_t.msg_reader_t msg_reader = new mdb_req_t.msg_reader_t();
            msg_reader.data = reader_option;

            return new msg_mdb_req_t(mdb_command_reader, msg_reader);
        }

        public static msg_mdb_req_t vend_req(byte sub_command, ushort item_price, ushort item_number)
        {
            mdb_req_t.msg_vend_t msg_vend = new mdb_req_t.msg_vend_t();

            msg_vend.sub_command = sub_command;
            msg_vend.item_price = item_price;
            msg_vend.item_number = item_number;

            return new msg_mdb_req_t(mdb_command_vend, msg_vend);
        }

        public static msg_mdb_req_t mdb_ex(byte sub_command, byte type)
        {
            mdb_req_t.msg_ex_t msg_ex = new mdb_req_t.msg_ex_t();

            msg_ex.sub_command = sub_command;
            msg_ex.type = type;

            return new msg_mdb_req_t(mdb_command_vend, msg_ex);
        }

        public static msg_mdb_req_t mdb_vend_selection_denied(byte sub_command, ushort product_code, byte reason)
        {
            mdb_req_t.msg_ex_selection_denied_t msg_ex = new mdb_req_t.msg_ex_selection_denied_t();

            msg_ex.sub_command = sub_command;
            msg_ex.item_number = product_code;
            msg_ex.reason = reason;

            return new msg_mdb_req_t(mdb_command_vend, msg_ex);
        }

        public static msg_mdb_req_t expansion_ftl_req_to_send(byte src, byte dst, byte file_id, byte length, byte control)
        {
            mdb_t.msg_ftl_req_to_send_t req = new msg_ftl_req_to_send_t();
            req.src = src;
            req.dst = dst;
            req.file_id = file_id;
            req.len = length;
            req.control = control;

            msg_expansion_t exp = new msg_expansion_t();
            exp.sub_command = mdb_sub_command_expansion_ftl_req_to_send;
            exp.body = req;

            return new msg_mdb_req_t(mdb_command_expansion, req);
        }

        public static msg_mdb_req_t expansion_ftl_ok_to_send(byte src, byte dst)
        {

            mdb_t.msg_ftl_ok_to_send_t req = new msg_ftl_ok_to_send_t();
            req.src = src;
            req.dst = dst;

            msg_expansion_t exp = new msg_expansion_t();
            exp.sub_command = mdb_sub_command_expansion_ftl_ok_to_send;
            exp.body = req;

            return new msg_mdb_req_t(mdb_command_expansion, req);
        }


        public static msg_mdb_req_t expansion_ftl_send_block(byte dst, byte block_num, byte[] data)
        {

            mdb_t.msg_ftl_send_block_t req = new msg_ftl_send_block_t();
            req.dst = dst;
            req.block_num = block_num;
            req.data = data;

            msg_expansion_t exp = new msg_expansion_t();
            exp.sub_command = mdb_sub_command_expansion_ftl_send_block;
            exp.body = req;

            return new msg_mdb_req_t(mdb_command_expansion, exp);
        }

        public static msg_mdb_req_t expansion_ftl_retry_deny(byte src, byte dst, byte retry_delay)
        {

            mdb_t.msg_ftl_retry_deny_t req = new msg_ftl_retry_deny_t();
            req.src = src;
            req.dst = dst;
            req.retry_delay = retry_delay;

            msg_expansion_t exp = new msg_expansion_t();
            exp.sub_command = mdb_sub_command_expansion_ftl_retry_deny;
            exp.body = exp;

            return new msg_mdb_req_t(mdb_command_expansion, req);
        }

        public static msg_mdb_req_t expansion_ftl_req_to_receive(byte src, byte dst, byte file_id, byte max_length, byte control)
        {

            mdb_t.msg_ftl_req_to_receive_t req = new msg_ftl_req_to_receive_t();
            req.src = src;
            req.dst = dst;
            req.file_id = file_id;
            req.max_len = max_length;
            req.control = control;

            msg_expansion_t exp = new msg_expansion_t();
            exp.sub_command = mdb_sub_command_expansion_ftl_req_to_rcv;
            exp.body = req;

            return new msg_mdb_req_t(mdb_command_expansion, exp);
        }
    }
}