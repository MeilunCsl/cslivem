﻿namespace com.bitmick.marshall.interfaces
{
	public abstract class lowlevel_i
	{
        // this interface represents all the platform requirements in order
        // for the sdk to work properly:
        //     - timer
        //     - serial port

        public interface link_events_t
        {

            //////////////////////////////////////////////////////////////////////////////////////////////
            // function name:
            // input:
            // output:
            // notes:
            /////////////////////////////////////////////////////////////////////////////////////////////
            bool onReceive(byte[] data, int offset, int len);
        }

        // ===========================================================
        // Constants
        // ===========================================================

        // ===========================================================
        // enums
        // ===========================================================

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        // methods
        public abstract void init(object i_f, object i_f_params);
        public abstract void register_link_events(link_events_t events);
        public abstract void start();
        public abstract void stop();
		public abstract void restart();
		public abstract void dumpStats();
        public abstract bool transmit(byte[] data, int len);
        public abstract void onLinkTimerTick(long ms);
    }
}