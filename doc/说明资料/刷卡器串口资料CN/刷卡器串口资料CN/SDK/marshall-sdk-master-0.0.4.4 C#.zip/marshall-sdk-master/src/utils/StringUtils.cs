﻿using System;

namespace com.bitmick.marshall.utils
{

	public class StringUtils
	{


		// ===========================================================
		// Constants
		// ===========================================================

		internal static readonly string TAG = typeof(StringUtils).Name;

        internal static readonly char[] hex_array = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        //  abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================


        public static String byteArray2String(byte[] buf)
        {
            String str = null;
            int length = -1;
            // find null terminate character
            for (int i = 0; i < buf.Length; i++)
            {
                if (buf[i] == 0)
                {
                    length = i;
                    break;
                }
            }

            if (length > 0)
                str = System.Text.Encoding.Default.GetString(buf, 0, length);

            return str;
        }

        public static int atoi(string s, int offset)
		{
			int neg = 1;
			int n = 0;

			// check for minus prefix
			if (s[offset] == '-')
			{
				n = -1;
				offset++;
			}

			// parse number
			while (offset < s.Length && char.IsDigit(s[offset]))
			{
				n = (n * 10) + (s[offset] - '0');
				offset++;
			}

			return n * (neg);
		}

		public static string int2Str(int i)
		{
			return Convert.ToString(i);
		}

		public static string float2Str(float f)
		{
			return Convert.ToString(f);
		}

		public static string paddingStringRight(string @string, int length)
		{
			return string.Format("%1$-" + length + "s", @string);
		}

        public static String buf2hex_str(byte[] buf)
        {
            char[] char_array = new char[buf.Length * 2];

            for (int i = 0, j = 0; i < buf.Length; i++)
            {
                int b = buf[i] & 0x00FF;
                byte low_nibble = (byte)(b & 0x0F);
                byte hi_nibble = (byte)(b >> 4);

                char_array[j++] = hex_array[hi_nibble];
                char_array[j++] = hex_array[low_nibble];
            }

            return new String(char_array);
        }
		public static string reverse(string s)
		{
			char[] charArray = s.ToCharArray();
			Array.Reverse(charArray);
			return new string(charArray);
		}
	}
}