using app;
using com.bitmick.marshall.models;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.utils;

    //////////////////////////////////////////////////////////////////////////////////////////////
    // class name:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    public class vmc_general_t : vmc_client_t
    {
        // ===========================================================
        // Constants
        // ===========================================================

        internal static readonly string TAG = typeof(vmc_general_t).Name;

        public interface GeneralEvents
        {
            void onDCSParamChange(int dcs_param, byte[] data);
            void onTransferData(byte[] data);
            void onDisplayEventButtonPressed(byte button_id);
            void onDisplayEventTextInput(string input);

            void onTimeUpdate(
                    byte year,
                    byte month,
                    byte day,
                    byte hours,
                    byte minutes,
                    byte seconds);
        }

        // ===========================================================
        // Fields
        // ===========================================================

        private vmc_link m_vmc_link;

        private GeneralEvents m_general_events;

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void onReady(vmc_link link)
        {
            m_vmc_link = link;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void onCommError()
        {
            m_vmc_link = null;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override bool handleMarshallMessage(marshall_t.msg_marshall_t msg)
        {
            switch (msg.func_code)
            {
                case marshall_t.marshall_func_code_set_periph_param:
                    marshall_t.msg_set_periph_param_t periph_param = (marshall_t.msg_set_periph_param_t)msg.body;
                    if (m_general_events != null)
                        m_general_events.onDCSParamChange(periph_param.dcs_code, periph_param.data);
                    break;
                case marshall_t.marshall_func_code_get_time_rsp:
                    marshall_t.msg_time_rsp_t time_rsp = (marshall_t.msg_time_rsp_t)msg.body;
                    if (m_general_events != null)
                    {
                        m_general_events.onTimeUpdate(
                                time_rsp.year,
                                time_rsp.month,
                                time_rsp.day,
                                time_rsp.hours,
                                time_rsp.minutes,
                                time_rsp.seconds);
                    }
                    break;
                case marshall_t.marshall_func_code_display_event:
                    marshall_t.msg_display_event_t display_event = (marshall_t.msg_display_event_t)msg.body;

                    Log.d(TAG, string.Format("display event: {0} clicks", display_event.buttons.Count));

                    if (m_general_events != null)
                    {
                        foreach (byte button in display_event.buttons)
                            m_general_events.onDisplayEventButtonPressed(button);

                        foreach (string text in display_event.text)
                            m_general_events.onDisplayEventTextInput(text);
                    }
                    break;
                case marshall_t.marshall_func_code_display_msg_status:
                    marshall_t.msg_display_msg_status_t display_status = (marshall_t.msg_display_msg_status_t)msg.body;

                    Log.d(TAG, string.Format("display message status: {0}", display_status.status));
                    break;
                default:
                    break;
            }

            return false;
        }

        // ===========================================================
        // Methods
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void register_callbacks(GeneralEvents events)
        {
            m_general_events = events;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void alert(ushort id, string msg)
        {
            m_vmc_link.transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_alert, marshall_t.marshall_packet_option_ack_mask, new marshall_t.msg_alert_t(id, msg)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void reuqest_time()
        {
            m_vmc_link.transmit_marshall(marshall_t.request((byte)marshall_t.marshall_func_code_get_time_req, (byte)marshall_t.marshall_packet_option_ack_mask, new marshall_t.msg_time_req_t()));

        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void set_display_text(string text, ushort picture_file_id, ushort audio_file_idf)
        {
            m_vmc_link.transmit_marshall(marshall_t.request((byte)marshall_t.marshall_func_code_display_msg, (byte)marshall_t.marshall_packet_option_ack_mask, new marshall_t.msg_display_msg_t(text, picture_file_id, audio_file_idf)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output: return context of layout, to be used with add_label and add_button functions
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public object display_control_create_layout(int layout_id)
        {
            marshall_t.msg_display_control_t.layout_t layout = new marshall_t.msg_display_control_t.layout_t(layout_id);

            return layout;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public object display_control_layout_add_label(object context, int obj_id, int in_layout_id, string label)
        {
            if (context is marshall_t.msg_display_control_t.layout_t)
            {
                marshall_t.msg_display_control_t.layout_t layout = (marshall_t.msg_display_control_t.layout_t)context;

                marshall_t.msg_display_control_t.label_t label_obj = new marshall_t.msg_display_control_t.label_t(obj_id, in_layout_id, label);

                layout.add(label_obj);
            }
            else
            {
                // in case provided wrong context, return null
                context = null;
            }

            return context;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public object display_control_layout_add_button(object context, int button_id)
        {
            if (context is marshall_t.msg_display_control_t.layout_t)
            {
                marshall_t.msg_display_control_t.layout_t layout = (marshall_t.msg_display_control_t.layout_t)context;

                layout.add((byte)button_id);
            }
            else
            {
                // in case provided wrong context, return null
                context = null;
            }

            return context;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void display_control_apply_layout(object context)
        {
            if (m_vmc_link != null)
            {
                if (context is marshall_t.msg_display_control_t.layout_t)
                {
                    marshall_t.msg_display_control_t.layout_t layout = (marshall_t.msg_display_control_t.layout_t)context;

                    marshall_t.msg_display_control_t display = new marshall_t.msg_display_control_t();
                    display.add(layout);

                    m_vmc_link.transmit_marshall(marshall_t.request((byte)marshall_t.marshall_func_code_display_control, (byte)marshall_t.marshall_packet_option_ack_mask, display));
                }
            }
        }

    }
}