using System;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.interfaces;
    using com.bitmick.marshall.utils;
    using System.Collections.Generic;

    public class marshall_t
    {
        // Notes:
        // all strings in the marshall protocols should be instatiated with "UTF-8" format

        // ===========================================================
        // static finalants
        // ===========================================================


        internal static readonly string TAG = typeof(marshall_t).Name;

        public const int MARSHALL_MSG_MAX_SIZE = 512;

        public const byte marshall_addr_bcast = unchecked((byte)0xff);
        public const byte vpos_address = (byte)0x00;

        // marshall version to negotiate against the vpos
        public const ushort marshall_version = (ushort)0x0200;

        public const byte marshall_packet_option_none = (byte)0x00;
        public const byte marshall_packet_option_ack_mask = (byte)0x01;
        public const byte marshall_packet_option_encrypt_mask = (byte)0x02;
        public const byte marshall_packet_option_retry_num_mask = (byte)0x0c;
        public const byte marshall_packet_option_rfu_mask = unchecked((byte)0xf0);

        public const byte marshall_func_code_response = (byte)0x00;
        public const byte marshall_func_code_reset = (byte)0x01;
        public const byte marshall_func_code_fw_info = (byte)0x05;
        public const byte marshall_func_code_config = (byte)0x06;
        public const byte marshall_func_code_keepalive = (byte)0x07;
        public const byte marshall_func_code_display_msg = (byte)0x08;
        public const byte marshall_func_code_display_msg_status = (byte)0x09;
        public const byte marshall_func_code_trasfer_data = (byte)0x0a;
        public const byte marshall_func_code_status = (byte)0x0b;
        public const byte marshall_func_code_get_time_req = (byte)0x0c;
        public const byte marshall_func_code_get_time_rsp = (byte)0x0d;
        public const byte marshall_func_code_set_periph_param = (byte)0x0e;
        public const byte marshall_func_code_ereceipt_e = (byte)0x11;
        public const byte marshall_func_code_display_control = (byte)0x14;
        public const byte marshall_func_code_display_event = (byte)0x15;
        public const byte marshall_func_code_modem_status = (byte)0x20;
        public const byte marshall_func_code_open_socket = (byte)0x21;
        public const byte marshall_func_code_close_socket = (byte)0x22;
        public const byte marshall_func_code_socket_send_data = (byte)0x23;
        public const byte marshall_func_code_socket_rcv_data = (byte)0x24;
        public const byte marshall_func_code_modem_rx_control = (byte)0x25;
        public const byte marshall_func_code_trace = (byte)0x30;
        public const byte marshall_func_code_alert = (byte)0x31;
        public const byte marshall_func_code_mdb_command = unchecked((byte)0x80);
        public const byte marshall_func_code_reader_command = (byte)0x91;

        public const byte marshall_transfer_data_transaction_id = (byte)0x01;
        public const byte marshall_transfer_data_choose_prod_timeout = (byte)0x02;
        public const byte marshall_transfer_data_card_type = (byte)0x03;
        public const byte marshall_transfer_data_card_entry_mode = (byte)0x04;
        public const byte marshall_transfer_data_card_bin = (byte)0x05;
        public const byte marshall_transfer_data_card_bin_hash = (byte)0x06;
        public const byte marshall_transfer_data_prop_card_uid = (byte)0x07;
        public const byte marshall_transfer_data_vmc_auth_status = (byte)0x08;
        public const byte marshall_transfer_data_com_status = (byte)0x09;
        public const byte marshall_transfer_data_excel_type = (byte)0x0a;
        public const byte marshall_transfer_data_cc_last_4_digits = (byte)0x0d;
        public const byte marshall_transfer_data_product_code = (byte)0x0e;
        public const byte marshall_transfer_data_product_price = (byte)0x0f;

        public const byte entry_type_msr_swipe_card_e = 0x01;
        public const byte entry_type_contactless_card_e = 0x02;
        public const byte entry_type_contact_card_e = 0x03;
        public const byte entry_type_mifare_card_e = 0x04;
        public const byte entry_type_hid_card_e = 0x05;
        public const byte entry_type_nfc_card_e = 0x06;
        public const byte entry_type_cnous_card_e = 0x07;
        public const byte entry_type_keypad_e = 0x08;
        public const byte entry_type_mobile_e = 0x09;
        public const byte entry_type_qr_e = 0x0a;
        public const byte entry_type_ble_e = 0x0b;


        public const byte status_unexpected_error = 0;
        public const byte status_unexpected_timeout = 1;
        public const byte status_unexpected_out_of_seq = 2;
        public const byte status_unexpected_pending_3rd_party_rcvd = 3;
        public const byte status_settlement = 4;
        public const byte status_machine_status = 5;
        public const byte status_ftp_status = 6;
        public const byte status_vpos_call_your_bank = 54;
        public const byte status_vpos_card_error = 56;
        public const byte status_vpos_insert_card = 61;
        public const byte status_vpos_not_accepted = 62;
        public const byte status_vpos_processing_error = 65;
        public const byte status_vpos_please_remove_card = 66;
        public const byte status_vpos_please_use_chip = 67;
        public const byte status_vpos_please_use_mag = 68;
        public const byte status_vpos_try_again = 69;
        public const byte status_vpos_present_card = 71;
        public const byte status_vpos_card_read_ok_please_remove_card = 73;
        public const byte status_vpos_please_insert_or_swipe_card = 74;
        public const byte status_vpos_please_present_one_card_only = 75;
        public const byte status_vpos_try_another_card = 78;
        public const byte status_vpos_please_insert_card = 79;
        public const byte status_vpos_see_phone_for_instructions = 82;
        public const byte status_vpos_present_card_again = 83;
        public const byte status_vpos_insert_or_swipe_another_card = 84;


        public const byte marshall_display_control_layout_id_tag = (byte)0x01;
        public const byte marshall_display_control_label_tag = (byte)0x02;
        public const byte marshall_display_control_button_id_tag = (byte)0x03;

        public const byte marshalll_display_control_button_id_left_arrow = 100;
        public const byte marshalll_display_control_button_id_menu = 101;
        public const byte marshalll_display_control_button_id_right_arrow = 102;
        public const byte marshalll_display_control_button_id_cancel = 103;
        public const byte marshalll_display_control_button_id_back = 104;
        public const byte marshalll_display_control_button_id_enter_ok = 105;
        public const byte marshalll_display_control_button_id_touch = 106;

        public const ushort POLYNOMIAL_CCITT = 0x1021; // x^16 + x^12 + x^5 + 1
        public const ushort SEED_CCITT = 0;

        // ===========================================================
        // Sub Classes
        // ===========================================================

        /*
        * msg_header_t
        */
        public class msg_marshall_t : msg_i
        {

            public ushort packet_len;
            public byte options;
            public byte id;
            public byte source;
            public byte source_lsb;
            public byte dest;
            public byte dest_lsb;
            public byte func_code;
            public msg_i body;
            public ushort crc16;


            public msg_marshall_t()
            {
            }

            public msg_marshall_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                // decode header
                packet_len = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                options = buf[index++];
                id = buf[index++];
                source = buf[index++];
                source_lsb = buf[index++];
                dest = buf[index++];
                dest_lsb = buf[index++];
                func_code = buf[index++];

                if (packet_len < 0)
                {
                    return -1;
                }

                crc16 = ByteArrayUtils.byteArrToShort(buf, starting_index + packet_len);

                int test_crc = (((int)Calc_CRC_CCITT(buf, starting_index, packet_len, SEED_CCITT)) & 0xffff);
                int rx_crc = (((int)crc16) & 0xffff);

                if (rx_crc != test_crc)
                {
                    Log.d(TAG, String.Format("wrong crc on packet({0}), index: {1}, length: {2}, crc_rx: {3}, crc_calc: {4}", (((int)id) & 0xff), starting_index, packet_len, rx_crc, test_crc));
                    return -1;
                }


                //Log.d(TAG, string.Format("received code: {0}, ack: {1}, id: {2}", func_code, options & marshall_packet_option_ack_mask, id));

                body = null;
                switch (func_code)
                {
                    case marshall_func_code_response:
                        body = new msg_response_t();
                        break;
                    case marshall_func_code_reset:
                        body = new msg_reset_t();
                        break;
                    case marshall_func_code_fw_info:
                        body = new msg_fw_info_t();
                        break;
                    case marshall_func_code_config:
                        body = new msg_config_t();
                        break;
                    case marshall_func_code_keepalive:
                        body = new msg_keepalive_t();
                        break;
                    case marshall_func_code_display_msg:
                        Log.d(TAG, "unsupported: marshall_func_code_display_msg");
                        break;
                    case marshall_func_code_display_msg_status:
                        body = new msg_display_msg_status_t();
                        break;
                    case marshall_func_code_trasfer_data:
                        body = new msg_transfer_data_t();
                        break;
                    case marshall_func_code_status:
                        body = new msg_status_t();
                        break;
                    case marshall_func_code_get_time_req:
                        Log.d(TAG, "unsupported: marshall_func_code_get_time_req");
                        break;
                    case marshall_func_code_get_time_rsp:
                        body = new msg_time_rsp_t();
                        break;
                    case marshall_func_code_set_periph_param:
                        body = new msg_set_periph_param_t();
                        break;
                    case marshall_func_code_ereceipt_e:
                        body = new msg_ereceipt_t();
                        break;
                    case marshall_func_code_display_control:
                        body = new msg_display_control_t();
                        break;
                    case marshall_func_code_display_event:
                        body = new msg_display_event_t();
                        break;
                    case marshall_func_code_modem_status:
                        body = new msg_modem_status_t();
                        break;
                    case marshall_func_code_open_socket:
                        body = new msg_open_socket_t();
                        break;
                    case marshall_func_code_close_socket:
                        body = new msg_close_socket_t();
                        break;
                    case marshall_func_code_socket_send_data:
                        body = new msg_socket_transfer_data_t();
                        break;
                    case marshall_func_code_socket_rcv_data:
                        body = new msg_socket_transfer_data_t();
                        break;
                    case marshall_func_code_modem_rx_control:
                        break;
                    case marshall_func_code_trace:
                        body = new msg_trace_t();
                        break;
                    case marshall_func_code_alert:
                        body = new msg_alert_t();
                        break;
                    case marshall_func_code_mdb_command:
                        body = new msg_mdb_t();
                        break;
                    case marshall_func_code_reader_command:
                        body = new msg_reader_t();
                        break;
                    default:
                        Log.d(TAG, "unsupported msg func_code:" + Convert.ToString(func_code));
                        break;
                }

                // body length is the total packet length minus the header size offset
                int body_len = packet_len - (index - starting_index);

                if (body != null)
                {
                    index += body.decode(buf, index, body_len);
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, packet_len);
                buf[index++] = options;
                buf[index++] = id;
                buf[index++] = source;
                buf[index++] = source_lsb;
                buf[index++] = dest;
                buf[index++] = dest_lsb;
                buf[index++] = func_code;

                // encode message body
                index += body.encode(buf, index, buf_len);

                packet_len = (ushort)index;

                // encode length. now, the right value
                ByteArrayUtils.shortToByteArray(buf, starting_index, packet_len);

                // calculate crc16
                crc16 = Calc_CRC_CCITT(buf, starting_index, index, SEED_CCITT);

                index += ByteArrayUtils.shortToByteArray(buf, index, crc16);

                return index - starting_index;
            }
        }

        /*
        * msg_response_t
        */
        public class msg_response_t : msg_i
        {

            public const byte response_ack = 0x00;
            public const byte response_crc_err = 0x01;
            public const byte response_wrong_rcp = 0x02;
            public const byte response_non_cons_id = 0x03;
            public const byte response_unexp_error = 0x0a;

            // response field
            public byte value;

            public msg_response_t(byte _value)
            {
                value = _value;
            }

            public msg_response_t()
            {
            }

            public msg_response_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                value = buf[index++];

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                buf[index++] = value;

                return index - starting_index;
            }
        }

        /*
        * msg_reset_t
        */
        public class msg_reset_t : msg_i
        {

            public msg_reset_t()
            {
            }

            public msg_reset_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                Log.d(TAG, "received reset");
                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }
        }

        /*
        * msg_fw_info_t
        */
        public class msg_fw_info_t : msg_i
        {
            public const ushort fw_info_periph_cap_bitmap_magstripe = 0x0001;
            public const ushort fw_info_periph_cap_bitmap_contact = 0x0002;
            public const ushort fw_info_periph_cap_bitmap_contactless = 0x0004;
            public const ushort fw_info_periph_cap_bitmap_keypad = 0x0008;
            public const ushort fw_info_periph_cap_bitmap_display = 0x0010;
            public const ushort fw_info_periph_cap_bitmap_touch_screen = 0x0020;
            public const ushort fw_info_periph_cap_bitmap_multi_session = 0x0040;
            public const ushort fw_info_periph_cap_bitmap_mifare_card_approved_by_vmc = 0x0080;
            public const ushort fw_info_periph_cap_bitmap_req_price_is_not_final = 0x0100;
            public const ushort fw_info_periph_cap_bitmap_mag_card_approved_by_vmc = 0x0200;
            public const ushort fw_info_periph_cap_bitmap_ftl_data = 0x0400;


            public ushort prot_ver;
            public byte periph_type;
            public byte periph_sub_type;
            public ushort periph_cap_bitmap;
            public string model;
            public string serial;
            public string app_sw_ver;
            public string vmc_manuf_code;
            public string vmc_hw_ver;
            public String marshall_sdk_version;

            public msg_fw_info_t()
            {
                model = "";
                serial = "";
                app_sw_ver = "";
                vmc_manuf_code = "";
                vmc_hw_ver = "";
                marshall_sdk_version = "";
            }

            public msg_fw_info_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                Log.d(TAG, "received fw_info");

                prot_ver = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                periph_type = buf[index];
                index += 1;
                periph_sub_type = buf[index];
                index += 1;
                periph_cap_bitmap = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                model = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += model.Length;
                serial = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += serial.Length;
                app_sw_ver = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += app_sw_ver.Length;
                vmc_manuf_code = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += vmc_manuf_code.Length;
                vmc_hw_ver = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += vmc_hw_ver.Length;
                marshall_sdk_version = ByteArrayUtils.byteArrToString(buf, index, 20);
                index += marshall_sdk_version.Length;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, prot_ver);
                buf[index++] = periph_type;
                buf[index++] = periph_sub_type;
                index += ByteArrayUtils.shortToByteArray(buf, index, periph_cap_bitmap);
                index += ByteArrayUtils.stringToByteArray(buf, index, model, 19);
                buf[index++] = 0;
                index += ByteArrayUtils.stringToByteArray(buf, index, serial, 19);
                buf[index++] = 0;
                index += ByteArrayUtils.stringToByteArray(buf, index, app_sw_ver, 19);
                buf[index++] = 0;
                index += ByteArrayUtils.stringToByteArray(buf, index, vmc_manuf_code, 19);
                buf[index++] = 0;
                index += ByteArrayUtils.stringToByteArray(buf, index, vmc_hw_ver, 19);
                buf[index++] = 0;

                return index - starting_index;
            }
        }

        /*
        * msg_config_t
        */
        public class msg_config_t : msg_i
        {
            public byte prot_ver_major;
            public byte prot_ver_minor;
            public byte dev_src_id;
            public int keepalive_interval_ms;
            public byte language;
            public byte[] country_code;
            public byte[] currency_code;
            public byte decimal_place;
            public byte[] vpos_serial;
            public ushort max_msg_len;
            // from marshall version 1.0 and above
            public byte[] merchant_id;
            public byte[] acquirer_terminal_id;
            public byte[] machine_location;

            public msg_config_t()
            {
                prot_ver_major = 0;
                prot_ver_minor = 0;
                dev_src_id = 0;
                keepalive_interval_ms = 1000;
                language = 0;
                country_code = new byte[3];
                currency_code = new byte[3];
                decimal_place = 0;
                vpos_serial = new byte[16];
                max_msg_len = 512;
            }

            public msg_config_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                Log.d(TAG, "received config");

                prot_ver_major = buf[index++];
                prot_ver_minor = buf[index++];
                dev_src_id = buf[index++];
                keepalive_interval_ms = ByteArrayUtils.byteArrToInteger(buf, index);
                index += 4;
                language = buf[index++];
                ByteArrayUtils.byteArrToSubByteArray(buf, index, country_code);
                index += country_code.Length;
                ByteArrayUtils.byteArrToSubByteArray(buf, index, currency_code);
                index += currency_code.Length;
                decimal_place = buf[index++];
                ByteArrayUtils.byteArrToSubByteArray(buf, index, vpos_serial);
                index += vpos_serial.Length;
                max_msg_len = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                if (prot_ver_major >= 1)
                {
                    merchant_id = new byte[16];
                    ByteArrayUtils.byteArrToSubByteArray(buf, index, merchant_id);
                    index += merchant_id.Length;

                    acquirer_terminal_id = new byte[16];
                    ByteArrayUtils.byteArrToSubByteArray(buf, index, acquirer_terminal_id);
                    index += acquirer_terminal_id.Length;

                    machine_location = new byte[100];
                    ByteArrayUtils.byteArrToSubByteArray(buf, index, machine_location);
                    index += machine_location.Length;
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                buf[index++] = prot_ver_major;
                buf[index++] = prot_ver_minor;
                buf[index++] = dev_src_id;
                index += ByteArrayUtils.intToByteArray(buf, index, keepalive_interval_ms);
                buf[index++] = language;
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, country_code);
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, currency_code);
                buf[index++] = decimal_place;
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, vpos_serial);
                index += ByteArrayUtils.shortToByteArray(buf, index, max_msg_len);

                return index - starting_index;
            }
        }

        /*
        * msg_keepalive_t
        */
        public class msg_keepalive_t : msg_i
        {

            public msg_keepalive_t()
            {
            }

            public msg_keepalive_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }
        }

        /*
        * msg_display_msg_t
        */
        public class msg_display_msg_t : msg_i
        {
            public byte[] message;
            public ushort picture_file_id;
            public ushort audio_file_id;

            public msg_display_msg_t()
            {
            }

            public msg_display_msg_t(string msg, ushort _picture_file_id, ushort _audio_id_file)
            {
                message = msg.GetBytes();
                picture_file_id = _picture_file_id;
                audio_file_id = _audio_id_file;
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }
        }

        /*
        * msg_display_msg_status_t
        */
        public class msg_display_msg_status_t : msg_i
        {

            public byte status;

            public msg_display_msg_status_t()
            {
            }

            public msg_display_msg_status_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                status = buf[index++];

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }
        }

        /*
        * msg_transfer_data_t
        */
        public class msg_transfer_data_t : msg_i
        {
            public const int transfer_data_encode_transaction_id = 0x0001;
            public const int transfer_data_encode_choose_product_timeout = 0x0002;
            public const int transfer_data_encode_card_type = 0x0004;
            public const int transfer_data_encode_card_entry_mode = 0x0008;
            public const int transfer_data_encode_card_bin = 0x0010;
            public const int transfer_data_encode_card_bin_hash = 0x0020;
            public const int transfer_data_encode_prop_card_uid = 0x0040;
            public const int transfer_data_encode_vmc_auth_status = 0x0080;
            public const int transfer_data_encode_com_status = 0x0100;
            public const int transfer_data_encode_excel_type = 0x0200;
            public const int transfer_data_encode_cc_last_4_digits = 0x0400;
            public const int transfer_data_encode_product_code = 0x0800;
            public const int transfer_data_encode_product_price = 0x1000;

            // pre-paid / mi-fare client auth process status codes
            public const byte transfer_data_auth_status_approved_e = 0x00;
            public const byte transfer_data_auth_status_decline_e = 0x01;

            public int encode_bitmap;

            public byte[] transaction_id;
            public ushort choose_product_timeout;
            public byte card_type;
            public byte card_entry_mode;
            public byte[] card_bin;
            public byte[] card_bin_hash;
            public byte[] prop_card_uid;
            public byte vmc_auth_status;
            public byte com_status;
            public byte[] excel_data;
            public byte[] cc_last_4_digits;
            public ushort product_code;
            public int product_price;

            public msg_transfer_data_t()
            {
                init();
            }

            public msg_transfer_data_t(byte[] arr, int index, int len)
            {
                init();

                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                Log.d(TAG, "received transfer_data");

                while (index < (starting_index + buf_len))
                {
                    byte tag = buf[index++];
                    byte tag_len = buf[index++];

                    switch (tag)
                    {
                        case marshall_transfer_data_transaction_id:
                            encode_bitmap |= transfer_data_encode_transaction_id;

                            transaction_id = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, transaction_id);
                            Log.d(TAG, string.Format("marshall, transaction_id: {0}", tag_len));
                            break;
                        case marshall_transfer_data_choose_prod_timeout:
                            encode_bitmap |= transfer_data_encode_choose_product_timeout;

                            choose_product_timeout = ByteArrayUtils.byteArrToShort(buf, index);
                            index += tag_len;
                            Log.d(TAG, string.Format("marshall, choose_product_timeout: {0}", choose_product_timeout));
                            break;
                        case marshall_transfer_data_card_type:
                            encode_bitmap |= transfer_data_encode_card_type;

                            card_type = buf[index];
                            index += tag_len;
                            Log.d(TAG, string.Format("marshall, card_type: {0}", card_type));
                            break;
                        case marshall_transfer_data_card_entry_mode:
                            encode_bitmap |= transfer_data_encode_card_entry_mode;

                            card_entry_mode = buf[index];
                            index += tag_len;
                            Log.d(TAG, string.Format("marshall, card_entry_mode: {0}", card_entry_mode));
                            break;
                        case marshall_transfer_data_card_bin:
                            encode_bitmap |= transfer_data_encode_card_bin;

                            card_bin = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, card_bin);
                            Log.d(TAG, string.Format("marshall, card_bin: {0}", tag_len));
                            break;
                        case marshall_transfer_data_card_bin_hash:
                            encode_bitmap |= transfer_data_encode_card_bin_hash;

                            card_bin_hash = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, card_bin_hash);
                            Log.d(TAG, string.Format("marshall, card_bin_hash: {0}", tag_len));
                            break;
                        case marshall_transfer_data_prop_card_uid:
                            encode_bitmap |= transfer_data_encode_prop_card_uid;

                            prop_card_uid = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, prop_card_uid);
                            Log.d(TAG, string.Format("marshall, prop_card_uid: {0}", tag_len));
                            break;
                        case marshall_transfer_data_vmc_auth_status:
                            encode_bitmap |= transfer_data_encode_vmc_auth_status;

                            vmc_auth_status = buf[index];
                            index += tag_len;
                            Log.d(TAG, string.Format("marshall, vmc auth: {0}", vmc_auth_status));
                            break;
                        case marshall_transfer_data_com_status:
                            encode_bitmap |= transfer_data_encode_com_status;

                            com_status = buf[index];
                            index += tag_len;
                            Log.d(TAG, string.Format("marshall, com status: {0}", com_status));
                            break;
                        case marshall_transfer_data_excel_type:
                            encode_bitmap |= transfer_data_encode_excel_type;

                            excel_data = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, excel_data);
                            Log.d(TAG, String.Format("marshall, excel data: {0} bytes", tag_len));
                            break;
                        case marshall_transfer_data_cc_last_4_digits:
                            encode_bitmap |= transfer_data_encode_cc_last_4_digits;

                            cc_last_4_digits = new byte[tag_len];
                            index += ByteArrayUtils.byteArrToSubByteArray(buf, index, cc_last_4_digits);
                            Log.d(TAG, String.Format("marshall, last cc digits: {0} bytes", tag_len));
                            break;
                        case marshall_transfer_data_product_code:
                            encode_bitmap |= transfer_data_encode_product_code;

                            product_code = ByteArrayUtils.byteArrToShort(buf, index); index += tag_len;
                            Log.d(TAG, String.Format("marshall, product code: {0}", product_code));
                            break;
                        case marshall_transfer_data_product_price:
                            encode_bitmap |= transfer_data_encode_product_price;

                            product_price = ByteArrayUtils.byteArrToInteger(buf, index); index += tag_len;
                            Log.d(TAG, String.Format("marshall, product price: {1}", product_price));
                            break;
                        default:
                            index += tag_len;
                            Log.d(TAG, "skipping unknown tag");
                            break;
                    }
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                if ((encode_bitmap & transfer_data_encode_transaction_id) != 0)
                {
                    buf[index++] = marshall_transfer_data_transaction_id;
                    buf[index++] = (byte)transaction_id.Length;
                    index += ByteArrayUtils.subByteArrToByteArray(buf, index, transaction_id);
                }
                if ((encode_bitmap & transfer_data_encode_choose_product_timeout) != 0)
                {
                    buf[index++] = marshall_transfer_data_choose_prod_timeout;
                    buf[index++] = (byte)2;
                    index += ByteArrayUtils.shortToByteArray(buf, index, choose_product_timeout);
                }
                if ((encode_bitmap & transfer_data_encode_card_type) != 0)
                {
                    buf[index++] = marshall_transfer_data_card_type;
                    buf[index++] = (byte)1;
                    buf[index++] = (byte)card_type;
                }
                if ((encode_bitmap & transfer_data_encode_card_entry_mode) != 0)
                {
                    buf[index++] = marshall_transfer_data_card_entry_mode;
                    buf[index++] = (byte)1;
                    buf[index++] = (byte)card_entry_mode;
                }
                if ((encode_bitmap & transfer_data_encode_card_bin) != 0)
                {
                    buf[index++] = marshall_transfer_data_card_bin;
                    buf[index++] = (byte)card_bin.Length;
                    index += ByteArrayUtils.subByteArrToByteArray(buf, index, card_bin);
                }
                if ((encode_bitmap & transfer_data_encode_card_bin_hash) != 0)
                {
                    buf[index++] = marshall_transfer_data_card_bin_hash;
                    buf[index++] = (byte)card_bin_hash.Length;
                    index += ByteArrayUtils.subByteArrToByteArray(buf, index, card_bin_hash);
                }
                if ((encode_bitmap & transfer_data_encode_prop_card_uid) != 0)
                {
                    buf[index++] = marshall_transfer_data_prop_card_uid;
                    buf[index++] = (byte)prop_card_uid.Length;
                    index += ByteArrayUtils.subByteArrToByteArray(buf, index, prop_card_uid);
                }
                if ((encode_bitmap & transfer_data_encode_vmc_auth_status) != 0)
                {
                    buf[index++] = marshall_transfer_data_vmc_auth_status;
                    buf[index++] = (byte)1;
                    buf[index++] = (byte)vmc_auth_status;
                }
                if ((encode_bitmap & transfer_data_encode_com_status) != 0)
                {
                    buf[index++] = marshall_transfer_data_com_status;
                    buf[index++] = (byte)1;
                    buf[index++] = (byte)com_status;
                }
                if ((encode_bitmap & transfer_data_encode_excel_type) != 0)
                {
                    buf[index++] = marshall_transfer_data_excel_type;
                    buf[index++] = (byte)excel_data.Length;
                    index += ByteArrayUtils.subByteArrToByteArray(buf, index, excel_data);
                }

                return index - starting_index;
            }

            private void init()
            {
                encode_bitmap = 0;

                transaction_id = null;
                card_bin = null;
                card_bin_hash = null;
                prop_card_uid = null;
                excel_data = null;
                cc_last_4_digits = null;
            }
        }

        /*
        * msg_status_t
        */
        public class msg_status_t : msg_i
        {

            public const byte status_unexpected_error = 0x00;
            public const byte status_unexpected_timeout = 0x01;
            public const byte status_unexpected_out_of_seq = 0x02;
            public const byte status_unexpected_pending_3rd_party_rcvd = 0x03;
            public const byte status_settlement = 0x04;
            public const byte status_machine_status = 0x05;
            public const byte status_ftp_status = 0x06;

            public byte status;
            public ushort data_len;
            public byte[] data;

            public msg_status_t()
            {
            }

            public msg_status_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                Log.d(TAG, "received status");

                status = buf[index++];

                data_len = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                if (data_len > 0)
                {
                    data = new byte[data_len];
                    ByteArrayUtils.byteArrToSubByteArray(buf, index, data);
                    index += data_len;
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                buf[index++] = status;
                index += ByteArrayUtils.shortToByteArray(buf, index, data_len);
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, data);

                return index - starting_index;
            }
        }

        /*
        * msg_time_req_t
        */
        public class msg_time_req_t : msg_i
        {

            public msg_time_req_t() { }

            public msg_time_req_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;
                return index - starting_index;
            }
        }

        /*
        * msg_time_rsp_t
        */
        public class msg_time_rsp_t : msg_i
        {

            public byte year;
            public byte month;
            public byte day;
            public byte hours;
            public byte minutes;
            public byte seconds;

            public msg_time_rsp_t() { }

            public msg_time_rsp_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                year = buf[index++];
                month = buf[index++];
                day = buf[index++];
                hours = buf[index++];
                minutes = buf[index++];
                seconds = buf[index++];

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;
                return index - starting_index;
            }
        }

        /*
        * msg_set_periph_param_t
        */
        public class msg_set_periph_param_t : msg_i
        {

            public ushort dcs_code;
            public byte[] data;

            public msg_set_periph_param_t()
            {
            }

            public msg_set_periph_param_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                dcs_code = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                int data_len = buf_len - 2;

                data = new byte[data_len];
                ByteArrayUtils.byteArrToSubByteArray(buf, index, data);
                index += data_len;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, dcs_code);
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, data);

                return index - starting_index;
            }
        }

        /*
         * msg_ereceipt_t
         */
        public class msg_ereceipt_t : msg_i
        {
        public byte qr_type;
        public byte[] data;

        public msg_ereceipt_t()
        {
        }

        public msg_ereceipt_t(int type, byte[] data)
        {
            this.qr_type = (byte)type;
            this.data = data;
        }

        public msg_ereceipt_t(byte[] arr, int index, int len)
        {
            decode(arr, index, len);
        }

        public override int decode(byte[] buf, int index, int buf_len)
        {

            int starting_index = index;

            qr_type = buf[index++];

            int data_len = buf_len - 1;

            data = new byte[data_len];
            ByteArrayUtils.byteArrToSubByteArray(buf, index, data);
            index += data_len;

            return index - starting_index;
        }

         public override int encode(byte[] buf, int index, int buf_len)
        {

            int starting_index = index;

            buf[index++] = qr_type;
            index += ByteArrayUtils.subByteArrToByteArray(buf, index, data);

            return index - starting_index;
        }
    }

    /*
     * msg_display_control_t
     */
    public class msg_display_control_t : msg_i
        {
            public class label_t
            {
                public byte object_id;
                public byte label_num_in_layout;
                public String label;

                public label_t(int obj_id, int num_in_layout, String label)
                {
                    this.object_id = (byte)obj_id;
                    this.label_num_in_layout = (byte)num_in_layout;
                    this.label = label;
                }
            };
            public class layout_t
            {
                public ushort id;
                public List<label_t> labels;
                public List<Byte> buttons;

                public layout_t(int id)
                {
                    this.id = (ushort)id;
                    labels = new List<label_t>();
                    buttons = new List<Byte>();
                }

                public void add(label_t label)
                {
                    labels.Add(label);
                }

                public void add(byte button)
                {
                    buttons.Add(button);
                }

            }

            public List<layout_t> layouts;

            public msg_display_control_t()
            {
                layouts = new List<layout_t>();
            }

            public msg_display_control_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }

            public void add(layout_t layout)
            {
                layouts.Add(layout);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                return index - starting_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                int layout_index = 0;
                do
                {
                    if (layout_index < layouts.Count)
                    {
                        layout_t layout = layouts[layout_index++];

                        buf[index++] = marshall_display_control_layout_id_tag;
                        buf[index++] = (byte)2;
                        index += ByteArrayUtils.shortToByteArray(buf, index, layout.id);

                        // encode labels
                        for (int i = 0; i < layout.labels.Count; i++)
                        {
                            label_t label = layout.labels[i];

                            buf[index++] = marshall_display_control_label_tag;
                            buf[index++] = (byte)(2 + label.label.Length);
                            buf[index++] = label.object_id;
                            buf[index++] = label.label_num_in_layout;
                            index += ByteArrayUtils.stringToByteArray(buf, index, label.label, label.label.Length);
                        }

                        // encode buttons
                        if (layout.buttons.Count > 0)
                        {
                            buf[index++] = marshall_display_control_button_id_tag;
                            buf[index++] = (byte)layout.buttons.Count;
                            for (int i = 0; i < layout.buttons.Count; i++)
                            {
                                byte button = layout.buttons[i];

                                buf[index++] = (byte)button;
                            }
                        }
                    }

                } while (layout_index < layouts.Count);

                return index - starting_index;
            }
        }

        /*
         * msg_display_event_t
         */
        public class msg_display_event_t : msg_i
        {
            public List<Byte> buttons;
            public List<String> text;

            private const byte display_status_tag_type_button = 0x01;
            private const byte display_status_tag_type_text = 0x02;

            public msg_display_event_t()
            {
                init();
            }

            public msg_display_event_t(byte[] arr, int index, int len)
            {
                init();

                decode(arr, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                while (index < buf_len)
                {
                    byte type = buf[index++];
                    byte len = buf[index++];

                    switch (type)
                    {
                        case display_status_tag_type_button:
                            buttons.Add(buf[index]);
                            break;
                        case display_status_tag_type_text:                            
                            text.Add(System.Text.Encoding.Default.GetString(buf, index, len));
                            break;
                    }

                    index += len;
                }

                return index - starting_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;
                return index - starting_index;
            }

            private void init()
            {
                buttons = new List<Byte>();
                text = new List<String>();
            }
        }

        /*
        * msg_modem_status_t
        */
        public class msg_modem_status_t : msg_i
        {

            public const byte modem_status_ok = 0x00;
            public const byte modem_status_fail = 0x01;
            public const byte modem_status_busy = 0x02;
            public const byte modem_status_in_param_error = 0x03;
            public const byte modem_status_in_command_error = 0x04;
            public const byte modem_status_socket_is_closed = 0x05;
            public const byte modem_status_no_avail_resource = (byte)0x80;
            public const byte modem_status_unsupported_socket_type = (byte)0x81;

            public byte command;
            public byte status;
            public byte extra;

            public msg_modem_status_t()
            {
            }

            public msg_modem_status_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                command = buf[index++];

                status = buf[index++];

                extra = buf[index++];

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                buf[index++] = command;
                buf[index++] = status;
                buf[index++] = extra;

                return index - starting_index;
            }
        }

        /*
        * msg_open_socket_t
        */
        public class msg_open_socket_t : msg_i
        {

            public const byte socket_dest_nayax = 0x00;
            public const byte socket_dest_other = 0x01;

            public const byte socket_protocol_tcp = 0x00;
            public const byte socket_protocol_udp = 0x00;
            public const byte socket_protocol_ftp = 0x00;

            public byte dest;
            public byte protocol;
            public ushort port;
            public string ip_addr;
            public short socket_mtu;
            public short socket_timeout;

            public msg_open_socket_t()
            {
                socket_mtu = -1;
                socket_timeout = -1;
            }

            public msg_open_socket_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;

                dest = buf[index++];
                protocol = buf[index++];
                port = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                // rest of data is the ip address /  server url
                ip_addr = ByteArrayUtils.byteArrToString(buf, index, buf_len - (index - starting_index));

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                buf[index++] = dest;
                buf[index++] = protocol;
                index += ByteArrayUtils.shortToByteArray(buf, index, port);
                index += ByteArrayUtils.stringToByteArray(buf, index, ip_addr, buf_len - (index - starting_index));
                buf[index++] = (byte)'\0';


                /* optional: mtu, timeout. based on marshall version */
                if (socket_mtu >= 0 && socket_timeout >= 0)
                {
                    index += ByteArrayUtils.shortToByteArray(buf, index, (ushort)socket_mtu);
                    index += ByteArrayUtils.shortToByteArray(buf, index, (ushort)socket_timeout);
                }
                return index - starting_index;
            }
        }

        /*
        * msg_close_socket_t
        */
        public class msg_close_socket_t : msg_i
        {

            public msg_close_socket_t()
            {
            }

            public msg_close_socket_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {

                int starting_index = index;
                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;
                return index - starting_index;
            }
        }

        /*
        * msg_socket_transfer_data_t
        */
        public class msg_socket_transfer_data_t : msg_i
        {

            public byte[] data;

            public msg_socket_transfer_data_t()
            {
            }

            public msg_socket_transfer_data_t(byte[] buffer)
            {
                data = buffer;
            }

            public msg_socket_transfer_data_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                int len = buf_len;

                if (len < 0)
                {
                    Log.d(TAG, "negative len");
                }
                else
                {
                    data = new byte[len];
                    index += ByteArrayUtils.byteArrToSubByteArray(buf, index, data);
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                index += ByteArrayUtils.subByteArrToByteArray(buf, index, data);

                return index - starting_index;
            }
        }

        /*
        * msg_modem_rx_control_t
        */
        public class msg_modem_rx_control_t : msg_i
        {

            public const byte rx_control_resume = 0x00;
            public const byte rx_control_pause = 0x01;

            public byte control;

            public msg_modem_rx_control_t()
            {
            }

            public msg_modem_rx_control_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                control = buf[index++];

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                buf[index++] = control;

                return index - starting_index;
            }
        }

        /*
        * msg_trace_t
        */
        public class msg_trace_t : msg_i
        {

            public ushort trace_number;
            public byte num_of_params;
            public ushort[] param_values;


            public msg_trace_t()
            {
            }

            public msg_trace_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                trace_number = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                num_of_params = buf[index++];

                param_values = new ushort[num_of_params];
                for (int i = 0; i < num_of_params; i++)
                {
                    param_values[i] = ByteArrayUtils.byteArrToShort(buf, index);
                    index += 2;
                }

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, trace_number);
                buf[index++] = num_of_params;

                for (int i = 0; i < num_of_params; i++)
                {
                    index += ByteArrayUtils.shortToByteArray(buf, index, param_values[i]);
                }

                return index - starting_index;
            }
        }

        /*
        * msg_alert_t
        */
        public class msg_alert_t : msg_i
        {

            public ushort alert_id;
            public string alert;

            public msg_alert_t()
            {
            }

            public msg_alert_t(ushort id, String msg)
            {
                alert_id = id;
                alert = msg;
            }

            public msg_alert_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                alert_id = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;
                alert = ByteArrayUtils.byteArrToString(buf, index, 512);
                index += alert.Length;

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, alert_id);
                index += ByteArrayUtils.stringToByteArray(buf, index, alert, 512);

                return index - starting_index;
            }
        }


        /*
        * msg_mdb_t
        */
        public class msg_mdb_t : msg_i
        {

            public msg_i message;

            public msg_mdb_t()
            {
            }

            public msg_mdb_t(byte[] arr, int index, int len)
            {
                decode(arr, index, len);
            }


            public override int decode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                // we are mdb master - decode responses only
                message = new mdb_rsp_t.msg_mdb_rsp_t();

                index += message.decode(buf, index, buf_len);

                return index - starting_index;
            }


            public override int encode(byte[] buf, int index, int buf_len)
            {
                int starting_index = index;

                // we are mdb master - encode requests only
                index += message.encode(buf, index, buf_len);

                return index - starting_index;
            }
        }

        /*
         * msg_reader_t
         */
        public class msg_reader_t : msg_i
        {
        public byte event_type;
        public byte payment_type_key_value;
        public byte payment_type_data;
        public byte[] payment_type_data_value;

        public msg_reader_t()
        {
        }

        public msg_reader_t(byte[] arr, int index, int len)
        {
            decode(arr, index, len);
        }

        public override int decode(byte[] buf, int index, int buf_len)
        {
            int starting_index = index;

            // no decoding for this message

            return index - starting_index;
        }

        public override int encode(byte[] buf, int index, int buf_len)
        {
            int starting_index = index;

            buf[index++] = event_type;
            buf[index++] = payment_type_key_value;
            buf[index++] = payment_type_data;
            index += ByteArrayUtils.subByteArrToByteArray(buf, index, payment_type_data_value);

            return index - starting_index;
        }
    }
    // ===========================================================
    // Fields
    // ===========================================================

    // ===========================================================
    // Abstract methods
    // ===========================================================

    // ===========================================================
    // static finalructors
    // ===========================================================

    // ===========================================================
    // Methods from SuperClass/Interfaces (and supporting methods)
    // ===========================================================

    // ===========================================================
    // Methods
    // ===========================================================

    public static msg_marshall_t request(byte func_code, byte options, msg_i body)
        {
            msg_marshall_t message = new msg_marshall_t();

            message.packet_len = 0;
            message.id = 0;
            message.options = options;
            message.body = body;
            message.dest = vpos_address;
            message.func_code = func_code;

            return message;
        }

        public static msg_marshall_t response(byte options, byte value)
        {
            msg_response_t body = new msg_response_t();
            body.value = value;


            return request(marshall_func_code_response, options, body);
        }

        public static msg_marshall_t firmware_info(byte options, msg_fw_info_t body)
        {
            return request(marshall_func_code_fw_info, options, body);
        }

        public static msg_marshall_t config(byte options, byte value)
        {
            msg_config_t body = new msg_config_t();

            return request(marshall_func_code_config, options, body);
        }

        public static msg_marshall_t keepalive()
        {
            msg_keepalive_t body = new msg_keepalive_t();
            //Log.d(TAG, "keepalive");
            return request(marshall_func_code_keepalive, marshall_packet_option_ack_mask, body);
        }

        public static msg_marshall_t mdb_req(mdb_req_t.msg_mdb_req_t body)
        {
            return request(marshall_func_code_mdb_command, marshall_packet_option_ack_mask, body);
        }


        /// <summary>
        /// @brief  :This function Return CRC-CCITT calculation based on current CRC value and a given byte </summary>
        /// @param  :Crc  - Current CRC
        ///          Byte - Current byte to insert to the Crc
        /// @retval :New CRC </param>
        internal static ushort CRC_CCITT(ushort Crc, byte _byte)
        {
            byte i;
            ushort Temp, ShortC, CurrentCRC = (ushort)SEED_CCITT;

            ShortC = (ushort)(_byte & 0x00FF);
            Temp = (ushort)(((Crc >> 8) ^ ShortC) << 8);
            for (i = 0; i < 8; i++)
            {
                if (((CurrentCRC ^ Temp) & 0x8000) != 0)
                {
                    CurrentCRC = (ushort)((CurrentCRC << 1) ^ POLYNOMIAL_CCITT); // 1010.0000 0000.0001 = x^16 + x^15 + x^13 + 1
                }
                else
                {
                    CurrentCRC <<= 1;
                }
                Temp <<= 1;
            }

            return (ushort)((Crc << 8) ^ CurrentCRC);
        }

        /// <summary>
        /// @brief  :This function Return CRC-CCITT calculation for an entire buffer </summary>
        /// @param  :*pData  - Pointer to a buffer
        ///          Len     - Buffer length
        /// @retval :New CRC </param>
        public static ushort Calc_CRC_CCITT(byte[] buf, int start_index, int len, ushort seed)
        {
            int i;
            ushort crc = seed;

            for (i = start_index; i < start_index + len; i++)
            {
                crc = CRC_CCITT(crc, buf[i]);
            }

            return (crc);
        }
    }
}