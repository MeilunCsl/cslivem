using System;
using System.Threading;
using System.Collections.Generic;
using System.Collections.Concurrent;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.models;
    using com.bitmick.marshall.utils;

    public class vmc_socket_t : vmc_client_t
    {

		// ===========================================================
		// Constants
		// ===========================================================

        internal static readonly string TAG = typeof(vmc_socket_t).Name;

		private const int vmc_socket_state_init_e = 0;
		private const int vmc_socket_state_idle_e = 1;
		private const int vmc_socket_state_open_req_e = 2;
		private const int vmc_socket_state_opened_e = 3;
		private const int vmc_socket_state_close_req_e = 4;
		private const int vmc_socket_state_closed_e = 5;
		private const int vmc_socket_state_error_e = 6;

		private const int vmc_socket_event_init_done_e = 0;
		private const int vmc_socket_event_open_req_e = 1;
		private const int vmc_socket_event_opened_e = 2;
		private const int vmc_socket_event_close_req_e = 3;
		private const int vmc_socket_event_closed_e = 4;
		private const int vmc_socket_event_transmit_e = 5;
		private const int vmc_socket_event_receive_e = 6;
		private const int vmc_socket_event_error_e = 7;


        public const int vmc_socket_type_tcp_e         = 0x00;
        public const int vmc_socket_type_ftp_e         = 0x02;

        private static String[] m_states_str =
                {
                    "init",
                    "idle",
                    "open_req",
                    "opened",
                    "close_req",
                    "closed",
                    "error"
            };

        private static String[] m_events_str =
                {
                    "init_done",
                    "open_req",
                    "opened",
                    "close_req",
                    "closed",
                    "transmit",
                    "receive",
                    "error"
            };

        public abstract class socket_callbacks_t
		{
			// called when vmc framework is ready
			public abstract void onReady();

			public abstract void onSocketOpened();

			public abstract void onSocketClosed();

			public abstract void onSocketError();

			public abstract void onTimerTick(long ms);

			public abstract void onTransmitDone(bool success);

			// return false if flow-control is needed
			public abstract bool onReceive(byte[] buffer, int size);

			public abstract void onFTPDone(bool success);
		}

		// ===========================================================
		// Fields
		// ===========================================================

		private class socket_msg_t
		{
			public byte[] buffer;
			public int offset;
			public int len;
		}

		private class socket_params_t
		{
            public ushort type;
            public string ip_addr;
            public ushort port;
            public object meta;
			public int mtu;
			public int timeout;

		}

		private vmc_link m_vmc_link;
		private int m_socket_state;
		private socket_callbacks_t m_callbacks;

		private marshall_t.msg_marshall_t m_pending_msg;
        private static bool m_transfer_paused;

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public vmc_socket_t()
		{
			init();
		}

		// ===========================================================
		// Methods from SuperClass/Interfaces (and supporting methods)
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public override void onReady(vmc_link link)
		{
			m_vmc_link = link;

            if (m_socket_state != vmc_socket_state_init_e && m_socket_state != vmc_socket_state_idle_e)
            {
                // already opened. first gracefully close
                close_socket();
            }
            else
            {
                notify(vmc_socket_event_init_done_e, null);
            }
        }

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public override void onCommError()
		{
            if (m_callbacks != null)
                m_callbacks.onSocketError();

            init();
		}

		public override void onTimerTick(long ms)
		{
			base.onTimerTick(ms);

			if (m_callbacks != null)
				m_callbacks.onTimerTick(ms);

            if (m_transfer_paused)
            {
                m_transfer_paused = false;

                // resume
                socket_flow_control(false);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override bool handleMarshallMessage(marshall_t.msg_marshall_t msg)
		{
			switch (msg.func_code)
			{
				case marshall_t.marshall_func_code_status:
					marshall_t.msg_status_t status_body = (marshall_t.msg_status_t)msg.body;

                    Log.d(TAG, string.Format("received status: {0}", status_body.status));
					switch (status_body.status)
					{
						case marshall_t.msg_status_t.status_ftp_status:
						{
								bool success = (status_body.data[0] == 0);

								if (m_callbacks != null)
								{
									m_callbacks.onFTPDone(success);
								}

								close_socket();
						}
							break;
						default:
							break;
					}
					break;
				case marshall_t.marshall_func_code_modem_status:
					marshall_t.msg_modem_status_t modem_status = (marshall_t.msg_modem_status_t)msg.body;
                    Log.d(TAG, string.Format("received modem status: {0}, socket state: {1}", (((int)modem_status.status) & 0x00ff), m_socket_state));
					switch (modem_status.status)
					{
						case marshall_t.msg_modem_status_t.modem_status_ok:
							{
								switch (m_socket_state)
								{
									case vmc_socket_state_open_req_e:
										// received ack for open request
										notify(vmc_socket_event_opened_e, null);
										break;
									case vmc_socket_state_opened_e:
										// ack for transmission

										if (m_callbacks != null)
											m_callbacks.onTransmitDone(true);
										break;
									case vmc_socket_state_close_req_e:
										// received ack for close request
										notify(vmc_socket_event_closed_e, null);
										break;
									default:
										break;
								}
								m_pending_msg = null;
							}
							break;
						case marshall_t.msg_modem_status_t.modem_status_busy:
							{
								Log.d(TAG, "socket busy");
								switch (m_socket_state)
								{
									case vmc_socket_state_open_req_e:
										// todo: retransmit
										notify(vmc_socket_event_error_e, null);
										break;
									case vmc_socket_state_opened_e:
										// todo: retransmit

										if (m_callbacks != null)
											m_callbacks.onTransmitDone(false);
										break;
									case vmc_socket_state_close_req_e:
										// todo: retransmit
										break;
									default:
										break;
								}

								//notify(vmc_socket_event_error_e, null);
							}
							break;
						case marshall_t.msg_modem_status_t.modem_status_fail:
							Log.d(TAG, "socket fail");
							notify(vmc_socket_event_error_e, null);
							break;
						case marshall_t.msg_modem_status_t.modem_status_socket_is_closed:
							notify(vmc_socket_event_closed_e, null);
							break;
						case marshall_t.msg_modem_status_t.modem_status_unsupported_socket_type:
							break;
						case marshall_t.msg_modem_status_t.modem_status_in_command_error:
							break;
						case marshall_t.msg_modem_status_t.modem_status_in_param_error:
							break;
						case marshall_t.msg_modem_status_t.modem_status_no_avail_resource:
							break;
						default:
							break;
					}
					break;
				case marshall_t.marshall_func_code_socket_rcv_data:
					notify(vmc_socket_event_receive_e, msg.body);
					break;
				default:
					break;
			}
			return false;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        private bool change_state(int new_state, object obj)
		{
            Log.d(TAG, string.Format("changed state, from [{0}] to [{1}]", m_states_str[m_socket_state], m_states_str[new_state]));

            m_socket_state = new_state;

			switch (new_state)
			{
				case vmc_socket_state_init_e:
					break;
				case vmc_socket_state_idle_e:
					if (m_callbacks != null)
						m_callbacks.onReady();
					break;
				case vmc_socket_state_open_req_e:
					{
						marshall_t.msg_open_socket_t socket = new marshall_t.msg_open_socket_t();

						socket_params_t sock_params = (socket_params_t)obj;

						socket.dest = marshall_t.msg_open_socket_t.socket_dest_other;
						socket.protocol = (byte)sock_params.type;
						socket.port = sock_params.port;
						socket.ip_addr = sock_params.ip_addr;

						if (m_vmc_link.get_config().prot_ver_major >= 2)
						{
							socket.socket_mtu = (short)sock_params.mtu;
							socket.socket_timeout = (short)sock_params.timeout;
						}
						Log.d(TAG, String.Format("open url: {0} mtu:{1}", sock_params.ip_addr, socket.socket_mtu));

						transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_open_socket, (byte)marshall_t.marshall_packet_option_ack_mask, socket));
					}
					break;
				case vmc_socket_state_opened_e:
					if (m_callbacks != null)
						m_callbacks.onSocketOpened();
					break;
				case vmc_socket_state_close_req_e:
					{
						marshall_t.msg_close_socket_t socket = new marshall_t.msg_close_socket_t();

						transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_close_socket, (byte)0, socket));
					}
					break;
				case vmc_socket_state_closed_e:
					if (m_callbacks != null)
						m_callbacks.onSocketClosed();
					break;
				case vmc_socket_state_error_e:
					if (m_callbacks != null)
						m_callbacks.onSocketError();
					break;
				default:
					break;
			}

			return true;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		// on vmc_vend context
        protected override bool handleMessage(MsgObject msg)
		{
			bool action = false;

			base.handleMessage(msg);

            if (msg.id < m_events_str.Length && msg.id != vmc_socket_event_receive_e)
                Log.d(TAG, string.Format("received event: [{0}], state: [{1}]", m_events_str[msg.id], m_states_str[m_socket_state]));

            do
            {
				action = false;

				switch (m_socket_state)
				{
					case vmc_socket_state_init_e:
					{
						switch (msg.id)
						{
							case vmc_socket_event_init_done_e:
								action = change_state(vmc_socket_state_idle_e, null);
								break;
							default:
								break;
						}
					}
					break;
					case vmc_socket_state_idle_e:
						// wait for socket open request
						switch (msg.id)
						{
							case vmc_socket_event_open_req_e:
								action = change_state(vmc_socket_state_open_req_e, msg.data);
								// todo: add time-out on events, such as transmit / open / close requests
								break;
							case vmc_socket_event_receive_e:
							{
								Log.d(TAG, "received data, without opened socket. closing...");
								action = change_state(vmc_socket_state_close_req_e, null);
							}
							break;
							case vmc_socket_event_close_req_e:
							{
								action = change_state(vmc_socket_state_close_req_e, null);
							}
							break;
							default:
								break;
						}
						break;
					case vmc_socket_state_open_req_e:
						// wait for socket opend ack
						switch (msg.id)
						{
							case vmc_socket_event_opened_e:
								action = change_state(vmc_socket_state_opened_e, null);
								break;
							case vmc_socket_event_close_req_e:
								action = change_state(vmc_socket_state_close_req_e, null);
								break;
							case vmc_socket_event_error_e:
								action = change_state(vmc_socket_state_error_e, null);
								break;
							default:
								break;

						}
						break;
					case vmc_socket_state_opened_e:
						switch (msg.id)
						{
							case vmc_socket_event_transmit_e:
							{
									socket_msg_t sock_msg = (socket_msg_t)msg.data;

									byte[] data = new byte[sock_msg.len];
									Array.Copy(sock_msg.buffer, sock_msg.offset, data, 0, sock_msg.len);

									marshall_t.msg_socket_transfer_data_t transfer = new marshall_t.msg_socket_transfer_data_t(data);

									transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_socket_send_data, (byte)0, transfer));
							}
								break;
							case vmc_socket_event_receive_e:
							{
									marshall_t.msg_socket_transfer_data_t socket_rcv_data = (marshall_t.msg_socket_transfer_data_t)msg.data;

                                    //Log.d(TAG, string.Format("received {0} bytes", socket_rcv_data.data.Length));

									if (m_callbacks != null)
									{
										if (!m_callbacks.onReceive(socket_rcv_data.data, socket_rcv_data.data.Length))
										{
                                            // todo: flow control
                                            //socket_flow_control(true);
                                        }
									}
							}
								break;
							case vmc_socket_event_close_req_e:
								action = change_state(vmc_socket_state_close_req_e, null);
								break;
							case vmc_socket_event_error_e:
								action = change_state(vmc_socket_state_error_e, null);
								break;
							default:
								break;

						}
						break;
					case vmc_socket_state_close_req_e:
						// wait for socket closed ack
						switch (msg.id)
						{
							case vmc_socket_event_closed_e:
								action = change_state(vmc_socket_state_closed_e, null);
								break;
							case vmc_socket_event_error_e:
								action = change_state(vmc_socket_state_error_e, null);
								break;
							default:
								break;
						}
						break;
					case vmc_socket_state_closed_e:
						action = change_state(vmc_socket_state_idle_e, null);
						break;
					case vmc_socket_state_error_e:
                        // wait for socket closed ack
                        switch (msg.id)
                        {
                            case vmc_socket_event_closed_e:
                                action = change_state(vmc_socket_state_idle_e, null);
                                break;
                            case vmc_socket_event_error_e:
                                action = change_state(vmc_socket_state_idle_e, null);
                                break;
                            default:
                                break;
                        }
                        break;
					default:
						break;
				}
			} while (action);

			return true;
		}

		// ===========================================================
		// Methods
		// ===========================================================

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void init()
		{
			m_vmc_link = null;

			m_socket_state = vmc_socket_state_init_e;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		private void transmit_marshall(marshall_t.msg_marshall_t msg)
		{
			m_pending_msg = msg;

			if (m_vmc_link != null)
				m_vmc_link.transmit_marshall(msg);
		}

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void socket_flow_control(bool pause)
        {
            marshall_t.msg_modem_rx_control_t rx_control = new marshall_t.msg_modem_rx_control_t();

            rx_control.control = (byte)(pause ? 1 : 0);

            transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_socket_send_data, (byte)0, rx_control));

            m_transfer_paused = true;
        }

        // ===========================================================
        // Public Methods
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void register_callbacks(socket_callbacks_t callbacks)
		{
			m_callbacks = callbacks;
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public bool is_ready()
		{
			return (m_socket_state == vmc_socket_state_idle_e);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public void open_socket(int type, string ip_addr, ushort port)
		{
			open_socket(type, ip_addr, port, -1, -1);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void open_socket(int type, String ip_addr, ushort port, int mtu, int timeout)
		{
			socket_params_t sock_params = new socket_params_t();

			sock_params.type = (ushort)type;
			sock_params.ip_addr = ip_addr;
			sock_params.port = port;
			sock_params.meta = null;
			sock_params.mtu = mtu;
			sock_params.timeout = timeout;

			notify(vmc_socket_event_open_req_e, sock_params);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
		public void transmit(byte[] buffer, int offset, int len)
		{
			socket_msg_t sock_msg = new socket_msg_t();

			sock_msg.buffer = buffer;
			sock_msg.offset = offset;
			sock_msg.len = len;

			notify(vmc_socket_event_transmit_e, sock_msg);
		}

		//////////////////////////////////////////////////////////////////////////////////////////////
		// function name:
		// input:
		// output:
		// notes:
		/////////////////////////////////////////////////////////////////////////////////////////////
        public void close_socket()
		{
			notify(vmc_socket_event_close_req_e, null);
		}
	}
}