﻿using System;

namespace com.bitmick.marshall.protocol
{
    using com.bitmick.marshall.interfaces;
    using com.bitmick.marshall.utils;

    public class mdb_rsp_t : mdb_t
    {

        // ===========================================================
        // Constants
        // ===========================================================

        internal static readonly string TAG = typeof(mdb_rsp_t).Name;

        // respones

        public const byte mdb_response_setup_reader_config_data = (byte)0x01;

        public const byte mdb_response_poll_just_reset = (byte)0x00;
        public const byte mdb_response_poll_reader_config_data = (byte)0x01;
        public const byte mdb_response_poll_display_req = (byte)0x02;
        public const byte mdb_response_poll_begin_session = (byte)0x03;
        public const byte mdb_response_poll_session_cancel_req = (byte)0x04;
        public const byte mdb_response_poll_vend_approved = (byte)0x05;
        public const byte mdb_response_poll_vend_denied = (byte)0x06;
        public const byte mdb_response_poll_end_session = (byte)0x07;
        public const byte mdb_response_poll_cancelled = (byte)0x08;
        public const byte mdb_response_poll_peripheral_id = (byte)0x09;
        public const byte mdb_response_poll_malfunction_error = (byte)0x0a;
        public const byte mdb_response_poll_cmd_out_of_seq = (byte)0x0b;
        public const byte mdb_response_poll_revalue_approved = (byte)0x0d;
        public const byte mdb_response_poll_revalue_denied = (byte)0x0e;
        public const byte mdb_response_poll_revalue_limit_amount = (byte)0x0f;
        public const byte mdb_response_poll_user_file_data = (byte)0x10;
        public const byte mdb_response_poll_time_date_req = (byte)0x11;
        public const byte mdb_response_poll_data_entry_req = (byte)0x12;
        public const byte mdb_response_poll_data_entry_cancel = (byte)0x13;
        public const byte mdb_response_poll_selection_request = (byte)0x14; // mdb 4.3 (remote vend)
        public const byte mdb_response_poll_ftl_req_to_rcv = (byte)0x1b;
        public const byte mdb_response_poll_ftl_retry_deny = (byte)0x1c;
        public const byte mdb_response_poll_ftl_send_block = (byte)0x1d;
        public const byte mdb_response_poll_ok_to_send = (byte)0x1e;
        public const byte mdb_response_poll_req_to_send = (byte)0x1f;
        public const byte mdb_response_sessions_status = (byte)0x86;
        public const byte mdb_response_reader_state_rsp = (byte)0x88;
        public const byte mdb_response_poll_diagnostics_response = unchecked((byte)0xff);

        public const byte mdb_response_vend_approved = (byte)0x05;
        public const byte mdb_response_vend_denied = (byte)0x06;
        public const byte mdb_response_vend_end_session = (byte)0x07;

        public const byte mdb_response_reader_cancelled = (byte)0x08;

        public const byte mdb_response_revalue_approved = (byte)0x0d;
        public const byte mdb_response_revalue_denied = (byte)0x0e;
        public const byte mdb_response_revalue_limit_amount = (byte)0x0f;

        public const byte mdb_response_expansion_pripheral_id = (byte)0x09;
        public const byte mdb_response_expansion_user_file_data = (byte)0x10;
        public const byte mdb_response_expansion_send_block = (byte)0x1d;
        public const byte mdb_response_expansion_retry_deny = (byte)0x1c;
        public const byte mdb_response_expansion_ok_to_send = (byte)0x1e;
        public const byte mdb_response_expansion_diagnostics_response = unchecked((byte)0xff);

        // ===========================================================
        // Sub Classes
        // ===========================================================

        /*
		 * msg_mdb_rsp_t
		 */
        public class msg_mdb_rsp_t : msg_i
        {

            public byte response;
            public msg_i body;

            public msg_mdb_rsp_t()
            {
            }

            public msg_mdb_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                response = buf[index++];

                Log.d(TAG, string.Format("received mdb: {0:D}", response));

                switch (response)
                {
                    case mdb_response_poll_just_reset:
                        // no body
                        break;
                    case mdb_response_poll_reader_config_data:
                        body = new msg_setup_config_data_rsp_t();
                        break;
                    case mdb_response_poll_display_req:
                        body = new msg_display_request_rsp_t();
                        break;
                    case mdb_response_poll_begin_session:
                        body = new msg_begin_session_rsp_t();
                        break;
                    case mdb_response_poll_session_cancel_req:
                        body = new msg_session_cancel_req_rsp_t();
                        break;
                    case mdb_response_poll_vend_approved:
                        body = new msg_vend_approved_rsp_t();
                        break;
                    case mdb_response_poll_vend_denied:
                        body = new msg_vend_denied_rsp_t();
                        break;
                    case mdb_response_poll_end_session:
                        body = new msg_end_session_rsp_t();
                        break;
                    case mdb_response_poll_cancelled:
                        body = new msg_cancelled_rsp_t();
                        break;
                    case mdb_response_poll_peripheral_id:
                        body = new msg_peripheral_id_rsp_t();
                        break;
                    case mdb_response_poll_malfunction_error:
                        body = new msg_malfunction_error_rsp_t();
                        break;
                    case mdb_response_poll_cmd_out_of_seq:
                        body = new msg_cmd_out_of_seq_rsp_t();
                        break;
                    case mdb_response_poll_revalue_approved:
                        body = new msg_revalue_approved_rsp_t();
                        break;
                    case mdb_response_poll_revalue_denied:
                        body = new msg_revalue_denied_rsp_t();
                        break;
                    case mdb_response_poll_revalue_limit_amount:
                        body = new msg_limit_amount_rsp_t();
                        break;
                    case mdb_response_poll_user_file_data:
                        break;
                    case mdb_response_poll_time_date_req:
                        break;
                    case mdb_response_poll_data_entry_req:
                        break;
                    case mdb_response_poll_data_entry_cancel:
                        break;
                    case mdb_response_poll_selection_request:
                        body = new msg_remote_selection_t();
                        break;
                    case mdb_response_poll_ftl_req_to_rcv:
                        body = new mdb_t.msg_ftl_req_to_receive_t();
                        break;
                    case mdb_response_poll_ftl_retry_deny:
                        break;
                    case mdb_response_poll_ftl_send_block:
                        body = new mdb_t.msg_ftl_send_block_t();
                        break;
                    case mdb_response_poll_ok_to_send:
                        body = new mdb_t.msg_ftl_ok_to_send_t();
                        break;
                    case mdb_response_poll_req_to_send:
                        body = new mdb_t.msg_ftl_req_to_send_t();
                        break;
                    case mdb_response_sessions_status:
                        body = new mdb_t.msg_sessions_status_t();
                        break;
                    case mdb_response_reader_state_rsp:
                        body = new mdb_t.msg_reader_state_t();
                        break;
                    case mdb_response_poll_diagnostics_response:
                    default:
                        Log.d(TAG, "not implemented : " + Convert.ToString(response));
                        break;
                }

                // body length is payload length minus the mdb header length
                int body_len = buf_len - (index - start_index);

                if (body != null)
                {
                    index += body.decode(buf, index, body_len);
                }

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = response;

                if (body != null)
                {
                    index += body.encode(buf, index, buf_len - index);
                }

                return index - enc_len;
            }
        }

        /*
		 * msg_setup_config_data_rsp_t
		 */
        public class msg_setup_config_data_rsp_t : msg_i
        {

            public byte reader_feature_level;
            public byte country_code_high;
            public byte country_code_low;
            public byte scale_factor;
            public byte decimal_places;
            public byte app_max_response_time;
            public byte misc_options;

            public msg_setup_config_data_rsp_t()
            {
            }

            public msg_setup_config_data_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                reader_feature_level = buf[index++];
                country_code_high = buf[index++];
                country_code_low = buf[index++];
                scale_factor = buf[index++];
                decimal_places = buf[index++];
                app_max_response_time = buf[index++];
                misc_options = buf[index++];

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = reader_feature_level;
                buf[index++] = country_code_high;
                buf[index++] = country_code_low;
                buf[index++] = scale_factor;
                buf[index++] = decimal_places;
                buf[index++] = app_max_response_time;
                buf[index++] = misc_options;

                return index - enc_len;
            }
        }

        /*
		 * msg_display_request_rsp_t
		 */
        public class msg_display_request_rsp_t : msg_i
        {

            public byte display_time;
            public byte[] display_data;

            public msg_display_request_rsp_t()
            {
            }

            public msg_display_request_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                display_data = new byte[buf_len];

                //            display_time = buf[index++];
                index += ByteArrayUtils.byteArrToSubByteArray(buf, index, display_data);

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                buf[index++] = display_time;
                index += ByteArrayUtils.subByteArrToByteArray(buf, index, display_data);

                return index - enc_len;
            }
        }

        /*
		 * msg_reset_t
		 */
        public class msg_begin_session_rsp_t : msg_i
        {

            public ushort funds_available;

            public msg_begin_session_rsp_t()
            {
            }

            public msg_begin_session_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                funds_available = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                // todo: if length is longer, this is > 1 protocol version

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                index += ByteArrayUtils.shortToByteArray(buf, index, funds_available);

                return index - enc_len;
            }
        }

        /*
		 * msg_session_cancel_req_rsp_t
		 */
        public class msg_session_cancel_req_rsp_t : msg_i
        {


            public msg_session_cancel_req_rsp_t()
            {
            }

            public msg_session_cancel_req_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_vend_approved_rsp_t
		 */
        public class msg_vend_approved_rsp_t : msg_i
        {

            public ushort vend_amount;

            public msg_vend_approved_rsp_t()
            {
            }

            public msg_vend_approved_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                vend_amount = ByteArrayUtils.byteArrToShort(buf, index);
                index += 2;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                index += ByteArrayUtils.byteArrToShort(buf, index);

                return index - enc_len;
            }
        }

        /*
		 * msg_vend_denied_rsp_t
		 */
        public class msg_vend_denied_rsp_t : msg_i
        {

            public msg_vend_denied_rsp_t()
            {
            }

            public msg_vend_denied_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_end_session_rsp_t
		 */
        public class msg_end_session_rsp_t : msg_i
        {


            public msg_end_session_rsp_t()
            {
            }

            public msg_end_session_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_cancelled_rsp_t
		 */
        public class msg_cancelled_rsp_t : msg_i
        {


            public msg_cancelled_rsp_t()
            {
            }

            public msg_cancelled_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_peripheral_id_rsp_t
		 */
        public class msg_peripheral_id_rsp_t : msg_i
        {


            public msg_peripheral_id_rsp_t()
            {
            }

            public msg_peripheral_id_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_malfunction_error_rsp_t
		 */
        public class msg_malfunction_error_rsp_t : msg_i
        {


            public msg_malfunction_error_rsp_t()
            {
            }

            public msg_malfunction_error_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_cmd_out_of_seq_rsp_t
		 */
        public class msg_cmd_out_of_seq_rsp_t : msg_i
        {


            public msg_cmd_out_of_seq_rsp_t()
            {
            }

            public msg_cmd_out_of_seq_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_revalue_approved_rsp_t
		 */
        public class msg_revalue_approved_rsp_t : msg_i
        {


            public msg_revalue_approved_rsp_t()
            {
            }

            public msg_revalue_approved_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_revalue_denied_rsp_t
		 */
        public class msg_revalue_denied_rsp_t : msg_i
        {


            public msg_revalue_denied_rsp_t()
            {
            }

            public msg_revalue_denied_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_limit_amount_rsp_t
		 */
        public class msg_limit_amount_rsp_t : msg_i
        {


            public msg_limit_amount_rsp_t()
            {
            }

            public msg_limit_amount_rsp_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {

                int start_index = index;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {

                int enc_len = index;

                return index - enc_len;
            }
        }

        /*
		 * msg_remote_selection_t
		 */
        public class msg_remote_selection_t : msg_i
        {
            public ushort funds_available;
            public ushort payment_media_id;
            public byte payment_type;
            public ushort payment_data;
            public ushort item_number;
            public int item_options;

            // todo: look at mdb 4.3, pages 145-146

            public msg_remote_selection_t()
            {
            }

            public msg_remote_selection_t(byte[] buf, int index, int len)
            {
                decode(buf, index, len);
            }

            public override int decode(byte[] buf, int index, int buf_len)
            {
                int start_index = index;

                funds_available = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                payment_media_id = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                payment_type = buf[index++];
                payment_data = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                item_number = ByteArrayUtils.byteArrToShort(buf, index); index += 2;
                item_options = ByteArrayUtils.byteArrToInteger(buf, index); index += 4;

                return index - start_index;
            }

            public override int encode(byte[] buf, int index, int buf_len)
            {
                int enc_len = index;

                return index - enc_len;
            }
        }

        // ===========================================================
        // Fields
        // ===========================================================

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================
    }

}