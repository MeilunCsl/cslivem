using System.Collections.Generic;

namespace com.bitmick.marshall.protocol
{
    using System;
    using com.bitmick.marshall.models;
    using com.bitmick.marshall.utils;

    public class vmc_vend_t : vmc_client_t
    {

        // ===========================================================
        // Constants
        // ===========================================================

        internal static readonly string TAG = typeof(vmc_vend_t).Name;

        private const int MULTI_VEND_PROD_CODE = 0xFFFF;
        private const int MUTLTI_VEND_MAX_PRODUCTS = ((marshall_t.MARSHALL_MSG_MAX_SIZE - 12) / 10);

        private const int vmc_vend_state_init_e = 0;
        private const int vmc_vend_state_idle_e = 1;
        private const int vmc_vend_state_reader_enabled_e = 2;
        private const int vmc_vend_state_wait_vend_request_e = 3;
        private const int vmc_vend_state_vend_process_e = 4;
        private const int vmc_vend_state_wait_end_session_e = 5;
        private const int vmc_vend_state_reader_disable_e = 6;

        private const int vmc_event_init_done_e = 0;
        private const int vmc_event_reader_enable_e = 1;
        private const int vmc_event_session_begin_e = 2;
        private const int vmc_event_session_cancel_e = 3;
        private const int vmc_event_vend_request_e = 4;
        private const int vmc_event_vend_approved_e = 5;
        private const int vmc_event_vend_denied_e = 6;
        private const int vmc_event_session_end_e = 7;
        private const int vmc_event_session_close_e = 8;
        private const int vmc_event_cash_sale_e = 9;
        private const int vmc_event_pp_pay_e = 10;
        private const int vmc_event_send_transfer_data_e = 11;
        private const int vmc_event_session_status_req = 12;
        private const int vmc_event_session_status_rsp = 13;
        private const int vmc_event_reader_state_req = 14;
        private const int vmc_event_reader_state_rsp = 15;
        private const int vmc_event_remote_selection_notify = 16;
        private const int vmc_event_remote_selection_deny = 17;
        private const int vmc_event_qr_ereceipt_e = 18;
        private const int vmc_event_vmc_reader_event_e = 19;

        public class vend_session_data_t
        {
            public long transaction_id;
            public ushort choose_product_timeout;
            public int card_type;
            public int card_entry_mode;
            public String card_bin;
            public String card_bin_hash;
            public String prop_card_uid;
            public int vmc_auth_status;
            public int com_status;
            public String excel_data;
            public String cc_last_4_digits;

            public vend_session_data_t()
            {
                transaction_id = -1;
                choose_product_timeout = 0;
                card_type = -1;
                card_entry_mode = -1;
                card_bin = null;
                card_bin_hash = null;
                prop_card_uid = null;
                vmc_auth_status = -1;
                com_status = -1;
                excel_data = null;
                cc_last_4_digits = null;
            }
        }

        public class vend_session_t
        {
            public int funds_avail;

            public int session_type;

            // user should set this, usually  in case user cancels or failed to dispense
            // please look at session_status_xxxxxxx
            public int session_status;

            public vend_session_data_t data;

            public List<vend_item_t> products_list;

            public vend_session_t(int code, int quantity, byte unit_of_measure, int price)
            {
                init();

                products_list = new List<vend_item_t>();
                products_list.Add(new vend_item_t((ushort)code, (ushort)price, quantity, unit_of_measure));
            }

            public vend_session_t(List<vend_item_t> list)
            {
                init();
                products_list = list;
            }

            private void init()
            {
                funds_avail = 0;
                session_status = session_status_ok_e;
            }
        }

        public class cash_sale_t
        {
            public int product_code;
            public int product_price;

            public cash_sale_t(int code, int price)
            {
                product_code = code;
                product_price = price;
            }
        }

        public class vend_item_t
        {
            public const int UNIT_DONT_CARE = 0;

            public ushort code;
            public ushort price;
            public int    qty;
            public byte unit;

            public vend_item_t(ushort _code, ushort _price, int _qty, byte _unit)
            {
                code = _code;
                price = _price;
                qty = _qty;
                unit = _unit;
            }
        }

        // card type
        public const int card_type_unknown_e = 0;
        public const int card_type_proprietary_e = 1;
        public const int card_type_visa_e = 2;
        public const int card_type_mastercard_e = 3;
        public const int card_type_china_union_pay_e = 4;
        public const int card_type_maestro_e = 5;
        public const int card_type_interac_e = 6;
        public const int card_type_monyx_card_e = 7;
        public const int card_type_amex_e = 8;
        public const int card_type_diners_e = 9;
        public const int card_type_discover_e = 10;
        public const int card_type_eftpos_e = 11;
        public const int card_type_jcb_e = 12;
        public const int card_type_magstripe_e = 13;
        public const int card_type_monyx_app_prepaid_e = 14;
        public const int card_type_monyx_padd_balance_e = 15;

        // card entry type
        public const int card_entry_type_msr_swipe_e = 1;
        public const int card_entry_type_contactless_e = 2;
        public const int card_entry_type_contact_e = 3;
        public const int card_entry_type_mifare_e = 4;
        public const int card_entry_type_hid_e = 5;
        public const int card_entry_type_nfc_e = 6;
        public const int card_entry_type_cnous_e = 7;
        public const int card_entry_type_keypad_e = 8;

        public const int vmc_auth_status_approved_e = 0;
        public const int vmc_auth_status_declined_e = 1;

        // session type
        public const int session_type_credit_e = 0x00;
        public const int session_type_info_e = 0x01;
        public const int session_type_none_e = 0xff;

        // session status (for close session)
        public const int session_status_ok_e = 0x00;
        public const int session_status_user_cancel_e = 0x01;
        public const int session_status_fail_to_dispense_e = 0x02;
        public const int session_status_session_timeout_e = 0x03;
        public const int session_status_vend_denied_e = 0x04;


        public const int ereceipt_type_dynamic_qr_e = 0x00;
        public const int ereceipt_type_static_ereceipt_e = 0x01;
        public const int ereceipt_type_dynamic_ereceipt_e = 0x02;

        public const int remote_vend_option_not_last = 0x01;

        public const int selection_deny_reason_unknown_e = 0x00;
        public const int selection_deny_reason_not_exist_e = 0x01;
        public const int selection_deny_reason_empty_e = 0x02;
        public const int selection_deny_reason_defective_e = 0x03;
        public const int selection_deny_reason_ingridient_over_e = 0x04;
        public const int selection_deny_reason_blocked_e = 0x05;
        public const int selection_deny_reason_inhibited_e = 0x06;
        public const int selection_deny_reason_product_expired_e = 0x07;
        public const int selection_deny_reason_temperature_out_of_range_e = 0x08;
        public const int selection_deny_reason_busy_wrong_mode_e = 0x09;
        public const int selection_deny_reason_insufficient_funds_e = 0x0a;
        public const int selection_deny_reason_machine_busy_e = 0xff;

        public abstract class vend_callbacks_t
        {
            // called when vmc framework is ready to start session (after a link has been established or a previouse session has ended)
            public abstract void onReady(vend_session_t session);

            // called when a client swipes a credit-card
            public abstract void onSessionBegin(int funds_avail);

            // on event of received data
            public abstract void onTransactionInfo(vend_session_data_t data);

            // the vending request has been approved
            public abstract bool onVendApproved(vend_session_t session);

            // the vending request has been denied
            public abstract void onVendDenied(vend_session_t session);

            // transaction settlement
            public abstract void onSettlement(bool success);

            // various status messages, see marshall_t.status_<xxxx> enum
            public abstract void onStatus(int status);

            // various status messages, see marshall_t.status_<xxxx> enum
            public abstract void onOpenedSessions(ushort[] sessions);

            // various status messages, see marshall_t.status_<xxxx> enum
            public abstract void onReaderState(bool enabled);

            // remote vend. for options, see vmc_vend_t.remote_vend_option_<xxx> bitmap
            public abstract void onRemoteVend(int avail_funds, int product_code, int options);

            // ereceipt feature. see vmc_vend_t.ereceipt_type_<xxx>
            public abstract void onReceipt(int ereceipt_type, String data);
        }

        // ===========================================================
        // Fields
        // ===========================================================

        private vmc_link m_vmc_link;
        private int m_vend_state;

        private vend_session_data_t m_session_data;
        private vend_session_t m_current_session;
        private vend_callbacks_t m_vend_callbacks;

        private bool m_in_process;
        private int m_session_type;

        private vmc_configuration m_vmc_configuration;

        // ===========================================================
        // Abstract methods
        // ===========================================================

        // ===========================================================
        // Constructors
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public vmc_vend_t()
        {
            // todo: how to call base constructor
            init();
        }

        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void start()
        {

            if (m_vend_callbacks == null)
            {
                Log.d(TAG, "cannot start vend process without registering vend callbacks");
                return;
            }

            // start thread
            base.start();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void onReady(vmc_link link)
        {
            m_vmc_link = link;

            m_vmc_configuration = m_vmc_link.get_configuration();

            m_in_process = false;

            notify(vmc_event_init_done_e, null);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void onCommError()
        {
            init();
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public override void onTimerTick(long ms)
        {
            base.onTimerTick(ms);
        }


        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        // on vmc_link thread context
        public override bool handleMarshallMessage(marshall_t.msg_marshall_t msg)
        {
            switch (msg.func_code)
            {
                case marshall_t.marshall_func_code_status:
                    if (true)
                    {
                        marshall_t.msg_status_t status_body = (marshall_t.msg_status_t)msg.body;

                        Log.d(TAG, string.Format("received status: {0}", status_body.status));
                        switch (status_body.status)
                        {
                            case marshall_t.msg_status_t.status_settlement:
                                {
                                    bool success = (status_body.data[0] == 0);
                                    Log.d(TAG, string.Format("settlement {0}", success ? "done" : "error"));

                                    m_vend_callbacks.onSettlement(success);
                                }
                                break;
                            case marshall_t.msg_status_t.status_unexpected_timeout:
                            // wait for end-session
                            default:
                                //if (status_body.status >= marshall_t.status_vpos_call_your_bank &&
                                //    status_body.status <= marshall_t.status_vpos_insert_or_swipe_another_card)
                                m_vend_callbacks.onStatus(status_body.status);
                                break;
                        }
                    }
                    break;
                case marshall_t.marshall_func_code_trasfer_data:
                    if (true)
                    {
                        marshall_t.msg_transfer_data_t transfer_data = (marshall_t.msg_transfer_data_t)msg.body;

                        {
                            m_session_data = new vend_session_data_t();

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_transaction_id) != 0)
                                m_session_data.transaction_id = ByteArrayUtils.byteArrToLong(transfer_data.transaction_id, 0);

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_choose_product_timeout) != 0)
                                m_session_data.choose_product_timeout = transfer_data.choose_product_timeout;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_card_type) != 0)
                                m_session_data.card_type = transfer_data.card_type;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_card_entry_mode) != 0)
                                m_session_data.card_entry_mode = transfer_data.card_entry_mode;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_card_bin) != 0)
                                m_session_data.card_bin = System.Text.Encoding.Default.GetString(transfer_data.card_bin);

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_card_bin_hash) != 0)
                                m_session_data.card_bin_hash = StringUtils.buf2hex_str(transfer_data.card_bin_hash);

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_prop_card_uid) != 0)
                            {

                                // mifare,
                                String s = null;
                                switch (m_session_data.card_entry_mode)
                                {
                                    case card_entry_type_msr_swipe_e:
                                        if (true)
                                        {
                                            // some cards are encoded as integer, little endian
                                            if (transfer_data.prop_card_uid.Length == 4)
                                            {
                                                int val = ByteArrayUtils.byteArrToInteger(transfer_data.prop_card_uid, 0);
                                                s = StringUtils.int2Str(val);
                                            }
                                            else
                                            {
                                                s = StringUtils.byteArray2String(transfer_data.prop_card_uid);
                                            }
                                        }
                                        break;
                                    case card_entry_type_mifare_e:
                                        if (true)
                                        {
                                            switch (m_session_data.card_type)
                                            {
                                                case card_type_proprietary_e:
                                                    if (transfer_data.prop_card_uid.Length == 4)
                                                    {
                                                        int val = ByteArrayUtils.byteArrToInteger(transfer_data.prop_card_uid, 0);
                                                        s = String.Format("%08x", val);
                                                    }
                                                    else
                                                    {
                                                        s = StringUtils.buf2hex_str(transfer_data.prop_card_uid);
                                                    }
                                                    break;
                                                default:
                                                    s = StringUtils.buf2hex_str(transfer_data.prop_card_uid);
                                                    break;
                                            }

                                        }
                                        break;
                                    default:
                                        if (true)
                                        {
                                            s = StringUtils.buf2hex_str(transfer_data.prop_card_uid);
                                        }
                                        break;
                                }

                                m_session_data.prop_card_uid = s;
                            }

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_vmc_auth_status) != 0)
                                m_session_data.vmc_auth_status = transfer_data.vmc_auth_status;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_com_status) != 0)
                                m_session_data.com_status = transfer_data.com_status;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_excel_type) != 0)
                                m_session_data.card_entry_mode = transfer_data.card_entry_mode;

                            if ((transfer_data.encode_bitmap & marshall_t.msg_transfer_data_t.transfer_data_encode_cc_last_4_digits) != 0)
                                m_session_data.cc_last_4_digits = System.Text.Encoding.Default.GetString(transfer_data.cc_last_4_digits);

                            if (m_current_session != null)
                                m_current_session.data = m_session_data;

                            m_vend_callbacks.onTransactionInfo(m_session_data);
                        }
                    }
                    break;
                case marshall_t.marshall_func_code_mdb_command:
                    if (true)
                    {
                        // received mdb response
                        marshall_t.msg_mdb_t mdb_body = (marshall_t.msg_mdb_t)msg.body;
                        mdb_rsp_t.msg_mdb_rsp_t rsp = (mdb_rsp_t.msg_mdb_rsp_t)mdb_body.message;

                        switch (rsp.response)
                        {
                            case mdb_rsp_t.mdb_response_poll_just_reset:
                                Log.d(TAG, "mdb_response_poll_just_reset");
                                break;
                            case mdb_rsp_t.mdb_response_poll_reader_config_data:
                                Log.d(TAG, "mdb_response_poll_reader_config_data");
                                break;
                            case mdb_rsp_t.mdb_response_poll_display_req:
                                Log.d(TAG, "mdb_response_poll_display_req");
                                break;
                            case mdb_rsp_t.mdb_response_poll_begin_session:
                                mdb_rsp_t.msg_begin_session_rsp_t begin_session = (mdb_rsp_t.msg_begin_session_rsp_t)rsp.body;

                                Log.d(TAG, "received begin session");
                                // notify state-machine
                                notify(vmc_event_session_begin_e, ((int)begin_session.funds_available & 0x0000ffff));
                                break;
                            case mdb_rsp_t.mdb_response_poll_session_cancel_req:
                                Log.d(TAG, "received session cancel");
                                // notify state-machine
                                notify(vmc_event_session_cancel_e, null);
                                break;
                            case mdb_rsp_t.mdb_response_poll_vend_approved:
                                mdb_rsp_t.msg_vend_approved_rsp_t vend_approved = (mdb_rsp_t.msg_vend_approved_rsp_t)rsp.body;

                                Log.d(TAG, "received vend approved");

                                // notify state-machine
                                notify(vmc_event_vend_approved_e, vend_approved.vend_amount);
                                break;
                            case mdb_rsp_t.mdb_response_poll_vend_denied:
                                Log.d(TAG, "received vend denied");
                                // notify state-machine
                                notify(vmc_event_vend_denied_e, null);
                                break;
                            case mdb_rsp_t.mdb_response_poll_end_session:
                                Log.d(TAG, "received end session");
                                // notify state-machine
                                notify(vmc_event_session_end_e, null);
                                break;
                            case mdb_rsp_t.mdb_response_poll_cancelled:
                                Log.d(TAG, "mdb_response_poll_cancelled");
                                break;
                            case mdb_rsp_t.mdb_response_poll_peripheral_id:
                                Log.d(TAG, "mdb_response_poll_peripheral_id");
                                break;
                            case mdb_rsp_t.mdb_response_poll_malfunction_error:
                                Log.d(TAG, "mdb_response_poll_malfunction_error");
                                break;
                            case mdb_rsp_t.mdb_response_poll_cmd_out_of_seq:
                                Log.d(TAG, "mdb_response_poll_cmd_out_of_seq");
                                break;
                            case mdb_rsp_t.mdb_response_poll_revalue_approved:
                                Log.d(TAG, "mdb_response_poll_revalue_approved");
                                break;
                            case mdb_rsp_t.mdb_response_poll_revalue_denied:
                                Log.d(TAG, "mdb_response_poll_revalue_denied");
                                break;
                            case mdb_rsp_t.mdb_response_poll_revalue_limit_amount:
                                Log.d(TAG, "mdb_response_poll_revalue_limit_amount");
                                break;
                            case mdb_rsp_t.mdb_response_poll_user_file_data:
                                Log.d(TAG, "mdb_response_poll_user_file_data");
                                break;
                            case mdb_rsp_t.mdb_response_poll_time_date_req:
                                Log.d(TAG, "mdb_response_poll_time_date_req");
                                break;
                            case mdb_rsp_t.mdb_response_poll_data_entry_req:
                                Log.d(TAG, "mdb_response_poll_data_entry_req");
                                break;
                            case mdb_rsp_t.mdb_response_poll_data_entry_cancel:
                                Log.d(TAG, "mdb_response_poll_data_entry_cancel");
                                break;
                            case mdb_rsp_t.mdb_response_poll_selection_request:
                                if (true)
                                {
                                    mdb_rsp_t.msg_remote_selection_t remote_selection = (mdb_rsp_t.msg_remote_selection_t)msg.body;
                                    Log.d(TAG, "mdb_response_poll_selection_request");

                                    // todo: notify upper layer
                                    notify(vmc_event_remote_selection_notify, remote_selection);
                                }
                                break;
                            case mdb_rsp_t.mdb_response_poll_ftl_req_to_rcv:
                                Log.d(TAG, "mdb_response_poll_ftl_req_to_rcv");
                                mdb_t.msg_ftl_req_to_receive_t rcv_req = (mdb_t.msg_ftl_req_to_receive_t)rsp.body;
                                break;
                            case mdb_rsp_t.mdb_response_poll_ftl_retry_deny:
                                Log.d(TAG, "mdb_response_poll_ftl_retry_deny");
                                break;
                            case mdb_rsp_t.mdb_response_poll_ftl_send_block:
                                Log.d(TAG, "mdb_response_poll_ftl_send_block");
                                mdb_t.msg_ftl_send_block_t send_block = (mdb_t.msg_ftl_send_block_t)rsp.body;
                                break;
                            case mdb_rsp_t.mdb_response_poll_ok_to_send:
                                Log.d(TAG, "mdb_response_poll_ok_to_send");
                                break;
                            case mdb_rsp_t.mdb_response_poll_req_to_send:
                                Log.d(TAG, "mdb_response_poll_req_to_send");
                                mdb_t.msg_ftl_req_to_send_t snd_req = (mdb_t.msg_ftl_req_to_send_t)rsp.body;
                                break;
                            case mdb_rsp_t.mdb_response_sessions_status:
                                mdb_t.msg_sessions_status_t sessions = (mdb_t.msg_sessions_status_t)rsp.body;
                                Log.d(TAG, String.Format("got {0} opened sessions", sessions.num_opened_sessions));

                                notify(vmc_event_session_status_rsp, sessions);
                                break;
                            case mdb_rsp_t.mdb_response_reader_state_rsp:
                                mdb_t.msg_reader_state_t state = (mdb_t.msg_reader_state_t)rsp.body;
                                Log.d(TAG, String.Format("reader state: {0}", (state.state != 0) ? "enabled" : "disabled"));

                                notify(vmc_event_reader_state_rsp, state);
                                break;
                            case mdb_rsp_t.mdb_response_poll_diagnostics_response:
                                Log.d(TAG, "mdb_response_poll_diagnostics_response");
                                break;
                            default:
                                Log.d(TAG, string.Format("unknown mdb response: {0}", rsp.response));
                                break;
                        }
                    }
                    break;
                case marshall_t.marshall_func_code_ereceipt_e:
                    if (true)
                    {
                        marshall_t.msg_ereceipt_t ereceipt = (marshall_t.msg_ereceipt_t)msg.body;

                        notify(vmc_event_qr_ereceipt_e, ereceipt);
                    }
                    break;
                default:
                    break;
            }
            return false;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private bool change_state(int new_state)
        {
            //Log.d(TAG, String.format("changed state, from{0} to {1}", m_vend_state, new_state));
            bool next_action = false;

            m_vend_state = new_state;

            switch (new_state)
            {
                case vmc_vend_state_init_e:
                    break;
                case vmc_vend_state_idle_e:

                    m_in_process = false;

                    // no session currently
                    m_session_type = session_type_none_e;

                    bool start = false;

                    start = m_vmc_configuration.reader_always_on;
                    start |= ((m_current_session != null && (m_current_session.session_status == session_status_vend_denied_e)) &&
                            (m_vmc_configuration.vend_denied_policy == vmc_configuration.vend_denied_policy_persist));

                    if (start)
                        session_start(session_type_credit_e);

                    vend_session_t curr_session = m_current_session;
                    m_current_session = null;

                    m_vend_callbacks.onReady(curr_session);
                    break;
                case vmc_vend_state_reader_enabled_e:
                    readerEnable();
                    next_action = true;
                    break;
                case vmc_vend_state_wait_vend_request_e:
                    break;
                case vmc_vend_state_vend_process_e:
                    break;
                case vmc_vend_state_wait_end_session_e:
                    break;
                case vmc_vend_state_reader_disable_e:
                    readerDisable();

                    next_action = true;
                    break;
                default:
                    break;
            }

            return next_action;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        // on vmc_vend context
        protected override bool handleMessage(MsgObject msg)
        {
            bool action = false;

            base.handleMessage(msg);

            //Log.d(TAG, string.Format("received event: {0}, state: {1}", msg.id, m_vend_state));

            do
            {
                action = false;

                switch (m_vend_state)
                {
                    case vmc_vend_state_init_e:
                        {
                            switch (msg.id)
                            {
                                case vmc_event_init_done_e:
                                    action = change_state(vmc_vend_state_idle_e);
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case vmc_vend_state_idle_e:
                    case vmc_vend_state_reader_enabled_e:
                        {
                            // wait for reader enabled

                            switch (msg.id)
                            {
                                case vmc_event_init_done_e:
                                    action = change_state(vmc_vend_state_idle_e);
                                    break;
                                case vmc_event_session_status_req:
                                    vendSessionsStatus();
                                    break;
                                case vmc_event_reader_state_req:
                                    readerStateRequest();
                                    break;
                                case vmc_event_session_status_rsp:
                                    if (true)
                                    {
                                        mdb_t.msg_sessions_status_t sessions = (mdb_t.msg_sessions_status_t)msg.data;

                                        // notify user about opened sessions
                                        m_vend_callbacks.onOpenedSessions(sessions.sessions);
                                    }
                                    break;
                                case vmc_event_reader_state_rsp:
                                    if (true)
                                    {
                                        mdb_t.msg_reader_state_t state = (mdb_t.msg_reader_state_t)msg.data;

                                        // notify user about reader state
                                        m_vend_callbacks.onReaderState(state.state != 0);
                                    }
                                    break;
                                case vmc_event_reader_enable_e:
                                    change_state(vmc_vend_state_reader_enabled_e);
                                    break;
                                case vmc_event_session_close_e:
                                    {
                                        vend_session_t session = (vend_session_t)msg.data;

                                        Log.d(TAG, "session close");

                                        byte status;

                                        switch (session.session_status)
                                        {
                                            case session_status_ok_e:
                                                status = mdb_req_t.mdb_close_session_status_ok;
                                                break;
                                            case session_status_user_cancel_e:
                                                status = mdb_req_t.mdb_close_session_status_user_cancel;
                                                break;
                                            case session_status_fail_to_dispense_e:
                                            case session_status_session_timeout_e:
                                            default:
                                                status = mdb_req_t.mdb_close_session_status_fail_to_dispense;
                                                break;
                                        }
                                        vend_item_t item = session.products_list[0];

                                        vendCloseSession((byte)status, (ushort)item.code, (ushort)item.price, (int)item.qty, item.unit);
                                    }
                                    break;
                                case vmc_event_session_begin_e:
                                    int funds_avail = (int)msg.data;

                                    Log.d(TAG, string.Format("session_begin. funds available: {0}", funds_avail));

                                    switch (m_session_type)
                                    {
                                        case session_type_credit_e:
                                            // notify user for a session begin
                                            m_vend_callbacks.onSessionBegin(funds_avail);

                                            // move to vend_process state
                                            action = change_state(vmc_vend_state_wait_vend_request_e);
                                            break;
                                        case session_type_info_e:
                                            {
                                                m_current_session = new vmc_vend_t.vend_session_t(0xffff, 0, (byte)0, 0);

                                                // session type
                                                vendSessionType(session_type_info_e);
                                                
                                                vend_item_t item = m_current_session.products_list[0];

                                                // vend request
                                                vendRequest((ushort)item.code, (ushort)item.price);

                                                // move to vend_process state
                                                action = change_state(vmc_vend_state_vend_process_e);
                                            }
                                            break;
                                        default:
                                            Log.d(TAG, "error: specify session type");
                                            break;
                                    }
                                    break;
                                case vmc_event_session_cancel_e:
                                    if (true)
                                    {
                                        if (m_vend_state == vmc_vend_state_reader_enabled_e)
                                            action = change_state(vmc_vend_state_reader_disable_e);
                                    }
                                    break;
                                case vmc_event_pp_pay_e:
                                    // send pay message, wait for session_begin
                                    vendExPay((byte[])msg.data);
                                    break;
                                case vmc_event_vmc_reader_event_e:
                                    if (true)
                                    {
                                        marshall_t.msg_reader_t reader = (marshall_t.msg_reader_t)msg.data;

                                        vmcReaderEvent(reader);
                                    }
                                    break;
                                case vmc_event_cash_sale_e:
                                    if (true)
                                    {
                                        cash_sale_t data = (cash_sale_t)msg.data;
                                        vendCashSale((ushort)data.product_code, (ushort)data.product_price);
                                    }
                                    break;
                                case vmc_event_vend_request_e:
                                    if (m_vmc_configuration.always_idle)
                                    {
                                        m_current_session = (vend_session_t)msg.data;

                                        List<vend_item_t> list = m_current_session.products_list;

                                        // check if it's a multi-vend setup, note that multi-session does not support multi-vend
                                        Boolean multi_vend = (m_vmc_configuration.multi_vend_support && !m_vmc_configuration.multi_session_support);

                                        if (multi_vend)
                                        {
                                            // send multi-vend request
                                            vendExMultiVendRequest(m_current_session.products_list);
                                        }
                                        else
                                        {
                                            vend_item_t item = m_current_session.products_list[0];

                                            // vend request
                                            vendRequest((ushort)item.code, (ushort)item.price);
                                        }

                                        // wait for vend approved / denied
                                        action = change_state(vmc_vend_state_vend_process_e);
                                    }
                                    break;
                                case vmc_event_remote_selection_notify:
                                    if (true)
                                    {
                                        mdb_rsp_t.msg_remote_selection_t remote_selection = (mdb_rsp_t.msg_remote_selection_t)msg.data;

                                        if (m_vend_callbacks != null)
                                            m_vend_callbacks.onRemoteVend(remote_selection.funds_available, remote_selection.item_number, remote_selection.item_options);
                                    }
                                    break;
                                case vmc_event_remote_selection_deny:
                                    if (true)
                                    {
                                        byte reason = (byte)msg.data;
                                        vendSelectionDenied(0, reason);
                                    }
                                    break;

                                default:
                                    break;
                            }
                            // wait for vend process initiation
                        }
                        break;
                    case vmc_vend_state_wait_vend_request_e:
                        switch (msg.id)
                        {
                            case vmc_event_init_done_e:
                                action = change_state(vmc_vend_state_idle_e);
                                break;
                            case vmc_event_send_transfer_data_e:
                                if (true)
                                {
                                    marshall_t.msg_transfer_data_t data = (marshall_t.msg_transfer_data_t)msg.data;

                                    // sent transfer data
                                    transferData(data);
                                }
                                break;
                            // this event is sent by the user (vmc->vpos)
                            case vmc_event_vend_request_e:
                                if (true)
                                {
                                    m_current_session = (vend_session_t)msg.data;

                                    List<vend_item_t> list = m_current_session.products_list;

                                    // check if it's a multi-vend setup, note that multi-session does not support multi-vend
                                    Boolean multi_vend = (m_vmc_configuration.multi_vend_support && !m_vmc_configuration.multi_session_support);

                                    if (multi_vend)
                                    {
                                        // send multi-vend request
                                        vendExMultiVendRequest(m_current_session.products_list);
                                    }
                                    else
                                    {
                                        vend_item_t item = m_current_session.products_list[0];

                                        // vend request
                                        vendRequest((ushort)item.code, (ushort)item.price);
                                    }

                                    // wait for vend approved / denied
                                    action = change_state(vmc_vend_state_vend_process_e);
                                }
                                break;
                            case vmc_event_session_cancel_e:
                                if (true)
                                {
                                    // transmit session cancel
                                    vendCancel();

                                    // transmit session complete
                                    vendSessionComplete();

                                    // move to next state
                                    action = change_state(vmc_vend_state_wait_end_session_e);
                                }
                                break;
                            default:
                                break;
                        }
                        break;
                    case vmc_vend_state_vend_process_e:
                        if (true)
                        {
                            switch (msg.id)
                            {
                                case vmc_event_init_done_e:
                                    action = change_state(vmc_vend_state_idle_e);
                                    break;
                                case vmc_event_send_transfer_data_e:
                                    marshall_t.msg_transfer_data_t data = (marshall_t.msg_transfer_data_t)msg.data;

                                    // sent transfer data
                                    transferData(data);
                                    break;
                                case vmc_event_vend_approved_e:
                                    bool result = m_vend_callbacks.onVendApproved(m_current_session);

                                    if (result)
                                    {
                                        // check if it's a multi-vend setup, note that multi-session does not support multi-vend
                                        Boolean multi_vend = (m_vmc_configuration.multi_vend_support && !m_vmc_configuration.multi_session_support);

                                        if (multi_vend)
                                        {
                                            vendExMultiVendSuccess(m_current_session.products_list);
                                        }
                                        else
                                        {
                                            vend_item_t item = m_current_session.products_list[0];

                                            // vend request
                                            vendSuccess((ushort)item.code);
                                        }

                                    }
                                    else
                                    {
                                        vendFailure();
                                    }

                                    // transmit session complete
                                    vendSessionComplete();

                                    // move to next state
                                    action = change_state(vmc_vend_state_wait_end_session_e);
                                    break;
                                case vmc_event_vend_denied_e:
                                    vendSessionComplete();

                                    m_current_session.session_status = session_status_vend_denied_e;
                                    m_vend_callbacks.onVendDenied(m_current_session);

                                    action = change_state(vmc_vend_state_wait_end_session_e);
                                    break;
                                case vmc_event_session_cancel_e:

                                    // send vend cancel
                                    vendCancel();
                                    // and wait for vend_denied
                                    break;
                                default:
                                    break;
                            }
                        }
                        break;
                    case vmc_vend_state_wait_end_session_e:
                        if (true)
                        {
                            // wait for reader enabled
                            switch (msg.id)
                            {
                                case vmc_event_init_done_e:
                                    action = change_state(vmc_vend_state_idle_e);
                                    break;
                                case vmc_event_session_end_e:
                                    if (m_vmc_configuration.reader_always_on)
                                        action = change_state(vmc_vend_state_idle_e);
                                    else
                                    {
                                        if (m_vmc_configuration.vend_denied_policy != vmc_configuration.vend_denied_policy_persist)
                                            action = change_state(vmc_vend_state_reader_disable_e);
                                        else
                                            action = change_state(vmc_vend_state_idle_e);
                                    }
                                    break;
                                case vmc_event_qr_ereceipt_e:
                                    if (true)
                                    {
                                        marshall_t.msg_ereceipt_t ereceipt = (marshall_t.msg_ereceipt_t)msg.data;

                                        byte type = ereceipt.qr_type;
                                        String str = StringUtils.buf2hex_str(ereceipt.data);
                                        Log.d(TAG, String.Format("received e-receipt qr. type: {0}, data: {1}", type, str));

                                        if (m_vend_callbacks != null)
                                            m_vend_callbacks.onReceipt(type, str);
                                    }
                                    break;
                                default:
                                    break;

                            }
                            // wait for vend process initiation
                        }
                        break;
                    case vmc_vend_state_reader_disable_e:
                        action = change_state(vmc_vend_state_idle_e);
                        break;
                    default:
                        break;
                }
            } while (action);

            return true;
        }

        // ===========================================================
        // Methods
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void init()
        {

            m_vmc_link = null;
            m_vend_state = vmc_vend_state_init_e;
            m_in_process = false;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void reader(byte option)
        {
            m_vmc_link.transmit_marshall(marshall_t.mdb_req(mdb_req_t.reader_req(option)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vend(byte sub_command, ushort item_price, ushort item_number)
        {
            m_vmc_link.transmit_marshall(marshall_t.mdb_req(mdb_req_t.vend_req(sub_command, item_price, item_number)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void mdb_ex(byte sub_command, byte type)
        {
            m_vmc_link.transmit_marshall(marshall_t.mdb_req(mdb_req_t.mdb_ex(sub_command, type)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendExCloseSession(byte status, ushort item_price, ushort item_number, int quantity, byte unit_of_measure)
        {
            mdb_req_t.msg_vend_t msg_vend = new mdb_req_t.msg_vend_t();

            msg_vend.sub_command = mdb_req_t.mdb_sub_command_vend_close_session;
            msg_vend.status = status;
            msg_vend.item_price = item_price;
            msg_vend.item_number = item_number;
            msg_vend.quantity = quantity;

            m_vmc_link.transmit_marshall(marshall_t.mdb_req(new mdb_req_t.msg_mdb_req_t(mdb_req_t.mdb_command_vend, msg_vend)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendExPay(byte[] pp_number)
        {
            mdb_req_t.msg_ex_pay_t msg_pay = new mdb_req_t.msg_ex_pay_t();

            msg_pay.sub_command = mdb_req_t.mdb_sub_command_prepaid_pay;
            msg_pay.pp_number = pp_number;

            m_vmc_link.transmit_marshall(marshall_t.mdb_req(new mdb_req_t.msg_mdb_req_t(mdb_req_t.mdb_command_vend, msg_pay)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendExMultiVendRequest(List<vend_item_t> list)
        {
            mdb_req_t.msg_ex_multi_vend_req_t msg_multi_vend_req = new mdb_req_t.msg_ex_multi_vend_req_t();

            msg_multi_vend_req.sub_command = mdb_req_t.mdb_sub_command_multivend_request;

            int total = 0;  
            int price = 0;
            foreach (vend_item_t item in list)
            {
                msg_multi_vend_req.add(item.code, item.price, item.qty, item.unit);
                price += (item.price * item.qty);

                total++;
                if (total == MUTLTI_VEND_MAX_PRODUCTS)
                    break;
            }

            Log.d(TAG, String.Format("Vend Multi-Request, products: {0}, total: price: {1}", total, price));

            m_vmc_link.transmit_marshall(marshall_t.mdb_req(new mdb_req_t.msg_mdb_req_t(mdb_req_t.mdb_command_vend, msg_multi_vend_req)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendExMultiVendSuccess(List<vend_item_t> list)
        {
            mdb_req_t.msg_ex_multi_vend_success_t msg_multi_vend_success = new mdb_req_t.msg_ex_multi_vend_success_t();

            msg_multi_vend_success.sub_command = mdb_req_t.mdb_sub_command_multivend_success;

            int total = 0;
            int price = 0;
            foreach (vend_item_t item in list)
            {
                msg_multi_vend_success.add(item.code, item.price, item.qty, item.unit);
                price += (item.price * item.qty);

                total++;
                if (total == MUTLTI_VEND_MAX_PRODUCTS)
                    break;
            }

            Log.d(TAG, String.Format("Vend Multi-Sucess, products: {0}, total: price: {1}", total, price));

            m_vmc_link.transmit_marshall(marshall_t.mdb_req(new mdb_req_t.msg_mdb_req_t(mdb_req_t.mdb_command_vend, msg_multi_vend_success)));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void readerEnable()
        {
            Log.d(TAG, "Reader Enable");
            reader(mdb_req_t.mdb_sub_command_reader_enable);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void readerDisable()
        {
            Log.d(TAG, "Reader Disable");
            reader(mdb_req_t.mdb_sub_command_reader_disable);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void readerStateRequest()
        {
            Log.d(TAG, "Reader State request");
            reader(mdb_req_t.mdb_sub_command_reader_state_req);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void readerCancel()
        {
            Log.d(TAG, "Reader Cancel");
            reader(mdb_req_t.mdb_sub_command_reader_cancel);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendRequest(ushort item_number, ushort item_price)
        {
            Log.d(TAG, string.Format("Vend Request, product: {0}, price: {1}", item_number, item_price));
            vend(mdb_req_t.mdb_sub_command_vend_request, item_price, item_number);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendSuccess(ushort item_number)
        {
            Log.d(TAG, string.Format("Vend Success, product: {0}", item_number));

            vend(mdb_req_t.mdb_sub_command_vend_success, (ushort)0, item_number);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendSessionComplete()
        {
            Log.d(TAG, "Vend Session Complete");

            vend(mdb_req_t.mdb_sub_command_vend_session_complete, (ushort)0, (ushort)0);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendSelectionDenied(ushort item_number, byte reason)
        {
            Log.d(TAG, String.Format("Vend Success, product: {0}", item_number));

            m_vmc_link.transmit_marshall(marshall_t.mdb_req(mdb_req_t.mdb_vend_selection_denied(mdb_req_t.mdb_sub_command_selection_denied, item_number, reason)));
        }


        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendCloseSession(byte status, ushort item_number, ushort item_price, int quantity, byte unit_of_measure)
        {
            Log.d(TAG, string.Format("Vend End Session, prod: {0}, price: {1}, quantity: {2}", item_number, item_price, quantity));
            vendExCloseSession(status, item_price, item_number, quantity, unit_of_measure);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendSessionType(int type)
        {
            Log.d(TAG, string.Format("Vend Session Type: {0}", type));

            mdb_ex(mdb_req_t.mdb_sub_command_vend_session_type, (byte)type);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendSessionsStatus()
        {
            Log.d(TAG, "Requesting sessions");

            vend(mdb_req_t.mdb_sub_command_get_sessions_status, (ushort)0, (ushort)0);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendCancel()
        {
            Log.d(TAG, "Vend Cancel");

            vend(mdb_req_t.mdb_sub_command_vend_cancel, (ushort)0, (ushort)0);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendFailure()
        {
            Log.d(TAG, "Vend Failure");

            vend(mdb_req_t.mdb_sub_command_vend_failure, (ushort)0, (ushort)0);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vendCashSale(ushort item_number, ushort item_price)
        {
            Log.d(TAG, string.Format("Cash Sale, product: {0}, price: {1}", item_number, item_price));
            vend(mdb_req_t.mdb_sub_command_vend_cash_sale, item_price, item_number);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void transferData(marshall_t.msg_transfer_data_t data)
        {
            Log.d(TAG, "TransferData");
            m_vmc_link.transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_trasfer_data, (byte)0, data));
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        private void vmcReaderEvent(marshall_t.msg_reader_t reader)
        {
            Log.d(TAG, "RdrEvent");
            m_vmc_link.transmit_marshall(marshall_t.request(marshall_t.marshall_func_code_reader_command, (byte)marshall_t.marshall_packet_option_ack_mask, reader));
        }

        // ===========================================================
        // Public Methods
        // ===========================================================

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void register_callbacks(vend_callbacks_t callbacks)
        {
            m_vend_callbacks = callbacks;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public bool is_ready()
        {
            return (!m_in_process && m_vend_state == vmc_vend_state_idle_e);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void session_start(int session_type)
        {
            if (is_ready())
            {
                m_in_process = true;

                m_session_type = session_type;

                notify(vmc_event_reader_enable_e, null);
            }
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void session_modify(int session_type)
        {
            m_session_type = session_type;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public int get_session_type()
        {
            return m_session_type;
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void session_cancel()
        {
            notify(vmc_event_session_cancel_e, null);

        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void session_close(vend_session_t session)
        {
            notify(vmc_event_session_close_e, session);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void vend_request(vend_session_t session)
        {
            notify(vmc_event_vend_request_e, session);
        }
        
        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void vend_cash_sale(cash_sale_t data)
        {
            notify(vmc_event_cash_sale_e, data);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input: product code, reason: see selection_deny_reason_<xxx>
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void vend_deny_selection(short product_code, int reason)
        {
            notify(vmc_event_remote_selection_deny, reason);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void vend_pp_pay(byte[] pp_number)
        {
            notify(vmc_event_pp_pay_e, pp_number);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void vmc_reader_event(byte event_type, byte payment_type_key_value, byte payment_type_data, byte[] payment_type_data_value)
        {
            marshall_t.msg_reader_t reader = new marshall_t.msg_reader_t();

            reader.event_type = event_type;
            reader.payment_type_key_value = payment_type_key_value;
            reader.payment_type_data = payment_type_data;
            reader.payment_type_key_value = payment_type_key_value;

            notify(vmc_event_vmc_reader_event_e, reader);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void transfer_data(marshall_t.msg_transfer_data_t data)
        {
            notify(vmc_event_send_transfer_data_e, data);

        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void get_session_status()
        {
            notify(vmc_event_session_status_req, null);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void get_reader_state()
        {
            notify(vmc_event_reader_state_req, null);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public void client_gateway_auth(bool approved)
        {
            marshall_t.msg_transfer_data_t data = new marshall_t.msg_transfer_data_t();

            data.encode_bitmap = marshall_t.msg_transfer_data_t.transfer_data_encode_vmc_auth_status;
            data.vmc_auth_status = approved ? marshall_t.msg_transfer_data_t.transfer_data_auth_status_approved_e : marshall_t.msg_transfer_data_t.transfer_data_auth_status_decline_e;

            transfer_data(data);
        }

        //////////////////////////////////////////////////////////////////////////////////////////////
        // function name:
        // input:
        // output:
        // notes:
        /////////////////////////////////////////////////////////////////////////////////////////////
        public long get_transaction_id()
        {
            long result = 0;

            if (m_current_session != null && m_current_session.data != null)
                result = m_current_session.data.transaction_id;

            return result;
        }
    }
}