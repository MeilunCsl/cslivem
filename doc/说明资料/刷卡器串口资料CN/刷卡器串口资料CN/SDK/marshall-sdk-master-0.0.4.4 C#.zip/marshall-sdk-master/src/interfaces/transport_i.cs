﻿namespace com.bitmick.marshall.interfaces
{
	public interface transport_i
	{

		// ===========================================================
		// Constants
		// ===========================================================

		// ===========================================================
		// enums
		// ===========================================================

		// ===========================================================
		// Fields
		// ===========================================================

		// ===========================================================
		// Abstract methods
		// ===========================================================

		// ===========================================================
		// Constructors
		// ===========================================================

		// ===========================================================
		// Methods from SuperClass/Interfaces (and supporting methods)
		// ===========================================================

		// ===========================================================
		// Methods
		// ===========================================================

		object allocate(string host, int port, string resource);
		void execute(object request, transport_i_transport_callbacks_t cb);
		void close(object request);

		void notifyTimerTick();
		void notifySocketError(int error);
		void notifySocketOpened();
		void notifySocketClosed();
		bool notifyReceivedData(sbyte[] data, int rcvd_len);
		void notifyDataTransmitted(bool success);
		void notifyFTPRxDone(bool success);
	}

	public static class transport_i_fields
	{
		public const int http_e = 0x00;
		public const int ftp_e = 0x01;
	}

	public interface transport_i_transport_callbacks_t
	{
		void onReady();

		// in case downloading, progress notification
		void onProgress(int percentage);

		// marshall initialization is done
		void onSuccess(string file_path);

		// socket error
		void onError(int error);
	}

}