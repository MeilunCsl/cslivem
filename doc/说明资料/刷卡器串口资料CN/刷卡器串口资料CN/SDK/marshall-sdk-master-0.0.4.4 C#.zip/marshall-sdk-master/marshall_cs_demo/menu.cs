﻿using System;
using System.Collections.Generic;
using System.Threading;



// 0..9 = 1
// 10..99 = 2
// 100..999 = 3
namespace com.bitmick.marshall.protocol
{
    public class menu_t
    {

        // ===========================================================
        // Constants
        // ===========================================================

        // ===========================================================
        // Fields
        // ===========================================================

        private static int m_menu_items_total;
        private static List<menu_item_t> m_menu_items;

        private static menu_t m_instance;

        private static Thread m_menu_thread;
        private volatile static bool m_menu_thread_running;

        // ===========================================================
        // Abstract methods
        // ===========================================================

        public abstract class menu_handler_t
        {
            public abstract void handle();
        }

        public class menu_item_t
        {
            public int index;
            public string title;
            public menu_handler_t handler;

            public menu_item_t(int _index, string _title, menu_handler_t _handler)
            {
                index = _index;
                title = _title;
                handler = _handler;
            }
        }

        // ===========================================================
        // Constructors
        // ===========================================================

        private menu_t()
        {
            m_menu_items = new List<menu_item_t>();
            m_menu_items_total = 0;

        }
        // ===========================================================
        // Methods from SuperClass/Interfaces (and supporting methods)
        // ===========================================================

        // ===========================================================
        // Methods
        // ===========================================================

        public static menu_t get_instance()
        {
            if (m_instance == null)
            {
                m_instance = new menu_t();
            }

            return m_instance;
        }

        public static void add(string title, menu_handler_t handler)
        {
            get_instance();

            m_menu_items.Add(new menu_item_t(m_menu_items_total, title, handler));

            m_menu_items_total++;
        }

        public static void run()
        {
            get_instance();

            // add

            // start parsing thread
            m_menu_thread = new Thread(new ThreadStart(menu_thread_proc));
            m_menu_thread.Priority = ThreadPriority.Normal;
            m_menu_thread.Start();

        }

        public static void show()
        {
            Console.WriteLine("");
            foreach (menu_item_t item in m_menu_items)
            {
                Console.WriteLine(string.Format("[{0}]: {1}", item.index, item.title));
            }
        }

        public static void stop()
        {
            m_menu_thread_running = false;
        }

        private static void menu_thread_proc()
        {
            m_menu_thread_running = true;


            int req_len = num_digits(m_menu_items_total - 1);

            while (m_menu_thread_running)
            {

                // show menu
                show();

                int index = inp_num(req_len);

                if (index >= 0 && index < m_menu_items_total)
                {

                    menu_item_t item = m_menu_items[index];

                    item.handler.handle();
                }
            }

            Console.WriteLine("");
            Console.WriteLine("finished");
        }

        private static int inp_num(int max_digits)
        {
            string inp = "";
            int inp_num = 0;
            // wait for user input
            do
            {
                char c = Console.ReadKey().KeyChar;
                if (c >= '0' && c <= '9')
                {
                    inp_num = inp_num * 10;
                    inp_num += c - '0';
                    inp += c;
                }
                else if (c == 27)
                {
                    inp_num = -1;
                    break;
                }
                else if (c == 13)
                {
                    break;
                }

            } while (inp.Length < max_digits);

            return inp_num;
        }

        private static int num_digits(int num)
        {
            int x = num;
            int req_len = 0;
            while (x > 0)
            {
                req_len += 1;
                x = x / 10;

            }

            return req_len;
        }

    }

}