﻿using System;
using System.Collections.Generic;

using com.bitmick.marshall.models;

namespace app
{
    using com.bitmick.marshall.protocol;
    using com.bitmick.marshall.utils;
    using System.Text;

    public abstract class cli_command_t
    {
        String title;
        public abstract void onExecute();
    }

    // CLI commands implementation
    public class StartSessionCommand : cli_command_t
    {
        public override void onExecute()
        {
            throw new NotImplementedException();
        }
    }

    class Program
    {
        internal static readonly string TAG = "main";
        
        public static vend_machine m_vend_machine;

        static void Main(string[] args)
        {
            Log.d(TAG, "welcome to marshall-c-sdk");
            Log.d(TAG, String.Format("marshall-sdk version: {0}", vmc_framework.get_version()));

            // create app_state object

            m_vend_machine = new vend_machine();

            m_vend_machine.start();

            menu_t.add("start session", new menu_command_handler_start_session());
            menu_t.add("cancel session", new menu_command_handler_cancel_session());
            menu_t.add("close session", new menu_command_handler_close_session());
            menu_t.add("query sessions", new menu_command_handler_query_sessions());
            menu_t.add("reader state", new menu_command_handler_reader_state());
            menu_t.add("cash sale", new menu_command_handler_cash_sale());
            menu_t.add("alert", new menu_command_handler_alert());
            menu_t.add("ftp socket test", new menu_command_handler_ftp_test());
            menu_t.add("screen control", new menu_command_handler_screen_control());
            menu_t.add("link stats", new menu_command_handler_link_stats());
            menu_t.add("quit", new menu_command_handler_menu_stop());

            menu_t.run();
        }

        public class menu_command_handler_start_session : menu_t.menu_handler_t
        {
            public override void handle()
            {
                if (m_vend_machine.vmc_config.always_idle)
                {
                    // prepare single session object
                    m_vend_machine.session = new vmc_vend_t.vend_session_t(2000, 1, (byte)0, 10);
                    // do vend request
                    m_vend_machine.vmc_instance.vend.vend_request(m_vend_machine.session);
                }
                else
                {
                    m_vend_machine.session = null;
                    m_vend_machine.start_session(vmc_vend_t.session_type_credit_e);
                }
            }
        }

        public class menu_command_handler_cancel_session : menu_t.menu_handler_t
        {
            public override void handle()
            {
                m_vend_machine.stop_session(null);
            }
        }

        public class menu_command_handler_close_session : menu_t.menu_handler_t
        {
            public override void handle()
            {
                m_vend_machine.close_session(m_vend_machine.session);
            }
        }

        public class menu_command_handler_query_sessions: menu_t.menu_handler_t
        {
            public override void handle()
            {
                m_vend_machine.vmc_instance.vend.get_session_status();
            }
        }

        public class menu_command_handler_reader_state : menu_t.menu_handler_t
        {
            public override void handle()
            {
                m_vend_machine.vmc_instance.vend.get_reader_state();
            }
        }

        public class menu_command_handler_cash_sale : menu_t.menu_handler_t
        {
            public override void handle()
            {
                vmc_vend_t.cash_sale_t data = new vmc_vend_t.cash_sale_t(0, 20);

                m_vend_machine.vmc_instance.vend.vend_cash_sale(data);
            }
        }

        public class menu_command_handler_alert : menu_t.menu_handler_t
        {
            public override void handle()
            {
                vmc_vend_t.cash_sale_t data = new vmc_vend_t.cash_sale_t(0, 20);

                m_vend_machine.vmc_instance.general.alert(200, "alert test");
            }
        }

        public class menu_command_handler_ftp_test : menu_t.menu_handler_t
        {
            public override void handle()
            {
                string url = null;
                int socket_type = -1;
                ushort port = 0;
                if (false)
                {
                    string host = "ftp.bitmick.net";
                    string user = "evmeter";
                    string pass = "Nayax";
                    string path = "/files/pglogo.png";
                    port = 21;

                    url = string.Format("{0};{1};{2};{3}", host, user, pass, path);
                    socket_type = vmc_socket_t.vmc_socket_type_ftp_e;

                }
                else
                {
                    url = "127.0.0.1";
                    port = 5555;
                }
                m_vend_machine.vmc_instance.socket.open_socket(socket_type, url, port);
            }
        }

        public class menu_command_handler_screen_control : menu_t.menu_handler_t
        {
            public override void handle()
            {
                // allocate layout
                Object ui_context = m_vend_machine.vmc_instance.general.display_control_create_layout(4);

                // add label
                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 0, 0, "Title");

                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 1, 0, "Opt 1");
                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 1, 1, "Opt 1");

                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 2, 0, "Opt 2");
                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 2, 1, "Opt 2");

                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 3, 0, "Opt 3");
                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 3, 1, "Opt 3");

                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 4, 0, "Opt 4");
                m_vend_machine.vmc_instance.general.display_control_layout_add_label(ui_context, 4, 1, "Opt 4");

                // apply layout on screen
                m_vend_machine.vmc_instance.general.display_control_apply_layout(ui_context);
            }
        }

        public class menu_command_handler_link_stats : menu_t.menu_handler_t
        {
            public override void handle()
            {
                vmc_link.vpos_link_stats_t stats = vmc_framework.getInstance().link.get_stats();


                Console.WriteLine(String.Format("\n\r ------ Stats ------ "));
                Console.WriteLine(String.Format("crc error: {0}", stats.crc_error));
                Console.WriteLine(String.Format("re-trans: {0}", stats.retrans));
                Console.WriteLine(String.Format("link loss: {0}", stats.comm_loss));
                Console.WriteLine(String.Format(" ------ Stats ------ \n\r"));
            }
        }
        public class menu_command_handler_menu_stop: menu_t.menu_handler_t
        {
            public override void handle()
            {
                m_vend_machine.stop();
                menu_t.stop();
            }
        }

    }


    public class vend_machine : vmc_vend_t.vend_callbacks_t
    {
        internal static readonly string TAG = "APP";

        public vmc_framework vmc_instance;
        public vmc_configuration vmc_config;
        public vmc_vend_t.vend_session_t session;

        public vend_machine()
        {
            vmc_instance = vmc_framework.getInstance();

            vmc_config = new vmc_configuration();

			vmc_config.port_vpos = "COM43";
            vmc_config.port_vpos_baud = 115200;

            vmc_config.machine_type = vmc_configuration.machine_type_none;
            vmc_config.model  = "marshall-cs-sdk";
            vmc_config.serial = "01234567";
            vmc_config.sw_ver = vmc_framework.get_version();
            
            vmc_config.multi_session_support = false;
            vmc_config.multi_vend_support = false;
            vmc_config.price_not_final_support = false;
            vmc_config.reader_always_on = false;
            vmc_config.always_idle = false;
            vmc_config.vend_denied_policy = vmc_configuration.vend_denied_policy_cancel;

            vmc_config.mag_card_approved_by_vmc_support = false;
            vmc_config.mifare_approved_by_vmc_support = false;
            
            // on production, disables these...
            vmc_config.debug = true;
			vmc_config.dump_packets_level = vmc_configuration.debug_level_dump_moderate;
            Log.initialize(@"marshall.log");

            vmc_instance.link.set_lowlevel(new lowlevel_serial());
            vmc_instance.configure(vmc_config);
            vmc_instance.link.set_events(new vmc_link_callback());
            vmc_instance.vend.register_callbacks(this);
            vmc_instance.socket.register_callbacks(new socket_callbacks_t());
            vmc_instance.general.register_callbacks(new time_update_callback());

        }

		public void start()
        {
            vmc_instance.start();
        }

        public void stop()
        {
            vmc_instance.stop();
        }

        public bool is_ready()
        {
            return vmc_instance.vend.is_ready();
        }

        public void start_session(int session_type)
        {
            vmc_instance.vend.session_start(session_type);
        }

        public void stop_session(vmc_vend_t.vend_session_t session)
        {
            if (!vmc_instance.vend.is_ready())
                vmc_instance.vend.session_cancel();
        }

        public void close_session(vmc_vend_t.vend_session_t session)
        {
            vmc_instance.vend.session_close(session);
        }

		public override void onReady(vmc_vend_t.vend_session_t session)
        {
            // vmc is ready for new session
            Log.d(TAG, "ready for new session");
        }

        public override void onSessionBegin(int funds_avail)
        {
            Log.d(TAG, "session began. requesting product vend");

            if (vmc_config.multi_vend_support)
            {
                List<vmc_vend_t.vend_item_t> list = new List<vmc_vend_t.vend_item_t>();

                list.Add(new vmc_vend_t.vend_item_t((ushort)1, (ushort)10, (short)1, (byte)1));
                list.Add(new vmc_vend_t.vend_item_t((ushort)2, (ushort)20, (short)2, (byte)1));
                list.Add(new vmc_vend_t.vend_item_t((ushort)3, (ushort)30, (short)3, (byte)1));

                // prepare single session object
                session = new vmc_vend_t.vend_session_t(list);
            }
            else
            {
                // prepare single session object
                session = new vmc_vend_t.vend_session_t(2000, 1, (byte)0, 10);
            }

            // do vend request
            vmc_instance.vend.vend_request(session);


            // acknowledge mifare (note: only when machine is working on mifare/mag mode)
            if (vmc_config.mifare_approved_by_vmc_support || vmc_config.mag_card_approved_by_vmc_support)
                vmc_instance.vend.client_gateway_auth(true);
        }

		public override bool onVendApproved(vmc_vend_t.vend_session_t session)
        {
            Log.d(TAG, "vend approved");

			// true:  vend success
			// false: vend failure
            
			return true;
        }

        public override void onVendDenied(vmc_vend_t.vend_session_t session)
        {
            Log.d(TAG, "vend denied");
        }

        public override void onTransactionInfo(vmc_vend_t.vend_session_data_t data)
        {
            if (data.cc_last_4_digits != null)
            {
                Log.d(TAG, String.Format("received cc last 4 digits: {0}", data.cc_last_4_digits));
            }

            if (data.transaction_id != -1)
            {
                Log.d(TAG, String.Format("transaction id: {0}", data.transaction_id));
            }

            if (data.card_bin != null)
            {
                Log.d(TAG, String.Format("card bin: {0}", data.card_bin));
            }

            if (data.prop_card_uid != null)
            {

                Log.d(TAG, String.Format("prop card uid: {0}", data.prop_card_uid));
            }

        }

        public override void onSettlement(bool success)
        {
            Log.d(TAG, string.Format("settlement: {0}", success ? "success" : "fail"));
        }

        public override void onStatus(int status)
        {
            Log.d(TAG, string.Format("received status: {0}", status));
        }

        public override void onOpenedSessions(ushort[] sessions)
        {
            foreach (ushort session in sessions)
            {
                Log.d(TAG, string.Format("open session: {0}", session));
            }
        }

        public override void onReaderState(bool enabled)
        {
            Log.d(TAG, string.Format("reader is: {0}", enabled ? "enabled" : "disabled"));
        }

        public override void onRemoteVend(int avail_funds, int product_code, int options)
        {
            Log.d(TAG, string.Format("remote product selected: {0}, price: {1}", product_code, avail_funds));
        }

        public override void onReceipt(int ereceipt_type, string data)
        {
            Log.d(TAG, string.Format("qr ereceipt: {0}", data));
        }
    }


    public class vmc_link_callback : vmc_link.vmc_link_events_t
    {
        internal static readonly string TAG = "APP";

        public void onCommError()
        {
        }

        public void onReady(vmc_link.vpos_config_t config)
        {
            String serial = StringUtils.reverse(Encoding.ASCII.GetString(config.vpos_serial, 0, config.vpos_serial.Length));

            Log.d(TAG, String.Format("link with vpos serial: {0}", serial));
        }
    }

    public class time_update_callback : vmc_general_t.GeneralEvents
    {
        public void onDCSParamChange(int dcs_param, byte[] data)
        {
            Log.d("--->", string.Format("received attribute update: id: {0}, value: {1}", dcs_param, StringUtils.byteArray2String(data)));
        }

        public void onTimeUpdate(byte year, byte month, byte day, byte hours, byte minutes, byte seconds)
        {
            Log.d("--->", String.Format("receveid time: {0}/{1}/{2} {3}:{4}:{5}", day, month, year, hours, minutes, seconds));
        }

        public void onDisplayEventButtonPressed(byte button_id)
        {
            Log.d("--->", String.Format("button pressed: {0}", button_id));
        }

        public void onDisplayEventTextInput(string input)
        {
            Log.d("--->", String.Format("text input: {0}", input));
        }

        public void onTransferData(byte[] data)
        {
            Log.d("--->", String.Format("received {0} bytes in transfer data", data.Length));
        }
    }

    public class socket_callbacks_t : vmc_socket_t.socket_callbacks_t
    {
        internal static readonly string TAG = "APP";

        int received_bytes = 0;

        public override void onReady()
        {
        }

        public override bool onReceive(byte[] buffer, int size)
        {
            received_bytes += size;

            Log.d(TAG, string.Format("received: {0} bytes, total: {1}", size, received_bytes));

            // you can save the bytes into a file (for FTP transfer for example)

            return true;
        }

        public override void onFTPDone(bool success)
        {
            Log.d(TAG, string.Format("finished FTP reception, status: {0}", success ? "success" : "fail"));

			received_bytes = 0;
        }

        public override void onSocketOpened()
        {
            Log.d(TAG, "socket is opened. on tcp socket, listening...");
        }

        public override void onSocketClosed()
        {
            Log.d(TAG, "socket closed...");
        }

        public override void onSocketError()
        {
            
        }

        public override void onTimerTick(long ms)
        {
            
        }

        public override void onTransmitDone(bool success)
        {
            Log.d(TAG, "transmitted data");
        
        }
    }
}
