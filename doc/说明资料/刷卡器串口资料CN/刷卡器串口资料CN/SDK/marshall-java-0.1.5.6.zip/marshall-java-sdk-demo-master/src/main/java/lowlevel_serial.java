import com.bitmick.marshall.interfaces.*;
import com.bitmick.utils.*;
import com.fazecast.jSerialComm.*;

import java.io.IOException;

public class lowlevel_serial implements lowlevel_i
{

    // ===========================================================
    // Constants
    // ===========================================================

    public static final String TAG = lowlevel_serial.class.getSimpleName();

    // ===========================================================
    // Fields
    // ===========================================================

    private link_events_t m_link_events;
    private SerialPort m_serial_port;

    private String m_serial_port_number;
    private int m_serial_port_baud_rate;

    private Thread  m_client_thread;
    private boolean m_client_thread_running;

    // ===========================================================
    // Abstract methods
    // ===========================================================

    // ===========================================================b
    // Constructors
    // ===========================================================

    // ===========================================================
    // Methods from SuperClass/Interfaces (and supporting methods)
    // ===========================================================

    @Override
    public void init(Object i_f, Object i_f_params)
    {
        m_serial_port_number = (String) i_f;
        m_serial_port_baud_rate = (Integer) i_f_params;
    }

    @Override
    public void register_link_events(link_events_t events)
    {
        m_link_events = events;
    }

    @Override
    public void start()
    {

        m_serial_port = SerialPort.getCommPort(m_serial_port_number);
        m_serial_port.setComPortParameters(m_serial_port_baud_rate, 8, SerialPort.ONE_STOP_BIT, SerialPort.NO_PARITY);

        if ((m_serial_port == null) || !m_serial_port.openPort())
        {
            Log.d(TAG, "failed opening serial port");

            m_serial_port = null;

            return;
        }

        m_client_thread = new Thread(new ClientAltHandlingRunnable());
        m_client_thread.start();
    }

    @Override
    public void stop()
    {
        if (m_serial_port != null)
        {
            m_serial_port.removeDataListener();
            m_serial_port.closePort();
        }
    }

    @Override
    public void reset()
    {

    }

    @Override
    public boolean transmit(byte[] data, int len)
    {
        try
        {
            if (m_serial_port != null)
                m_serial_port.writeBytes(data, len);
        }
        catch (Exception ex) {}

        return true;
    }

    @Override
    public void onLinkTimerTick(long ms)
    {
    }

    // ===========================================================
    // Methods
    // ===========================================================

    //////////////////////////////////////////////////////////////////////////////////////////////
    // class name:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    private class ClientAltHandlingRunnable implements Runnable {

        private int head;
        private int tail;
        private byte[] rx_buf;
        private boolean thread_running;

        public void stop()
        {
            thread_running = true;
        }

        private void reset()
        {
            head = 0;
            tail = 0;
        }

        private void serial_reset()
        {
            head = 0;
            tail = 0;
        }

        private int serial_read(byte[] buf, int offset)
        {
            int read_len = 0;

            synchronized (m_serial_port)
            {
                int to_read = Math.min(m_serial_port.bytesAvailable(), (buf.length - offset));
                if (to_read > 0)
                {
                    try {
                        read_len = m_serial_port.getInputStream().read(buf, offset, to_read);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
            }

            return read_len;
        }

        @Override
        public void run() {
            m_client_thread_running = true;

            byte[] rx_buf = new byte[4096 * 4];

            serial_reset();

            while (m_client_thread_running)
            {
                int read_len = serial_read(rx_buf, head);

                head += read_len;

                if (head != tail)
                {
                    Boolean cont = true;

                    // try to handle as many packets that might be inside buffer
                    do
                    {
                        int exp_len = ByteArrayUtils.byteArrToShort(rx_buf, tail) + 2;
                        int rcv_len = head - tail;

                        if (exp_len < 9 || exp_len > 512)
                        {
                            serial_reset();
                        }
                        else if (rcv_len >= exp_len)
                        {
                            // pass packet up
                            if (!m_link_events.onReceive(rx_buf, tail, exp_len))
                            {
                                serial_reset();
                            }
                            else
                            {
                                tail += exp_len;

                                // wrap around, only after packet processed successfully
                                if ((rx_buf.length - tail) <= 412 && tail == head)
                                    serial_reset();
                            }

                        }

                        cont = (head != tail) && (rcv_len >= exp_len);
                    } while (cont);
                }
                else
                {
                    Utils.threadSleep(1);
                }
            }
        }
    }
}
