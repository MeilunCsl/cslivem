import com.bitmick.marshall.models.vmc_configuration;
import com.bitmick.utils.Log;
import com.bitmick.utils.Utils;
import com.bitmick.marshall.vmc.*;
import menu.GenericMenu;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.TimeUnit;

public class Main {

    private final static String TAG = Main.class.getSimpleName();

    private static vmc_framework m_vmc;
    private static vmc_configuration vmc_config;
    private static vmc_vend_t.vend_session_t m_session;
    private static boolean is_running;

    private static Timer m_session_timer;
    private static Timer m_vend_request_timer;

    private static String m_pp_number;

    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    public static class WaitForCreditCardTimerTask extends TimerTask
    {
        private final static int TIMEOUT_MS = 30000;
        private static final String TAG = WaitForCreditCardTimerTask.class.getSimpleName();

        private long start_time;

        public WaitForCreditCardTimerTask()
        {
            start_time = Utils.currentTimeMillis();

            Log.d(TAG, String.format("starting session timer. you have %d seconds to swipe card before timeout", TIMEOUT_MS / 1000));
        }

        @Override
        public void run()
        {

            long ms = Utils.currentTimeMillis();

            if (ms - start_time > TIMEOUT_MS)
            {
                // stop session, no credit card arrived yet
                m_vmc.vend.session_cancel();

                // stop session timer
                session_timer_stop();
            }
        }
    }


    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    public static class DelayedVendRequestTimerTask extends TimerTask
    {

        private final static int TIMEOUT_MS = 5000;
        private static final String TAG = WaitForCreditCardTimerTask.class.getSimpleName();

        private long start_time;

        public DelayedVendRequestTimerTask()
        {
            start_time = Utils.currentTimeMillis();
        }

        @Override
        public void run()
        {

            long ms = Utils.currentTimeMillis();

            if (ms - start_time > TIMEOUT_MS)
            {

                // prepare session object
                m_session = new vmc_vend_t.vend_session_t(2000, 1, (byte) 0, 10);

                // vend request
                m_vmc.vend.vend_request(m_session);

                // stop session timer
                vend_timer_stop();
            }
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    private static void session_timer_start()
    {
        // invoke keep-alive - timer
        if (m_session_timer == null)
        {
            m_session_timer = new Timer(true);
            m_session_timer.scheduleAtFixedRate(new WaitForCreditCardTimerTask(), 0, 1000);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    private static void session_timer_stop()
    {
        // stop keepalive timer
        if (m_session_timer != null)
        {
            m_session_timer.cancel();
            m_session_timer = null;
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    private static void vend_timer_start()
    {
        // invoke keep-alive - timer
        if (m_vend_request_timer == null)
        {
            m_vend_request_timer = new Timer(true);
            m_vend_request_timer.scheduleAtFixedRate(new DelayedVendRequestTimerTask(), 0, 1000);
        }
    }

    //////////////////////////////////////////////////////////////////////////////////////////////
    // function name:
    // input:
    // output:
    // notes:
    /////////////////////////////////////////////////////////////////////////////////////////////
    private static void vend_timer_stop()
    {
        // stop keepalive timer
        if (m_vend_request_timer != null)
        {
            m_vend_request_timer.cancel();
            m_vend_request_timer = null;
        }
    }

    public static void main(String[] args)
    {
        GenericMenu menu = new GenericMenu();

        m_vmc = vmc_framework.getInstance();

        Log.d("main", "welcome to marshall-java-sdk");
        Log.d("main", String.format("marshall-sdk version: %s", vmc_framework.get_version()));

        vmc_config = new vmc_configuration();

        vmc_config.port_vpos = "COM43";
        vmc_config.port_vpos_baud = 115200;

        vmc_config.machine_type = vmc_configuration.machine_type_none;
        vmc_config.model = "marshall-java-sdk";
        vmc_config.serial = "01234567";
        vmc_config.sw_ver = vmc_framework.get_version();

        vmc_config.multi_vend_support = false;
        vmc_config.multi_session_support = false;
        vmc_config.price_not_final_support = false;
        vmc_config.reader_always_on = false;
        vmc_config.always_idle = false;
        vmc_config.vend_denied_policy = vmc_configuration.vend_denied_policy_cancel;

        vmc_config.mifare_approved_by_vmc_support = false;
        vmc_config.mag_card_approved_by_vmc_support = false;

        vmc_config.dump_packets_level = vmc_configuration.debug_level_dump_moderate;
        vmc_config.debug = true;

        // log capture to file sample
        if (true)
        {
            BufferedWriter out = null;

            try
            {
                FileWriter fstream = new FileWriter("c:\\out.txt", true); //true tells to append data.
                out = new BufferedWriter(fstream);

                Log.initialize(out);
            } catch (Exception ex)
            {
            }
        }

        m_vmc.link.set_lowlevel(new lowlevel_serial());
        m_vmc.link.configure(vmc_config);
        m_vmc.link.set_events(new vmc_link_events());
        m_vmc.vend.register_callbacks(new vmc_vend_events());
        m_vmc.socket.register_callbacks(new vmc_socket_events());
        m_vmc.general.register_callbacks(new vmc_general_t.GeneralEvents()
        {
            @Override
            public void onDCSParamChange(int dcs_param, byte[] data)
            {
                Log.d(TAG, String.format("dcs(%d): %s",dcs_param, new String(data)));
            }

            @Override
            public void onTransferData(byte[] bytes)
            {
                Log.d("--->", String.format("received %d bytes in transfer data", bytes.length));
            }

            @Override
            public void onDisplayEventButtonPressed(byte button_id)
            {
                Log.d("--->", String.format("button pressed: %d", button_id));
            }

            @Override
            public void onDisplayEventTextInput(String input)
            {
                Log.d("--->", String.format("text input: %d", input));
            }

            @Override
            public void onTimeUpdate(byte b, byte b1, byte b2, byte b3, byte b4, byte b5)
            {

            }
        });

        m_vmc.link.start();

        int menu_key = 0;
        menu.addMenuItem(Integer.toString(menu_key++), "Start Vend Session 0", new Runnable()
        {
            @Override
            public void run()
            {
                // multi-vend example
                if (vmc_config.multi_vend_support)
                {

                    ArrayList<vmc_vend_t.vend_item_t> list = new ArrayList<vmc_vend_t.vend_item_t>();

                    list.add(new vmc_vend_t.vend_item_t((short)0, (short)100, (short)1, (byte)1));
                    list.add(new vmc_vend_t.vend_item_t((short)1, (short)100, (short)1, (byte)1));
                    list.add(new vmc_vend_t.vend_item_t((short)2, (short)100, (short)1, (byte)1));
                    list.add(new vmc_vend_t.vend_item_t((short)2, (short)100, (short)1, (byte)1));
                    list.add(new vmc_vend_t.vend_item_t((short)2, (short)100, (short)1, (byte)1));

                    // prepare single session object
                    m_session = new vmc_vend_t.vend_session_t(list);
                }
                else
                {
                    // prepare single session object
                    m_session = new vmc_vend_t.vend_session_t(0, 1, (byte) 0, 10);
                }

                if (vmc_config.always_idle)
                {
                    // vend request
                    m_vmc.vend.vend_request(m_session);
                }
                else
                {
                    session_timer_start();

                    m_vmc.vend.session_start(vmc_vend_t.session_type_credit_e);
                }
            }
        });

        if (vmc_config.multi_session_support)
        {
            menu.addMenuItem(Integer.toString(menu_key++), "Start Vend Session 1", new Runnable()
            {
                @Override
                public void run()
                {
                    // prepare single session object
                    m_session = new vmc_vend_t.vend_session_t(1, 1, (byte) 0, 10);

                    if (vmc_config.always_idle)
                    {
                        // vend request
                        m_vmc.vend.vend_request(m_session);
                    }
                    else
                    {
                        session_timer_start();

                        m_vmc.vend.session_start(vmc_vend_t.session_type_credit_e);
                    }
                }
            });
        }

        menu.addMenuItem(Integer.toString(menu_key++), "Cancel Session", new Runnable()
        {
            @Override
            public void run()
            {
                session_timer_stop();
                m_vmc.vend.session_cancel();
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "Close Session 0", new Runnable()
        {
            @Override
            public void run()
            {
                if (m_session != null)
                {
                    // this line demonstrates the price_not_final capability.
                    if (vmc_config.price_not_final_support)
                    {
                        m_session.products_list.get(0).price = (short) (m_session.products_list.get(0).price / 2);

                    }

                    m_session.session_status = vmc_vend_t.session_status_fail_to_dispense_e;
                    m_session.products_list.get(0).code = 0;

                    m_vmc.vend.session_close(m_session);
                }
            }
        });

        if (vmc_config.multi_session_support)
        {

            menu.addMenuItem(Integer.toString(menu_key++), "Close Session 1", new Runnable()
            {
                @Override
                public void run()
                {
                    if (m_session != null)
                    {
                        // this line demonstrates the price_not_final capability.
                        if (vmc_config.price_not_final_support)
                        {
                            m_session.products_list.get(0).price = (short) (m_session.products_list.get(0).price / 2);

                        }

                        m_session.session_status = vmc_vend_t.session_status_ok_e;
                        m_session.products_list.get(0).code = 1;

                        m_vmc.vend.session_close(m_session);
                    }
                }
            });

        }

        if (vmc_config.multi_vend_support)
        {
            menu.addMenuItem(Integer.toString(menu_key++), "Paymarket Session", new Runnable()
            {
                @Override
                public void run() {
                    session_timer_start();


                    {

                        ArrayList<vmc_vend_t.vend_item_t> list = new ArrayList<vmc_vend_t.vend_item_t>();

                        list.add(new vmc_vend_t.vend_item_t((short) 0, (short) 100, (short) 1, (byte) 1));
                        list.add(new vmc_vend_t.vend_item_t((short) 1, (short) 100, (short) 1, (byte) 1));
                        list.add(new vmc_vend_t.vend_item_t((short) 2, (short) 100, (short) 1, (byte) 1));

                        // prepare single session object
                        m_session = new vmc_vend_t.vend_session_t(list);
                        m_vmc.vend.session_start(vmc_vend_t.session_type_credit_e);
                        Log.d(TAG, "waiting for credit-card. info session");
                    }
                }
            });

            menu.addMenuItem(Integer.toString(menu_key++), "Pay", new Runnable()
            {
                @Override
                public void run()
                {
                    session_timer_stop();
                    m_vmc.vend.vend_pp_pay(m_pp_number);
                    Log.d(TAG, String.format("charging pp card: %s", m_pp_number));
                }
            });
        }

        menu.addMenuItem(Integer.toString(menu_key++), "query opened sessions", new Runnable()
        {
            @Override
            public void run()
            {
                m_vmc.vend.get_session_status();
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "query reader state", new Runnable()
        {
            @Override
            public void run()
            {
                m_vmc.vend.get_reader_state();
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "cash sale", new Runnable()
        {
            @Override
            public void run()
            {
                m_vmc.vend.vend_cash_sale(new vmc_vend_t.cash_sale_t(0, 20));
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "alert", new Runnable()
        {
            @Override
            public void run()
            {
                Log.d(TAG, "alert");
                m_vmc.general.alert((short) 2, "Back door opened");
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "display message", new Runnable()
        {
            @Override
            public void run()
            {
                Log.d(TAG, "display message");
                m_vmc.general.set_display_text("hello!", (short)0, (short)0);
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "open socket", new Runnable()
        {
            @Override
            public void run()
            {
                String ftp_url = "speedtest.tele2.net;anonymous;anonymous;/100KB.zip";
                m_vmc.socket.open_socket(vmc_socket_t.vmc_socket_type_ftp_e, ftp_url, (short)21);
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "close socket", new Runnable()
        {
            @Override
            public void run()
            {
                m_vmc.socket.close_socket();
            }
        });

        menu.addMenuItem(Integer.toString(menu_key++), "UI control", new Runnable()
        {
            @Override
            public void run()
            {
                // allocate layout
                Object ui_context = m_vmc.general.display_control_create_layout(4);

                // add label
                m_vmc.general.display_control_layout_add_label(ui_context, 0, 0, "Title");

                m_vmc.general.display_control_layout_add_label(ui_context, 1, 0, "Opt 1");
                m_vmc.general.display_control_layout_add_label(ui_context, 1, 1, "Opt 1");

                m_vmc.general.display_control_layout_add_label(ui_context, 2, 0, "Opt 2");
                m_vmc.general.display_control_layout_add_label(ui_context, 2, 1, "Opt 2");

                m_vmc.general.display_control_layout_add_label(ui_context, 3, 0, "Opt 3");
                m_vmc.general.display_control_layout_add_label(ui_context, 3, 1, "Opt 3");

                m_vmc.general.display_control_layout_add_label(ui_context, 4, 0, "Opt 4");
                m_vmc.general.display_control_layout_add_label(ui_context, 4, 1, "Opt 4");

                // apply layout on screen
                m_vmc.general.display_control_apply_layout(ui_context);
            }
        });

        menu.addMenuItem("q", "quit", new Runnable()
        {
            @Override
            public void run()
            {
                is_running = false;
            }
        });

        menu.initMenu();

        m_vmc.link.stop();
    }

    private static class vmc_link_events implements vmc_link.vmc_link_events_t
    {

        @Override
        public void onReady(vmc_link.vpos_config_t config)
        {
            StringBuilder sb = new StringBuilder();
            sb.append(new String(config.vpos_serial));

            Log.d(TAG,  String.format("link with vpos serial: %s", sb.reverse().toString()));
            m_vmc.general.alert((short) 0x01, "hello there");
        }

        @Override
        public void onCommError()
        {

        }
    }

    private static class vmc_vend_events implements vmc_vend_t.vend_callbacks_t
    {
        @Override
        public void onReady(vmc_vend_t.vend_session_t session)
        {

        }

        @Override
        public void onSessionBegin(int funds_avail)
        {

            // credit card has been detected. stop timer
            session_timer_stop();

            // delayed vend example: send vend request later, and not now inside onBeginSession
            if (false)
                vend_timer_start();
            else
            {
                // vend request
                m_vmc.vend.vend_request(m_session);

                // example: approve mifar/mag card externally (vmc authenticates)
                if (vmc_config.mag_card_approved_by_vmc_support || vmc_config.mifare_approved_by_vmc_support)
                    m_vmc.vend.client_gateway_auth(true);
            }
        }

        @Override
        public void onTransactionInfo(vmc_vend_t.vend_session_data_t data)
        {
            if (data.cc_last_4_digits != null)
            {
                Log.d(TAG, String.format("received cc last 4 digits: %s", data.cc_last_4_digits));
            }

            if (data.transaction_id != -1)
            {
                Log.d(TAG, String.format("transaction id: %s", Long.toUnsignedString(m_vmc.vend.get_transaction_id())));
            }

            if (data.card_bin != null)
            {
                Log.d(TAG, String.format("card bin: %s", data.card_bin));

                m_pp_number = data.card_bin;
            }

            if (data.prop_card_uid != null)
            {

                Log.d(TAG, String.format("prop card uid: %s", data.prop_card_uid));
            }
        }

        @Override
        public boolean onVendApproved(vmc_vend_t.vend_session_t session)
        {
            Log.d("--->", "vend approved");

            // true:  vend success
            // false: vend failure
            return true;
        }

        @Override
        public void onVendDenied(vmc_vend_t.vend_session_t session)
        {
            Log.d("--->", "vend denied");
        }

        @Override
        public void onSettlement(boolean success)
        {
            Log.d("--->", String.format("settlement: %s", success ? "success" : "fail"));
        }

        @Override
        public void onStatus(int status)
        {
            Log.d(TAG, String.format("received status: %d10", status));
        }

        @Override
        public void onOpenedSessions(short[] sessions)
        {
            for (int session : sessions)
            {
                Log.d(TAG, String.format("opened session: %d", session));
            }
        }

        @Override
        public void onReaderState(boolean enabled)
        {
            Log.d(TAG, String.format("reader state: %s", enabled ? "enabled" : "disabled"));
        }

        @Override
        public void onReceipt(int ereceipt_type, String data)
        {
            Log.d(TAG, String.format("received qr e-receipt: %s", data));
        }
    }

    private static class vmc_socket_events implements vmc_socket_t.socket_callbacks_t
    {
        long start_time_stamp;
        int received_bytes = 0;

        @Override
        public void onReady()
        {

        }

        @Override
        public void onSocketOpened()
        {
            start_time_stamp = System.currentTimeMillis();
        }

        @Override
        public void onSocketClosed()
        {

        }

        @Override
        public void onSocketError()
        {

        }

        @Override
        public void onTimerTick(long ms)
        {

        }

        @Override
        public void onTransmitDone(boolean success)
        {

        }

        @Override
        public boolean onReceive(byte[] buffer, int size)
        {
            received_bytes += size;

            Log.d("--->", String.format("received: %d bytes, total: %d", size, received_bytes));

            return true;
        }

        @Override
        public void onFTPDone(boolean success)
        {
            long total_dl_time = System.currentTimeMillis() - start_time_stamp;
            Log.d("--->", String.format("ftp done. total: %d bytes. throughput = %f kb/sec", received_bytes, ((float)received_bytes) / total_dl_time));

            received_bytes = 0;
        }
    }
}