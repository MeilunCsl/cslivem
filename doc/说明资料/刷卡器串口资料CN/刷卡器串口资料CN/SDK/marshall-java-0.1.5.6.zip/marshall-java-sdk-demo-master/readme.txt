marshall sdk template project

